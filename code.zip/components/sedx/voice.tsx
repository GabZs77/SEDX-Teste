// TypeScript's non-platform fallback. Metro selects .native.tsx on Android/iOS
// and .web.tsx on web. Keep the generic fallback web-safe as well.
export { VoiceScreen, default } from "./voice.web";
