import React from "react";
import { Page, Card, Body, Notice } from "@/components/sedx/ui";
import { VOICE_DISCLOSURE } from "@/lib/sedx/voice-protocol";

/** Deliberately native-only calling: Web Preview must never resolve native WebRTC. */
export function VoiceScreen() {
  return (
    <Page title="Sala de voz" eyebrow="SEDX · P2P" subtitle="Até 20 participantes">
      <Card title="Chamadas no aplicativo Android">
        <Body>A prévia web não inicia chamadas nem acessa o microfone. Use o APK Android com o módulo WebRTC nativo; o Expo Go não inclui esse módulo.</Body>
      </Card>
      <Notice message={VOICE_DISCLOSURE} />
    </Page>
  );
}
export default VoiceScreen;
