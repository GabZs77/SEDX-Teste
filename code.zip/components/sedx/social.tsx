import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  AppState,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Linking,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { Redirect, useFocusEffect, useLocalSearchParams } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Clipboard from "expo-clipboard";
import * as DocumentPicker from "expo-document-picker";
import * as ImagePicker from "expo-image-picker";
import * as ImageManipulator from "expo-image-manipulator";
import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";
import {
  RecordingPresets,
  requestRecordingPermissionsAsync,
  setAudioModeAsync,
  useAudioPlayer,
  useAudioPlayerStatus,
  useAudioRecorder,
  useAudioRecorderState,
} from "expo-audio";
import { VideoView, useVideoPlayer } from "expo-video";
import { worker, useWorker } from "@/lib/sedx/api";
import { useSedx } from "@/lib/sedx/session";
import {
  C,
  Page,
  Card,
  Button,
  Input,
  Notice,
  Empty,
  Pill,
  Row,
  Body,
  Title,
} from "@/components/sedx/ui";
import { NotificationSettings } from "@/components/sedx/notification-settings";
import {
  IMAGE_MAX_BYTES,
  PROFILE_IMAGE_MAX_BYTES,
  PROFILE_IMAGE_MAX_CHARS,
  PROFILE_PRESETS,
  type Attachment,
  type ChatMessage,
  type CommunityChannel,
  type FeedbackMessage,
  type ProfileFields,
  type ReplyTarget,
  accountName,
  addReadMarkers,
  asList,
  base64Bytes,
  canReply,
  chatPayload,
  dataUriParts,
  feedbackCreatePayload,
  feedbackDeleteMessagePath,
  feedbackDeleteTicketPath,
  feedbackStatus,
  feedbackTicketPath,
  fitImage,
  formatDateTime,
  formatDuration,
  inferMime,
  initials,
  normalizeChatMessage,
  normalizeFeedbackMessage,
  normalizePartnership,
  normalizeProfile,
  normalizeTicket,
  noticeMarker,
  parseReadMarkers,
  profilePayload,
  publishedAbout,
  raDigits,
  readMarkerKey,
  replyContent,
  replyExcerpt,
  safeFilename,
  safeHttpUrl,
  safeImageUri,
  safeMediaUri,
  sameRa,
  shortName,
  splitReply,
  text,
  validateFeedbackContent,
  validateUpload,
} from "@/lib/sedx/social-utils";

const errorMessage = (error: unknown) =>
  error instanceof Error
    ? error.message
    : "Não foi possível concluir a operação. Tente novamente.";

/** Consultas periódicas existem somente na tela em foco e com o app em primeiro plano. */
function useForeground() {
  const [focused, setFocused] = useState(false);
  const [foreground, setForeground] = useState(
    AppState.currentState === "active",
  );
  useFocusEffect(
    useCallback(() => {
      setFocused(true);
      return () => setFocused(false);
    }, []),
  );
  useEffect(() => {
    const subscription = AppState.addEventListener("change", (state) =>
      setForeground(state === "active"),
    );
    return () => subscription.remove();
  }, []);
  return focused && foreground;
}
function useForegroundQuery(path: string | null, active: boolean, pollMs = 0) {
  const query = useWorker(active ? path : null);
  const refresh = useRef(query.refresh);
  useEffect(() => {
    refresh.current = query.refresh;
  }, [query.refresh]);
  useEffect(() => {
    if (!active || !path || !pollMs) return;
    let running = false;
    const timer = setInterval(() => {
      if (running || AppState.currentState !== "active") return;
      running = true;
      void refresh
        .current()
        .catch(() => {})
        .finally(() => {
          running = false;
        });
    }, pollMs);
    return () => clearInterval(timer);
  }, [active, path, pollMs]);
  return query;
}
function useAction() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const locked = useRef(false);
  const run = useCallback(async (action: () => Promise<void>, success = "") => {
    if (locked.current) return false;
    locked.current = true;
    setBusy(true);
    setError("");
    setNotice("");
    try {
      await action();
      setNotice(success);
      return true;
    } catch (caught) {
      setError(errorMessage(caught));
      return false;
    } finally {
      locked.current = false;
      setBusy(false);
    }
  }, []);
  return {
    busy,
    error,
    notice,
    run,
    clear: () => {
      setError("");
      setNotice("");
    },
  };
}
function ActionNotices({ action }: { action: ReturnType<typeof useAction> }) {
  return (
    <>
      {!!action.error && <Notice kind="error" message={action.error} />}
      {!!action.notice && <Notice kind="success" message={action.notice} />}
    </>
  );
}
function QueryState({
  loading,
  error,
  retry,
}: {
  loading: boolean;
  error: string | null;
  retry: () => Promise<void>;
}) {
  return (
    <>
      {loading && (
        <View style={styles.loading}>
          <ActivityIndicator color={C.accent} />
          <Text style={styles.meta}>Carregando…</Text>
        </View>
      )}
      {!!error && (
        <>
          <Notice kind="error" message={error} />
          <Button
            label="Tentar novamente"
            variant="secondary"
            onPress={() => {
              void retry().catch(() => {});
            }}
          />
        </>
      )}
    </>
  );
}
function confirmAction(title: string, message: string, action: () => void) {
  Alert.alert(title, message, [
    { text: "Cancelar", style: "cancel" },
    { text: "Confirmar", style: "destructive", onPress: action },
  ]);
}
function openExternal(value: unknown) {
  const url = safeHttpUrl(value);
  if (!url) {
    Alert.alert(
      "Link indisponível",
      "O endereço publicado não é um link HTTP ou HTTPS válido.",
    );
    return;
  }
  Alert.alert("Abrir link externo?", new URL(url).host, [
    { text: "Cancelar", style: "cancel" },
    {
      text: "Abrir",
      onPress: () => {
        void Linking.openURL(url).catch(() =>
          Alert.alert(
            "Não foi possível abrir o link",
            "Verifique se há um aplicativo compatível no dispositivo.",
          ),
        );
      },
    },
  ]);
}
function Inline({ value }: { value: string }) {
  return (
    <>
      {value
        .split(/(\*\*[^*\n]+\*\*|https?:\/\/[^\s<>]+)/g)
        .filter(Boolean)
        .map((part, index) => {
          if (part.startsWith("**") && part.endsWith("**"))
            return (
              <Text key={index} style={styles.bold}>
                {part.slice(2, -2)}
              </Text>
            );
          if (/^https?:\/\//i.test(part)) {
            const clean = part.replace(/[.,!?;:)\]]+$/, "");
            if (safeHttpUrl(clean))
              return (
                <Text
                  key={index}
                  accessibilityRole="link"
                  style={styles.link}
                  onPress={() => openExternal(clean)}
                >
                  {part}
                </Text>
              );
          }
          return <Text key={index}>{part}</Text>;
        })}
    </>
  );
}
/** Markdown básico é exibido em Text/View nativos; HTML recebido permanece texto. */
function RichText({ value }: { value: unknown }) {
  const lines = text(value).replace(/\r\n?/g, "\n").split("\n");
  return (
    <View style={styles.rich}>
      {lines.map((line, index) => {
        if (!line.trim())
          return <View key={index} style={styles.paragraphGap} />;
        const heading = line.match(/^(#{1,4})\s+(.+)$/);
        const quote = line.match(/^>\s?(.*)$/);
        const list = line.match(/^(?:[-*•]|\d+[.)])\s+(.+)$/);
        return (
          <Text
            key={index}
            selectable
            style={[
              styles.body,
              heading && styles.heading,
              quote && styles.quoteText,
              list && styles.listText,
            ]}
          >
            <Inline
              value={
                heading
                  ? heading[2]
                  : quote
                    ? quote[1]
                    : list
                      ? `• ${list[1]}`
                      : line
              }
            />
          </Text>
        );
      })}
    </View>
  );
}
function NativeImage({
  uri,
  label,
  avatar = false,
}: {
  uri: unknown;
  label: string;
  avatar?: boolean;
}) {
  const source = safeImageUri(uri);
  const [failedSource, setFailedSource] = useState("");
  if (!source || failedSource === source) return null;
  return (
    <Image
      source={{ uri: source }}
      accessibilityLabel={label}
      style={avatar ? styles.avatarImage : styles.image}
      resizeMode={avatar ? "cover" : "contain"}
      onError={() => setFailedSource(source)}
    />
  );
}
function Identity({
  name,
  photo,
  ra,
  admin,
}: {
  name: string;
  photo?: string;
  ra?: string;
  admin?: boolean;
}) {
  return (
    <View style={styles.identity}>
      <View style={styles.avatar}>
        <Text style={styles.avatarLetters}>{initials(name)}</Text>
        <NativeImage uri={photo} label={`Foto de ${name}`} avatar />
      </View>
      <View style={styles.identityText}>
        <Text style={styles.author}>{admin ? "Equipe SEDX" : name}</Text>
        {!!ra && <Text style={styles.meta}>RA {ra}</Text>}
      </View>
      {admin && <Pill label="Equipe" color={C.accent} />}
    </View>
  );
}
async function imageDimensions(
  uri: string,
): Promise<{ width: number; height: number }> {
  return new Promise((resolve, reject) =>
    Image.getSize(
      uri,
      (width, height) => resolve({ width, height }),
      () => reject(new Error("Não foi possível ler a imagem selecionada.")),
    ),
  );
}
type NativeFile = { uri: string; name: string; type: string; size?: number };
/** Reduz JPEG e dimensões, verificando bytes e tamanho serializado antes do envio. */
async function optimizeImage(
  uri: string,
  maxBytes = IMAGE_MAX_BYTES,
  maxChars = 350000,
) {
  const dimensions = await imageDimensions(uri);
  for (let attempt = 0; attempt < 11; attempt += 1) {
    const size = fitImage(
      dimensions.width,
      dimensions.height,
      Math.round(1200 * Math.pow(0.8, Math.max(0, attempt - 3))),
    );
    const result = await ImageManipulator.manipulateAsync(
      uri,
      [{ resize: size }],
      {
        compress: Math.max(0.3, 0.84 - attempt * 0.06),
        format: ImageManipulator.SaveFormat.JPEG,
        base64: true,
      },
    );
    const base64 = result.base64 || "";
    const data = `data:image/jpeg;base64,${base64}`;
    const bytes = base64Bytes(base64);
    if (bytes > 0 && bytes <= maxBytes && data.length <= maxChars)
      return { data, uri: result.uri, bytes };
    await FileSystem.deleteAsync(result.uri, { idempotent: true }).catch(
      () => {},
    );
  }
  throw new Error(
    "A imagem continua acima do limite após a otimização. Escolha outra imagem.",
  );
}
async function chooseImageData(profile = false) {
  const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (!permission.granted)
    throw new Error("Permita acesso às fotos para escolher uma imagem.");
  const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ["images"],
    allowsMultipleSelection: false,
    quality: 1,
  });
  if (result.canceled || !result.assets[0]) return null;
  const optimized = await optimizeImage(
    result.assets[0].uri,
    profile ? PROFILE_IMAGE_MAX_BYTES : IMAGE_MAX_BYTES,
    profile ? PROFILE_IMAGE_MAX_CHARS : 350000,
  );
  await FileSystem.deleteAsync(optimized.uri, { idempotent: true }).catch(
    () => {},
  );
  return optimized.data;
}
async function uploadNativeFile(file: NativeFile): Promise<Attachment> {
  const info = await FileSystem.getInfoAsync(file.uri);
  const size = info.exists && "size" in info ? info.size : file.size;
  validateUpload(size, file.type);
  const form = new FormData();
  // React Native transmite o arquivo por URI. Não usar Blob do navegador nem definir boundary manualmente.
  form.append("file", {
    uri: file.uri,
    name: safeFilename(file.name),
    type: file.type,
  } as unknown as Blob);
  const result = await worker("/chat/upload", { method: "POST", body: form });
  if (!result?.attachment?.url || !safeMediaUri(result.attachment.url))
    throw new Error("O Worker não retornou um anexo válido.");
  return {
    url: result.attachment.url,
    name: text(result.attachment.name) || file.name,
    type: text(result.attachment.type) || file.type,
  };
}
function mediaExtension(type: string) {
  const extensions: Record<string, string> = {
    "audio/mp4": "m4a",
    "audio/mpeg": "mp3",
    "audio/aac": "aac",
    "audio/webm": "webm",
    "audio/ogg": "ogg",
    "audio/wav": "wav",
    "video/mp4": "mp4",
    "video/webm": "webm",
    "video/quicktime": "mov",
    "application/pdf": "pdf",
    "text/plain": "txt",
    "application/zip": "zip",
  };
  return extensions[type] || safeFilename(type.split("/")[1], "bin");
}
async function cachedDataUri(source: string) {
  const data = dataUriParts(source);
  if (!data || !safeMediaUri(source) || !FileSystem.cacheDirectory)
    throw new Error("Não foi possível preparar o anexo no dispositivo.");
  const uri = `${FileSystem.cacheDirectory}sedx-media-${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${mediaExtension(data.type)}`;
  await FileSystem.writeAsStringAsync(uri, data.base64, {
    encoding: FileSystem.EncodingType.Base64,
  });
  return uri;
}
function useMediaSource(source: string) {
  const [prepared, setPrepared] = useState<{
    source: string;
    uri: string | null;
    error: string;
  }>({ source: "", uri: null, error: "" });
  useEffect(() => {
    let cancelled = false;
    let local: string | null = null;
    const prepare = async () => {
      try {
        const safe = safeMediaUri(source);
        if (!safe) throw new Error("Formato de mídia não permitido.");
        const value = safe.startsWith("data:")
          ? await cachedDataUri(safe)
          : safe;
        if (value.startsWith("file:")) local = value;
        if (cancelled) {
          if (local)
            await FileSystem.deleteAsync(local, { idempotent: true }).catch(
              () => {},
            );
          return;
        }
        setPrepared({ source, uri: value, error: "" });
      } catch (caught) {
        if (!cancelled)
          setPrepared({ source, uri: null, error: errorMessage(caught) });
      }
    };
    void prepare();
    return () => {
      cancelled = true;
      if (local)
        void FileSystem.deleteAsync(local, { idempotent: true }).catch(
          () => {},
        );
    };
  }, [source]);
  return prepared.source === source ? prepared : { uri: null, error: "" };
}
function AudioControl({ source, active }: { source: string; active: boolean }) {
  const media = useMediaSource(source);
  const player = useAudioPlayer(media.uri ? { uri: media.uri } : null, {
    updateInterval: 300,
  });
  const status = useAudioPlayerStatus(player);
  const [error, setError] = useState("");
  useEffect(() => {
    if (!active) {
      try {
        player.pause();
      } catch {}
    }
  }, [active, player]);
  const toggle = async () => {
    try {
      if (!active || !media.uri) return;
      if (status.playing) player.pause();
      else {
        await setAudioModeAsync({
          allowsRecording: false,
          playsInSilentMode: true,
          shouldPlayInBackground: false,
        });
        if (
          status.didJustFinish ||
          (status.duration > 0 && status.currentTime >= status.duration)
        )
          await player.seekTo(0);
        player.play();
      }
    } catch (caught) {
      setError(errorMessage(caught));
    }
  };
  return (
    <View style={styles.mediaBox}>
      <Row>
        <Button
          label={status.playing ? "Pausar áudio" : "Ouvir áudio"}
          variant="secondary"
          disabled={!active || !media.uri || !status.isLoaded}
          onPress={() => {
            void toggle();
          }}
        />
        <Text style={styles.meta}>
          {formatDuration(status.currentTime || 0)} /{" "}
          {formatDuration(status.duration || 0)}
        </Text>
      </Row>
      {!media.uri && !media.error && <ActivityIndicator color={C.accent} />}
      {!!(media.error || error) && (
        <Notice kind="error" message={media.error || error} />
      )}
    </View>
  );
}
function VideoControl({ source, active }: { source: string; active: boolean }) {
  const media = useMediaSource(source);
  const player = useVideoPlayer(media.uri, (item) => {
    item.loop = false;
  });
  useEffect(() => {
    if (!active) {
      try {
        player.pause();
      } catch {}
    }
  }, [active, player]);
  if (media.error) return <Notice kind="error" message={media.error} />;
  if (!media.uri) return <ActivityIndicator color={C.accent} />;
  return (
    <VideoView
      player={player}
      style={styles.video}
      nativeControls
      fullscreenOptions={{ enable: true }}
    />
  );
}
async function shareAttachment(item: Attachment) {
  const safe = safeMediaUri(item.url);
  if (!safe) throw new Error("Este anexo não possui um endereço seguro.");
  if (!(await Sharing.isAvailableAsync()))
    throw new Error(
      "O compartilhamento de arquivos não está disponível neste dispositivo.",
    );
  let uri: string | null = null;
  try {
    if (safe.startsWith("data:")) uri = await cachedDataUri(safe);
    else {
      if (!FileSystem.cacheDirectory)
        throw new Error("Armazenamento temporário indisponível.");
      uri = `${FileSystem.cacheDirectory}sedx-anexo-${Date.now()}-${safeFilename(item.name, `anexo.${mediaExtension(item.type)}`)}`;
      const result = await FileSystem.downloadAsync(safe, uri);
      if (result.status < 200 || result.status >= 300)
        throw new Error("Não foi possível baixar o anexo.");
    }
    await Sharing.shareAsync(uri, {
      mimeType: item.type,
      dialogTitle: item.name || "Anexo SEDX",
    });
  } finally {
    if (uri)
      await FileSystem.deleteAsync(uri, { idempotent: true }).catch(() => {});
  }
}
function AttachmentView({
  item,
  active,
}: {
  item: Attachment;
  active: boolean;
}) {
  const action = useAction();
  const image = item.type.startsWith("image/");
  return (
    <View style={styles.mediaBox}>
      {image && (
        <NativeImage uri={item.url} label={item.name || "Imagem anexada"} />
      )}
      {item.type.startsWith("video/") && (
        <VideoControl source={item.url} active={active} />
      )}
      {item.type.startsWith("audio/") && (
        <AudioControl source={item.url} active={active} />
      )}
      <Text style={styles.meta}>{item.name || "Anexo"}</Text>
      <Button
        label="Abrir / compartilhar anexo"
        variant="secondary"
        loading={action.busy}
        onPress={() => {
          void action.run(() => shareAttachment(item));
        }}
      />
      <ActionNotices action={action} />
    </View>
  );
}

function ChannelButton({
  title,
  description,
  onPress,
  tag,
}: {
  title: string;
  description: string;
  onPress: () => void;
  tag?: string;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`${title}. ${description}`}
      onPress={onPress}
      style={({ pressed }) => [styles.channel, pressed && styles.pressed]}
    >
      <View style={styles.channelText}>
        <Text style={styles.channelTitle}>{title}</Text>
        <Text style={styles.bodyMuted}>{description}</Text>
      </View>
      {tag && <Pill label={tag} />}
      <Text style={styles.channelArrow}>›</Text>
    </Pressable>
  );
}

export function CommunityScreen({
  initialChannel = "channels",
}: { initialChannel?: CommunityChannel } = {}) {
  const params = useLocalSearchParams<{ channel?: string }>();
  const routeChannel = ["general", "announcements", "drops", "voice"].includes(
    text(params.channel),
  )
    ? (params.channel as CommunityChannel)
    : initialChannel;
  return <CommunityChannels key={routeChannel} initialChannel={routeChannel} />;
}
function CommunityChannels({
  initialChannel,
}: {
  initialChannel: CommunityChannel;
}) {
  const [channel, setChannel] = useState<CommunityChannel>(initialChannel);
  const { session, profile } = useSedx();
  if (channel === "general")
    return <ChatRoom onBack={() => setChannel("channels")} />;
  if (channel === "announcements")
    return <Announcements onBack={() => setChannel("channels")} />;
  if (channel === "drops")
    return <Drops onBack={() => setChannel("channels")} />;
  if (channel === "voice") return <Redirect href="/voz" />;
  return (
    <Page
      title="Comunidade"
      eyebrow="Aprender juntos"
      subtitle="Aprender juntos nos leva mais longe."
    >
      <Card>
        <Identity name={accountName(session)} photo={profile?.photo} />
        <Title>Seu espaço para trocar ideias</Title>
        <Body>
          Tire dúvidas, compartilhe materiais e conecte-se com outros
          estudantes.
        </Body>
      </Card>
      <Text style={styles.sectionLabel}>INFORMAÇÕES</Text>
      <ChannelButton
        title="Anúncios"
        description="Novidades e comunicados do SEDX"
        onPress={() => setChannel("announcements")}
      />
      <Text style={styles.sectionLabel}>COMUNIDADE</Text>
      <ChannelButton
        title="Geral"
        description="Converse com todos os alunos em um espaço público e moderado"
        onPress={() => setChannel("general")}
      />
      <ChannelButton
        title="Streaming Drop"
        description="Contas e links publicados para os alunos"
        onPress={() => setChannel("drops")}
      />
      <Text style={styles.sectionLabel}>CANAIS DE VOZ</Text>
      <ChannelButton
        title="Sala de voz"
        description="Conversas ao vivo no aplicativo nativo"
        tag="Nativo"
        onPress={() => setChannel("voice")}
      />
    </Page>
  );
}

function ChatRoom({ onBack }: { onBack: () => void }) {
  const { session, profile, isAdmin } = useSedx();
  const active = useForeground();
  const query = useForegroundQuery("/chat/messages?limit=100", active, 5000);
  const messages = asList(query.data?.messages || query.data).map(
    normalizeChatMessage,
  );
  const action = useAction();
  const [content, setContent] = useState("");
  const [attachment, setAttachment] = useState<Attachment | null>(null);
  const [audio, setAudio] = useState<Attachment | null>(null);
  const [reply, setReply] = useState<ReplyTarget | null>(null);
  const [editing, setEditing] = useState<ChatMessage | null>(null);
  const [atBottom, setAtBottom] = useState(true);
  const list = useRef<FlatList<ChatMessage>>(null);
  const input = useRef<TextInput>(null);
  const activeRef = useRef(active);
  useEffect(() => {
    activeRef.current = active;
  }, [active]);
  const recordLock = useRef(false);
  const recorder = useAudioRecorder({
    ...RecordingPresets.HIGH_QUALITY,
    bitRate: 64000,
    sampleRate: 22050,
    numberOfChannels: 1,
  });
  const recording = useAudioRecorderState(recorder, 250);
  const recordingRef = useRef(false);
  const [recordingNow, setRecordingNow] = useState(false);
  const count = useRef(0);
  useEffect(() => {
    if (messages.length !== count.current && atBottom)
      setTimeout(() => list.current?.scrollToEnd({ animated: true }), 80);
    count.current = messages.length;
  }, [messages.length, atBottom]);
  useEffect(() => {
    if (!active && recordingRef.current) {
      recordingRef.current = false;
      setRecordingNow(false);
      void recorder
        .stop()
        .catch(() => {})
        .finally(() => {
          void setAudioModeAsync({
            allowsRecording: false,
            shouldPlayInBackground: false,
          }).catch(() => {});
        });
    }
  }, [active, recorder]);
  useEffect(
    () => () => {
      if (recordingRef.current) {
        recordingRef.current = false;
        void recorder
          .stop()
          .catch(() => {})
          .finally(() => {
            void setAudioModeAsync({
              allowsRecording: false,
              shouldPlayInBackground: false,
            }).catch(() => {});
          });
      }
    },
    [recorder],
  );
  const stopRecording = async () => {
    if (recordLock.current || !recordingRef.current) return;
    recordLock.current = true;
    recordingRef.current = false;
    setRecordingNow(false);
    await action.run(async () => {
      try {
        const duration = recording.durationMillis / 1000;
        await recorder.stop();
        if (!activeRef.current) return;
        if (!recorder.uri)
          throw new Error("Não foi possível salvar a gravação.");
        const uploaded = await uploadNativeFile({
          uri: recorder.uri,
          name: `audio-${Date.now()}.m4a`,
          type: "audio/mp4",
        });
        if (activeRef.current) {
          setAudio({ ...uploaded, duration });
          setAttachment(null);
        }
      } finally {
        await setAudioModeAsync({
          allowsRecording: false,
          shouldPlayInBackground: false,
        }).catch(() => {});
      }
    });
    recordLock.current = false;
  };
  useEffect(() => {
    if (recordingNow && recording.durationMillis >= 120000)
      void stopRecording();
  });
  const toggleRecording = async () => {
    if (recordingRef.current) {
      await stopRecording();
      return;
    }
    if (!activeRef.current || recordLock.current) return;
    recordLock.current = true;
    await action.run(async () => {
      try {
        const permission = await requestRecordingPermissionsAsync();
        if (!permission.granted)
          throw new Error("Permita acesso ao microfone para gravar áudio.");
        if (!activeRef.current) return;
        await setAudioModeAsync({
          allowsRecording: true,
          playsInSilentMode: true,
          shouldPlayInBackground: false,
          allowsBackgroundRecording: false,
        });
        await recorder.prepareToRecordAsync();
        if (!activeRef.current) {
          await setAudioModeAsync({ allowsRecording: false });
          return;
        }
        recorder.record();
        recordingRef.current = true;
        setRecordingNow(true);
      } catch (caught) {
        await setAudioModeAsync({ allowsRecording: false }).catch(() => {});
        throw caught;
      }
    });
    recordLock.current = false;
  };
  const chooseFile = async () => {
    await action.run(async () => {
      const result = await DocumentPicker.getDocumentAsync({
        type: [
          "image/*",
          "video/*",
          "audio/*",
          "application/pdf",
          "text/plain",
          "application/zip",
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ],
        copyToCacheDirectory: true,
        multiple: false,
      });
      if (result.canceled || !result.assets[0]) return;
      const file = result.assets[0];
      const type = inferMime(file.name, file.mimeType);
      let temporary: string | null = null;
      try {
        let upload: NativeFile = {
          uri: file.uri,
          name: file.name,
          type,
          size: file.size,
        };
        if (type.startsWith("image/")) {
          const optimized = await optimizeImage(file.uri);
          temporary = optimized.uri;
          upload = {
            uri: optimized.uri,
            name: `${safeFilename(file.name).replace(/\.[^.]+$/, "")}.jpg`,
            type: "image/jpeg",
            size: optimized.bytes,
          };
        }
        const uploaded = await uploadNativeFile(upload);
        if (activeRef.current) {
          setAttachment(uploaded);
          setAudio(null);
        }
      } finally {
        if (temporary)
          await FileSystem.deleteAsync(temporary, { idempotent: true }).catch(
            () => {},
          );
      }
    });
  };
  const send = async () => {
    if (!active || recordingNow) return;
    await action.run(async () => {
      if (editing) {
        const next = content.trim();
        if (!next || next.length > 4000)
          throw new Error("A mensagem deve ter de 1 a 4.000 caracteres.");
        await worker(`/chat/messages/${encodeURIComponent(editing.id)}`, {
          method: "PUT",
          body: { content: next },
        });
      } else
        await worker("/chat/messages", {
          method: "POST",
          body: {
            ...chatPayload(content, attachment, audio),
            replyTo: reply
              ? { id: reply.id || "", name: reply.name, content: reply.excerpt }
              : null,
            avatarUrl: safeImageUri(profile?.photo),
          },
        });
      setContent("");
      setAttachment(null);
      setAudio(null);
      setReply(null);
      setEditing(null);
      setAtBottom(true);
      await query.refresh();
      list.current?.scrollToEnd({ animated: true });
    });
  };
  const moderate = (message: ChatMessage, kind: "delete" | "mute" | "ban") => {
    if (!isAdmin) return;
    const titles = {
      delete: "Remover mensagem?",
      mute: "Silenciar aluno?",
      ban: "Proibir entrada no chat?",
    };
    confirmAction(
      titles[kind],
      kind === "mute"
        ? "O aluno não poderá enviar mensagens por 60 minutos."
        : "A moderação é aplicada pelo Worker à conta selecionada.",
      () => {
        void action.run(async () => {
          const path =
            kind === "delete"
              ? `messages/${encodeURIComponent(message.id)}/delete`
              : kind;
          const body =
            kind === "mute"
              ? { userRa: raDigits(message.authorRa), durationMinutes: 60 }
              : kind === "ban"
                ? {
                    userRa: raDigits(message.authorRa),
                    reason: "Moderação da comunidade",
                  }
                : {};
          await worker(`/admin/chat/${path}`, { method: "POST", body });
          await query.refresh();
        }, "Moderação aplicada.");
      },
    );
  };
  const renderMessage = ({ item }: { item: ChatMessage }) => {
    const mine = sameRa(item.authorRa, session?.usuario);
    const name = mine ? accountName(session) : shortName(item.author.name);
    const quote = splitReply(item.content);
    return (
      <View style={[styles.message, mine && styles.mine]}>
        <Identity
          name={name}
          photo={item.author.avatarUrl || (mine ? profile?.photo : "")}
        />
        <Text style={styles.meta}>
          {formatDateTime(item.createdAt)}
          {item.editedAt ? " · editada" : ""}
        </Text>
        {item.deleted ? (
          <Text style={styles.bodyMuted}>
            Mensagem removida pela administração.
          </Text>
        ) : (
          <>
            {!!(quote.name || item.replyTo) && (
              <View style={styles.quote}>
                <Text style={styles.author}>
                  {quote.name || item.replyTo?.name}
                </Text>
                <Text style={styles.bodyMuted}>
                  {quote.excerpt || item.replyTo?.content}
                </Text>
              </View>
            )}
            <RichText value={quote.content} />
            {item.attachmentUrl && (
              <AttachmentView
                active={active}
                item={{
                  url: item.attachmentUrl,
                  name: item.attachmentName,
                  type: item.attachmentType,
                }}
              />
            )}
            {item.audioUrl && (
              <AudioControl
                source={item.audioUrl}
                active={active && !recordingNow}
              />
            )}
            <Row>
              {canReply(item, session?.usuario) && (
                <Button
                  label="Responder"
                  variant="secondary"
                  disabled={action.busy || recordingNow}
                  onPress={() => {
                    setEditing(null);
                    setContent("");
                    setReply({
                      id: item.id,
                      name,
                      excerpt: replyExcerpt(item),
                    });
                    input.current?.focus();
                  }}
                />
              )}
              {mine && !item.deleted && (
                <Button
                  label="Editar"
                  variant="secondary"
                  disabled={action.busy || recordingNow}
                  onPress={() => {
                    setEditing(item);
                    setReply(null);
                    setAttachment(null);
                    setAudio(null);
                    setContent(item.content);
                    input.current?.focus();
                  }}
                />
              )}
              {mine && !item.deleted && (
                <Button
                  label="Excluir minha mensagem"
                  variant="danger"
                  disabled={action.busy}
                  onPress={() =>
                    confirmAction(
                      "Excluir sua mensagem?",
                      "Sua mensagem será removida do canal geral.",
                      () => {
                        void action.run(async () => {
                          await worker(
                            `/chat/messages/${encodeURIComponent(item.id)}`,
                            { method: "DELETE" },
                          );
                          await query.refresh();
                        }, "Mensagem excluída.");
                      },
                    )
                  }
                />
              )}
              {isAdmin && (
                <Button
                  label="Remover"
                  variant="danger"
                  disabled={action.busy}
                  onPress={() => moderate(item, "delete")}
                />
              )}
            </Row>
            {isAdmin && !mine && (
              <Row>
                <Button
                  label="Silenciar 1h"
                  variant="secondary"
                  disabled={action.busy}
                  onPress={() => moderate(item, "mute")}
                />
                <Button
                  label="Proibir entrada"
                  variant="danger"
                  disabled={action.busy}
                  onPress={() => moderate(item, "ban")}
                />
              </Row>
            )}
          </>
        )}
      </View>
    );
  };
  return (
    <Page
      title="Geral"
      eyebrow="Comunidade"
      subtitle="Mensagens públicas para todos os alunos logados."
      scroll={false}
    >
      <KeyboardAvoidingView
        style={styles.chatLayout}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
      >
        <Button
          label="Voltar aos canais"
          variant="secondary"
          onPress={onBack}
        />
        <QueryState
          loading={query.loading && !messages.length}
          error={query.error}
          retry={query.refresh}
        />
        <FlatList
          ref={list}
          data={messages}
          keyExtractor={(item) => item.id}
          renderItem={renderMessage}
          style={styles.messageList}
          contentContainerStyle={styles.messageListContent}
          keyboardShouldPersistTaps="handled"
          onScroll={(event) => {
            const { contentOffset, contentSize, layoutMeasurement } =
              event.nativeEvent;
            setAtBottom(
              contentOffset.y + layoutMeasurement.height >=
                contentSize.height - 100,
            );
          }}
          scrollEventThrottle={100}
          onContentSizeChange={() => {
            if (atBottom) list.current?.scrollToEnd({ animated: false });
          }}
          ListEmptyComponent={
            !query.loading && !query.error ? (
              <Empty
                title="O grupo está esperando você"
                description="Compartilhe uma dúvida ou material de estudo com a comunidade."
              />
            ) : null
          }
        />
        <View style={styles.composer}>
          <ActionNotices action={action} />
          {reply && (
            <View style={styles.quote}>
              <Text style={styles.author}>Respondendo a {reply.name}</Text>
              <Text style={styles.bodyMuted}>{reply.excerpt}</Text>
              <Button
                label="Cancelar resposta"
                variant="secondary"
                onPress={() => setReply(null)}
              />
            </View>
          )}
          {editing && (
            <Row>
              <Pill label="Editando mensagem" />
              <Button
                label="Cancelar edição"
                variant="secondary"
                onPress={() => {
                  setEditing(null);
                  setContent("");
                }}
              />
            </Row>
          )}
          {(attachment || audio) && (
            <Card
              title={
                audio ? "Áudio pronto para enviar" : "Anexo pronto para enviar"
              }
            >
              <Text style={styles.bodyMuted}>
                {(attachment || audio)?.name}
              </Text>
              {audio && (
                <AudioControl
                  source={audio.url}
                  active={active && !recordingNow}
                />
              )}
              <Button
                label="Remover anexo"
                variant="secondary"
                disabled={action.busy}
                onPress={() => {
                  setAttachment(null);
                  setAudio(null);
                }}
              />
            </Card>
          )}
          {recordingNow && (
            <Notice
              message={`Gravando ${formatDuration(recording.durationMillis / 1000)} · limite de 2 minutos. Ao sair da tela a gravação é descartada.`}
            />
          )}
          <Text style={styles.inputLabel}>
            {editing ? "Editar mensagem" : "Mensagem para a comunidade"}
          </Text>
          <TextInput
            ref={input}
            accessibilityLabel={
              editing ? "Editar mensagem" : "Mensagem para a comunidade"
            }
            placeholderTextColor={C.muted}
            selectionColor={C.accent}
            value={content}
            onChangeText={setContent}
            multiline
            maxLength={4000}
            style={[styles.nativeInput, styles.composerInput]}
            placeholder="Escreva uma mensagem…"
            editable={!action.busy && !recordingNow}
          />
          <Text style={styles.meta}>
            {replyContent(content, reply).length}/4000
            {reply ? " · inclui a citação" : ""}
          </Text>
          <Row>
            {!editing && (
              <>
                <Button
                  label="Anexar"
                  variant="secondary"
                  disabled={action.busy || recordingNow || !active}
                  onPress={() => {
                    void chooseFile();
                  }}
                />
                <Button
                  label={recordingNow ? "Parar gravação" : "Gravar áudio"}
                  variant={recordingNow ? "danger" : "secondary"}
                  disabled={action.busy || !active}
                  onPress={() => {
                    void toggleRecording();
                  }}
                />
              </>
            )}
            <Button
              label={editing ? "Salvar edição" : "Enviar"}
              loading={action.busy}
              disabled={
                !active ||
                recordingNow ||
                (!content.trim() && !attachment && !audio)
              }
              onPress={() => {
                void send();
              }}
            />
          </Row>
          {!isAdmin && (
            <Text style={styles.meta}>
              A remoção de mensagens do chat depende da administração no
              contrato atual.
            </Text>
          )}
        </View>
      </KeyboardAvoidingView>
    </Page>
  );
}

/** A rota antiga de notificações abre o mesmo canal de anúncios, sem outra fonte de dados. */
export function NotificationsScreen() {
  return <CommunityScreen initialChannel="announcements" />;
}
function Announcements({ onBack }: { onBack: () => void }) {
  const { siteState, refreshSiteState, session } = useSedx();
  const active = useForeground();
  const action = useAction();
  const notices = asList(siteState?.notifications);
  const [readState, setReadState] = useState<{
    key: string;
    markers: string[];
    loaded: boolean;
  }>({ key: "", markers: [], loaded: false });
  const key = readMarkerKey(session?.usuario);
  const markers = readState.key === key ? readState.markers : [];
  const loaded = readState.key === key && readState.loaded;
  useEffect(() => {
    let cancelled = false;
    void AsyncStorage.getItem(key)
      .then((value) => {
        if (!cancelled) {
          setReadState({ key, markers: parseReadMarkers(value), loaded: true });
        }
      })
      .catch(() => {
        if (!cancelled) setReadState({ key, markers: [], loaded: true });
      });
    return () => {
      cancelled = true;
    };
  }, [key]);
  const runAction = action.run;
  useEffect(() => {
    if (active) void runAction(refreshSiteState);
  }, [active, runAction, refreshSiteState]);
  const markRead = async (items: any[]) => {
    await action.run(async () => {
      const next = addReadMarkers(markers, items);
      await AsyncStorage.setItem(key, JSON.stringify(next));
      setReadState({ key, markers: next, loaded: true });
    });
  };
  const unread = notices.filter(
    (item) => !markers.includes(noticeMarker(item)),
  ).length;
  return (
    <Page
      title="Anúncios"
      eyebrow="Comunidade · Informações"
      subtitle="Novidades e comunicados do SEDX."
      onRefresh={() => action.run(refreshSiteState).then(() => {})}
    >
      <Button label="Voltar aos canais" variant="secondary" onPress={onBack} />
      <ActionNotices action={action} />
      <Row>
        <Pill
          label={
            loaded
              ? `${unread} não lido${unread === 1 ? "" : "s"}`
              : "Carregando leitura…"
          }
        />
        <Button
          label="Marcar todos como lidos"
          variant="secondary"
          disabled={!loaded || action.busy || unread === 0}
          onPress={() => {
            void markRead(notices);
          }}
        />
      </Row>
      {action.busy && !siteState && <ActivityIndicator color={C.accent} />}
      {!siteState && !action.busy && (
        <Notice message="Não foi possível obter o estado de anúncios. Atualize para tentar novamente." />
      )}
      {siteState && !notices.length && (
        <Empty
          title="Nenhum anúncio publicado"
          description="As novidades da equipe aparecerão neste canal."
        />
      )}
      {notices.map((notice, index) => {
        const read = markers.includes(noticeMarker(notice));
        return (
          <Card
            key={text(notice.id) || String(index)}
            title={text(notice.title)}
          >
            <Row>
              <Pill
                label={read ? "Lido" : "Novo"}
                color={read ? C.muted : C.accent}
              />
              {notice.audience && (
                <Text style={styles.meta}>{text(notice.audience)}</Text>
              )}
            </Row>
            <RichText value={notice.description} />
            <NativeImage
              uri={notice.image}
              label={text(notice.title) || "Imagem do comunicado"}
            />
            <Text style={styles.meta}>
              {formatDateTime(notice.publishedAt)}
            </Text>
            {!read && (
              <Button
                label="Marcar como lido"
                variant="secondary"
                disabled={!loaded || action.busy}
                onPress={() => {
                  void markRead([notice]);
                }}
              />
            )}
          </Card>
        );
      })}
      <NotificationSettings />
      <Text style={styles.meta}>
        As marcações de leitura ficam somente neste dispositivo; o cadastro push
        acima usa o Worker existente.
      </Text>
    </Page>
  );
}
function Drops({ onBack }: { onBack: () => void }) {
  return (
    <Page
      title="Streaming Drop"
      eyebrow="Comunidade"
      subtitle="Contas e links publicados para os alunos."
    >
      <Button label="Voltar aos canais" variant="secondary" onPress={onBack} />
      <Card title="Integração pendente">
        <Notice message="O Worker ativo ainda não disponibiliza os recursos de Streaming Drop. Publicações e reservas dependem da ativação desse contrato no serviço existente." />
        <Body>
          Não há acesso fictício nem reserva local nesta versão. As ferramentas
          e parcerias publicadas continuam disponíveis nas suas respectivas
          áreas.
        </Body>
      </Card>
    </Page>
  );
}

export function HelpScreen({ ticketId }: { ticketId?: string } = {}) {
  const params = useLocalSearchParams<{ ticketId?: string; id?: string }>();
  const initialId = ticketId || text(params.ticketId || params.id);
  return <HelpCenter key={initialId} initialId={initialId} />;
}
function HelpCenter({ initialId }: { initialId: string }) {
  const { session, isAdmin } = useSedx();
  const active = useForeground();
  const [selected, setSelected] = useState(initialId);
  const [creating, setCreating] = useState(false);
  const [kind, setKind] = useState<"bug" | "suggestion">("suggestion");
  const [content, setContent] = useState("");
  const [image, setImage] = useState("");
  const [editing, setEditing] = useState<FeedbackMessage | null>(null);
  const action = useAction();
  const mine = useForegroundQuery(
    !selected && !creating ? "/feedback/mine" : null,
    active,
  );
  const admin = useForegroundQuery(
    !selected && !creating && isAdmin ? "/admin/feedback" : null,
    active,
  );
  const thread = useForegroundQuery(
    selected ? feedbackTicketPath(selected) : null,
    active,
    selected ? 8000 : 0,
  );
  const ticket = thread.data?.ticket
    ? normalizeTicket(thread.data.ticket)
    : null;
  const messages = asList(thread.data?.messages).map(normalizeFeedbackMessage);
  const back = () => {
    setSelected("");
    setCreating(false);
    setEditing(null);
    setContent("");
    setImage("");
    action.clear();
  };
  const openTicket = (id: string) => {
    setSelected(id);
    setCreating(false);
    setContent("");
    setEditing(null);
    action.clear();
  };
  const create = async () => {
    await action.run(async () => {
      const result = await worker("/feedback", {
        method: "POST",
        headers: { "X-Task-User": accountName(session) },
        body: feedbackCreatePayload(kind, content, image),
      });
      setCreating(false);
      setContent("");
      setImage("");
      const newId = text(result?.ticket?.id || result?.id);
      if (newId) setSelected(newId);
      // A consulta de lista será recarregada quando sair do formulário.
    }, "Atendimento enviado. A equipe do SEDX responderá por aqui.");
  };
  const send = async () => {
    await action.run(
      async () => {
        const next = validateFeedbackContent(content);
        await worker("/feedback/message", {
          method: editing ? "PUT" : "POST",
          body: editing
            ? { id: editing.id, content: next }
            : { ticketId: selected, content: next },
        });
        setContent("");
        setEditing(null);
        await thread.refresh();
      },
      editing ? "Mensagem atualizada." : "Mensagem enviada.",
    );
  };
  const deleteMessage = (message: FeedbackMessage) => {
    confirmAction(
      "Excluir mensagem?",
      "A mensagem será removida deste atendimento.",
      () => {
        void action.run(async () => {
          await worker(feedbackDeleteMessagePath(message.id), {
            method: "DELETE",
          });
          await thread.refresh();
        }, "Mensagem excluída.");
      },
    );
  };
  const tickets = (items: any[], adminList = false) =>
    items.map((raw, index) => {
      const item = normalizeTicket(raw);
      return (
        <Card key={item.id || String(index)}>
          <Row>
            <Pill
              label={item.type === "bug" ? "Problema" : "Sugestão ou dúvida"}
            />
            <Pill
              label={feedbackStatus(item.status)}
              color={item.status === "resolvido" ? C.green : C.accent}
            />
          </Row>
          {adminList && <Identity name={item.userName} ra={item.userRa} />}
          <Text style={styles.body} numberOfLines={4}>
            {item.content}
          </Text>
          <Text style={styles.meta}>
            Atendimento #{item.id.slice(-6)} · {formatDateTime(item.createdAt)}
          </Text>
          {item.adminReply && (
            <Text style={styles.bodyMuted} numberOfLines={2}>
              Equipe SEDX: {item.adminReply}
            </Text>
          )}
          <Button
            label="Abrir atendimento"
            variant="secondary"
            onPress={() => openTicket(item.id)}
          />
        </Card>
      );
    });
  if (creating)
    return (
      <Page
        title="Novo atendimento"
        eyebrow="Central de ajuda"
        subtitle="Conte como podemos ajudar."
      >
        <Button
          label="Voltar aos atendimentos"
          variant="secondary"
          disabled={action.busy}
          onPress={back}
        />
        <Card title="O que aconteceu?">
          <Identity
            name={accountName(session)}
            ra={raDigits(session?.usuario)}
          />
          <Body>
            Descreva sua dúvida, sugestão ou problema. Não envie sua senha nem
            informações sensíveis.
          </Body>
          <Row>
            <Button
              label="Sugestão ou dúvida"
              variant={kind === "suggestion" ? "primary" : "secondary"}
              disabled={action.busy}
              onPress={() => setKind("suggestion")}
            />
            <Button
              label="Problema"
              variant={kind === "bug" ? "primary" : "secondary"}
              disabled={action.busy}
              onPress={() => setKind("bug")}
            />
          </Row>
          <Input
            label="Descrição do atendimento"
            value={content}
            onChangeText={setContent}
            placeholder="Escreva sua mensagem…"
            multiline
            maxLength={2000}
            style={styles.multiline}
            editable={!action.busy}
          />
          <Text style={styles.meta}>
            {content.length}/2000 · mínimo de 10 caracteres
          </Text>
          <NativeImage uri={image} label="Prévia da imagem do atendimento" />
          <Row>
            <Button
              label={image ? "Trocar imagem" : "Anexar imagem"}
              variant="secondary"
              disabled={action.busy}
              onPress={() => {
                void action.run(async () => {
                  const value = await chooseImageData();
                  if (value) setImage(value);
                });
              }}
            />
            {!!image && (
              <Button
                label="Remover imagem"
                variant="secondary"
                disabled={action.busy}
                onPress={() => setImage("")}
              />
            )}
          </Row>
          <ActionNotices action={action} />
          <Button
            label="Enviar atendimento"
            loading={action.busy}
            disabled={content.trim().length < 10}
            onPress={() => {
              void create();
            }}
          />
        </Card>
      </Page>
    );
  if (selected)
    return (
      <Page
        title={ticket ? `Atendimento #${ticket.id.slice(-6)}` : "Atendimento"}
        eyebrow="Central de ajuda"
        subtitle={
          ticket
            ? `${ticket.type === "bug" ? "Problema" : "Sugestão ou dúvida"} · ${feedbackStatus(ticket.status)}`
            : undefined
        }
        onRefresh={thread.refresh}
      >
        <Button
          label="Voltar aos atendimentos"
          variant="secondary"
          disabled={action.busy}
          onPress={back}
        />
        <QueryState
          loading={thread.loading && !ticket}
          error={thread.error}
          retry={thread.refresh}
        />
        <ActionNotices action={action} />
        {ticket && ticket.id === selected && (
          <>
            <Card title="Mensagem inicial">
              <Identity
                name={
                  sameRa(ticket.userRa, session?.usuario)
                    ? accountName(session)
                    : ticket.userName
                }
                ra={ticket.userRa}
              />
              <RichText value={ticket.content} />
              <NativeImage uri={ticket.image} label="Imagem do atendimento" />
              <Text style={styles.meta}>
                {formatDateTime(ticket.createdAt)}
              </Text>
            </Card>
            {ticket.adminReply &&
              !messages.some((item) => item.authorRole === "admin") && (
                <Card title="Equipe SEDX">
                  <RichText value={ticket.adminReply} />
                </Card>
              )}
            {messages.map((message) => {
              const isMine =
                message.mine || sameRa(message.authorRa, session?.usuario);
              const canDelete =
                isMine ||
                (isAdmin &&
                  thread.data?.admin === true &&
                  message.authorRole === "admin" &&
                  message.authorRa === "assistente");
              return (
                <Card key={message.id} style={isMine ? styles.mine : undefined}>
                  <Identity
                    name={isMine ? accountName(session) : message.authorName}
                    ra={
                      message.authorRole === "admin"
                        ? undefined
                        : message.authorRa
                    }
                    admin={message.authorRole === "admin"}
                  />
                  {message.deleted ? (
                    <Text style={styles.bodyMuted}>Mensagem excluída</Text>
                  ) : (
                    <RichText value={message.content} />
                  )}
                  <Text style={styles.meta}>
                    {formatDateTime(message.createdAt)}
                    {message.editedAt ? " · editada" : ""}
                  </Text>
                  {!message.deleted && (
                    <Row>
                      {isMine && (
                        <Button
                          label="Editar"
                          variant="secondary"
                          disabled={action.busy}
                          onPress={() => {
                            setEditing(message);
                            setContent(message.content);
                            action.clear();
                          }}
                        />
                      )}
                      {canDelete && (
                        <Button
                          label="Excluir"
                          variant="danger"
                          disabled={action.busy}
                          onPress={() => deleteMessage(message)}
                        />
                      )}
                    </Row>
                  )}
                </Card>
              );
            })}
            <Card title={editing ? "Editar mensagem" : "Continuar atendimento"}>
              <Input
                label={
                  editing
                    ? "Texto da mensagem editada"
                    : "Mensagem para o suporte"
                }
                value={content}
                onChangeText={setContent}
                placeholder="Escreva uma mensagem…"
                multiline
                maxLength={2000}
                style={styles.multiline}
                editable={!action.busy}
              />
              <Text style={styles.meta}>{content.length}/2000</Text>
              <Row>
                {editing && (
                  <Button
                    label="Cancelar edição"
                    variant="secondary"
                    disabled={action.busy}
                    onPress={() => {
                      setEditing(null);
                      setContent("");
                    }}
                  />
                )}
                <Button
                  label={editing ? "Salvar edição" : "Enviar mensagem"}
                  loading={action.busy}
                  disabled={!content.trim()}
                  onPress={() => {
                    void send();
                  }}
                />
              </Row>
            </Card>
            {isAdmin && thread.data?.admin === true && (
              <Button
                label="Excluir atendimento"
                variant="danger"
                disabled={action.busy}
                onPress={() =>
                  confirmAction(
                    "Excluir atendimento?",
                    "Todas as mensagens serão excluídas. Esta ação não pode ser desfeita.",
                    () => {
                      void action.run(async () => {
                        await worker(feedbackDeleteTicketPath(selected), {
                          method: "DELETE",
                        });
                        back();
                      }, "Atendimento excluído.");
                    },
                  )
                }
              />
            )}
          </>
        )}
      </Page>
    );
  const ownTickets = asList(mine.data?.feedback);
  const adminTickets = asList(admin.data?.feedback);
  return (
    <Page
      title="Central de ajuda"
      eyebrow="Atendimento SEDX"
      subtitle={`Olá, ${accountName(session).split(" ")[0]}. Conte com a equipe do SEDX.`}
      onRefresh={async () => {
        await Promise.all([
          mine.refresh(),
          ...(isAdmin ? [admin.refresh()] : []),
        ]);
      }}
    >
      <Card title="Como podemos ajudar?">
        <Body>
          Suas conversas com o suporte ficam aqui, conectadas à sua conta.
        </Body>
        <Button
          label="Abrir novo atendimento"
          onPress={() => {
            setCreating(true);
            setKind("suggestion");
            setContent("");
            setImage("");
            action.clear();
          }}
        />
      </Card>
      <ActionNotices action={action} />
      <Title>Seus atendimentos</Title>
      <QueryState
        loading={mine.loading}
        error={mine.error}
        retry={mine.refresh}
      />
      {!mine.loading && !mine.error && !ownTickets.length && (
        <Empty
          title="Nenhum atendimento"
          description="Suas conversas com o suporte aparecerão aqui."
        />
      )}
      {tickets(ownTickets)}
      {isAdmin && (
        <>
          <Title>Atendimentos dos alunos</Title>
          <QueryState
            loading={admin.loading}
            error={admin.error}
            retry={admin.refresh}
          />
          {!admin.loading && !admin.error && !adminTickets.length && (
            <Empty title="Nenhum atendimento dos alunos" />
          )}
          {tickets(adminTickets, true)}
        </>
      )}
    </Page>
  );
}

export function ProfileScreen() {
  const { session, profile, refreshProfile, signOut, siteState } = useSedx();
  const active = useForeground();
  const [pending, setPending] = useState<ProfileFields | null>(null);
  const draft = pending || normalizeProfile(profile);
  const dirty = pending !== null;
  const preview = normalizeProfile(draft);
  const action = useAction();
  const runAction = action.run;
  useEffect(() => {
    if (active) void runAction(refreshProfile);
  }, [active, runAction, refreshProfile]);

  const patch = (value: Partial<ProfileFields>) => {
    if (!profile) return;
    setPending((previous) => ({
      ...normalizeProfile(profile),
      ...(previous || {}),
      ...value,
    }));
    action.clear();
  };
  const save = async () => {
    await action.run(async () => {
      await worker("/profile", {
        method: "PUT",
        body: profilePayload(profile, draft),
      });
      await refreshProfile();
      setPending(null);
    }, "Perfil salvo e sincronizado.");
  };
  const image = async (key: "photo" | "banner") => {
    await action.run(async () => {
      const value = await chooseImageData(true);
      if (value) patch({ [key]: value });
    });
  };
  const colorLabels: Record<
    "accent" | "secondary" | "bg" | "foreground",
    string
  > = {
    accent: "Cor principal",
    secondary: "Cor secundária",
    bg: "Fundo do perfil",
    foreground: "Cor do texto",
  };
  return (
    <Page
      title="Perfil"
      eyebrow="Conta do aluno"
      subtitle="Personalize como os outros alunos veem você."
      onRefresh={async () => {
        if (dirty) {
          Alert.alert(
            "Alterações não salvas",
            "Salve ou descarte suas alterações antes de atualizar.",
          );
          return;
        }
        await action.run(refreshProfile);
      }}
    >
      <ActionNotices action={action} />
      {!profile && action.busy && <ActivityIndicator color={C.accent} />}
      {!profile && !action.busy && (
        <Notice message="Carregue seu perfil antes de editar. Atualize a tela para tentar novamente sem substituir informações existentes." />
      )}
      <Card
        style={{ backgroundColor: preview.bg, borderColor: preview.accent }}
      >
        <NativeImage uri={draft.banner} label="Banner do perfil" />
        <Identity
          name={accountName(session)}
          photo={draft.photo}
          ra={raDigits(session?.usuario)}
        />
        <Text style={[styles.body, { color: preview.foreground }]}>
          {draft.description || "Conte um pouco sobre você."}
        </Text>
        <Row>
          <Button
            label="Editar foto"
            variant="secondary"
            disabled={action.busy}
            onPress={() => {
              void image("photo");
            }}
          />
          <Button
            label="Editar banner"
            variant="secondary"
            disabled={action.busy}
            onPress={() => {
              void image("banner");
            }}
          />
        </Row>
        <Row>
          {!!draft.photo && (
            <Button
              label="Remover foto"
              variant="secondary"
              disabled={action.busy}
              onPress={() => patch({ photo: "" })}
            />
          )}
          {!!draft.banner && (
            <Button
              label="Remover banner"
              variant="secondary"
              disabled={action.busy}
              onPress={() => patch({ banner: "" })}
            />
          )}
        </Row>
      </Card>
      <Card title="Informações do perfil">
        <Input
          label="Nome da conta · não editável"
          value={accountName(session)}
          editable={false}
        />
        <Input
          label="Descrição"
          value={draft.description}
          onChangeText={(description) => patch({ description })}
          multiline
          maxLength={180}
          style={styles.multiline}
          editable={!action.busy && !!profile}
          placeholder="Conte um pouco sobre você…"
        />
        <Text style={styles.meta}>{draft.description.length}/180</Text>
        {session?.escola && (
          <Text style={styles.bodyMuted}>{text(session.escola)}</Text>
        )}
      </Card>
      <Card title="Aparência do perfil">
        <Body>
          Os temas abaixo são preferências do perfil sincronizadas com o Worker.
          Temas sazonais continuam seguindo o estado publicado do SEDX.
        </Body>
        <Row>
          {PROFILE_PRESETS.map((preset) => (
            <Pressable
              key={preset.id}
              accessibilityRole="button"
              accessibilityState={{ selected: draft.theme === preset.id }}
              accessibilityLabel={`Tema ${preset.name}`}
              disabled={action.busy}
              onPress={() =>
                patch({
                  theme: preset.id,
                  accent: preset.accent,
                  secondary: preset.secondary,
                  bg: preset.bg,
                  foreground: preset.foreground,
                })
              }
              style={({ pressed }) => [
                styles.preset,
                {
                  backgroundColor: preset.bg,
                  borderColor:
                    draft.theme === preset.id ? preset.accent : C.border,
                },
                pressed && styles.pressed,
              ]}
            >
              <View
                style={[styles.swatch, { backgroundColor: preset.accent }]}
              />
              <Text style={{ color: preset.foreground }}>{preset.name}</Text>
            </Pressable>
          ))}
        </Row>
        {(["accent", "secondary", "bg", "foreground"] as const).map((key) => (
          <Input
            key={key}
            label={colorLabels[key]}
            value={draft[key]}
            onChangeText={(value) => patch({ theme: "custom", [key]: value })}
            autoCapitalize="none"
            autoCorrect={false}
            maxLength={7}
            editable={!action.busy && !!profile}
            placeholder="#RRGGBB"
          />
        ))}
        <Text style={styles.meta}>
          Tema sazonal publicado: {text(siteState?.activeTheme) || "padrão"}
        </Text>
      </Card>
      <Row>
        <Button
          label="Salvar perfil"
          loading={action.busy}
          disabled={!dirty || !profile}
          onPress={() => {
            void save();
          }}
        />
        <Button
          label="Descartar alterações"
          variant="secondary"
          disabled={!dirty || action.busy}
          onPress={() => {
            setPending(null);
            action.clear();
          }}
        />
      </Row>
      <Card title="Segurança">
        <Body>
          Seu nome e RA vêm da conta SED e não podem ser alterados aqui. Sua
          senha não faz parte do perfil.
        </Body>
        <Button
          label="Sair da conta"
          variant="danger"
          disabled={action.busy}
          onPress={() =>
            confirmAction(
              "Sair da conta?",
              "Você precisará entrar novamente para acessar seus dados escolares.",
              () => {
                void action.run(signOut);
              },
            )
          }
        />
      </Card>
    </Page>
  );
}

export function ToolsScreen() {
  const { siteState, refreshSiteState } = useSedx();
  const active = useForeground();
  const action = useAction();
  const tools = asList(siteState?.tools);
  const runAction = action.run;
  useEffect(() => {
    if (active) void runAction(refreshSiteState);
  }, [active, runAction, refreshSiteState]);
  const runTool = (tool: any) => {
    void action.run(
      async () => {
        if (tool.actionType === "site") {
          if (!safeHttpUrl(tool.content))
            throw new Error("O endereço publicado não é válido.");
          openExternal(tool.content);
        } else if (tool.actionType === "copy")
          await Clipboard.setStringAsync(text(tool.content));
        else throw new Error("A ação desta ferramenta não é suportada.");
      },
      tool.actionType === "copy" ? "Conteúdo copiado." : "",
    );
  };
  return (
    <Page
      title="Ferramentas"
      eyebrow="Utilidades do SEDX"
      subtitle="Recursos complementares para apoiar sua rotina de estudos."
      onRefresh={() => action.run(refreshSiteState).then(() => {})}
    >
      <ActionNotices action={action} />
      {action.busy && !siteState && <ActivityIndicator color={C.accent} />}
      {!siteState && !action.busy && (
        <Notice message="Não foi possível obter as ferramentas. Atualize para tentar novamente." />
      )}
      {siteState && !tools.length && (
        <Empty
          title="Nenhuma ferramenta disponível"
          description="As ferramentas publicadas aparecerão aqui."
        />
      )}
      {tools.map((tool, index) => (
        <Card key={text(tool.id) || String(index)} title={text(tool.title)}>
          <NativeImage
            uri={tool.image}
            label={text(tool.title) || "Imagem da ferramenta"}
          />
          <RichText value={tool.description} />
          {tool.actionType === "copy" && (
            <Text style={styles.bodyMuted} numberOfLines={4}>
              {text(tool.content)}
            </Text>
          )}
          <Button
            label={
              tool.actionType === "site" ? "Ir para o site" : "Copiar conteúdo"
            }
            variant="secondary"
            disabled={
              action.busy || !["site", "copy"].includes(tool.actionType)
            }
            onPress={() => runTool(tool)}
          />
        </Card>
      ))}
    </Page>
  );
}
export function PartnershipsScreen() {
  const active = useForeground();
  const query = useForegroundQuery("/partnerships", active);
  const partnerships = asList(query.data?.partnerships)
    .map(normalizePartnership)
    .filter((item) => item.isPublished);
  return (
    <Page
      title="Parcerias"
      eyebrow="Conexões que somam"
      subtitle="Conheça iniciativas e comunidades parceiras do SEDX."
      onRefresh={query.refresh}
    >
      <QueryState
        loading={query.loading}
        error={query.error}
        retry={query.refresh}
      />
      {!query.loading && !query.error && !partnerships.length && (
        <Empty
          title="Nenhuma parceria disponível"
          description="As parcerias publicadas aparecerão aqui."
        />
      )}
      {partnerships.map((item) => (
        <Card key={item.id} title={item.title}>
          <NativeImage uri={item.banner} label={`Banner de ${item.title}`} />
          <NativeImage uri={item.logo} label={`Logo de ${item.title}`} />
          <Pill label={item.type} />
          <RichText value={item.description} />
          {item.destinationUrl ? (
            <>
              <Text style={styles.meta}>
                {new URL(item.destinationUrl).host}
              </Text>
              <Button
                label="Conhecer parceria"
                onPress={() => openExternal(item.destinationUrl)}
              />
            </>
          ) : (
            <Notice message="O link desta parceria não está disponível." />
          )}
        </Card>
      ))}
    </Page>
  );
}
export function AboutScreen() {
  const active = useForeground();
  const query = useForegroundQuery("/about", active);
  const about = publishedAbout(query.data);
  return (
    <Page
      title="Sobre"
      eyebrow="Conheça o SEDX"
      subtitle="Conheça a proposta e as ferramentas do SEDX."
      onRefresh={query.refresh}
    >
      <QueryState
        loading={query.loading}
        error={query.error}
        retry={query.refresh}
      />
      {!query.loading && !query.error && !about && (
        <Empty
          title="Sobre o SEDX"
          description="As informações desta página ainda não foram publicadas."
        />
      )}
      {about && (
        <>
          <Card title={about.title}>
            <RichText value={about.intro} />
          </Card>
          {about.sections.map((section, index) => (
            <Card
              key={text(section.id) || String(index)}
              title={text(section.title)}
            >
              <NativeImage
                uri={section.image}
                label={text(section.title) || "Imagem da seção"}
              />
              <RichText value={section.text} />
              {[...asList(section.links), ...asList(section.buttons)].map(
                (link, linkIndex) =>
                  safeHttpUrl(link.url) && (
                    <Button
                      key={`${index}-${linkIndex}`}
                      label={text(link.label) || "Abrir link"}
                      variant="secondary"
                      onPress={() => openExternal(link.url)}
                    />
                  ),
              )}
            </Card>
          ))}
        </>
      )}
    </Page>
  );
}

const styles = StyleSheet.create({
  loading: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingVertical: 12,
  },
  body: { color: C.text, fontSize: 15, lineHeight: 23 },
  bodyMuted: { color: C.muted, fontSize: 14, lineHeight: 21 },
  meta: { color: C.muted, fontSize: 12, lineHeight: 18, flexShrink: 1 },
  bold: { fontWeight: "700" },
  link: { color: C.blue, textDecorationLine: "underline" },
  rich: { gap: 3 },
  paragraphGap: { height: 7 },
  heading: { fontSize: 18, fontWeight: "700", marginVertical: 4 },
  quoteText: { color: C.muted, paddingLeft: 12 },
  listText: { paddingLeft: 8 },
  identity: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    flexWrap: "wrap",
  },
  identityText: { flex: 1, minWidth: 100, gap: 2 },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: C.raised,
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
  },
  avatarImage: { width: 44, height: 44, position: "absolute" },
  avatarLetters: { color: C.accent, fontWeight: "700", fontSize: 16 },
  author: { color: C.text, fontWeight: "700", fontSize: 14, lineHeight: 20 },
  image: {
    width: "100%",
    height: 190,
    borderRadius: 12,
    backgroundColor: C.raised,
  },
  video: { width: "100%", height: 210, borderRadius: 12 },
  mediaBox: { gap: 8, paddingVertical: 5 },
  sectionLabel: {
    color: C.muted,
    fontSize: 11,
    fontWeight: "700",
    letterSpacing: 1.4,
    marginTop: 10,
  },
  channel: {
    flexDirection: "row",
    gap: 10,
    alignItems: "center",
    padding: 18,
    backgroundColor: C.surface,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: C.border,
    minHeight: 88,
  },
  channelText: { flex: 1, gap: 4 },
  channelTitle: { color: C.text, fontWeight: "700", fontSize: 17 },
  channelArrow: { color: C.accent, fontSize: 28 },
  pressed: { opacity: 0.72 },
  chatLayout: { flex: 1, minHeight: 0, gap: 8 },
  messageList: { flex: 1, minHeight: 160 },
  messageListContent: { paddingVertical: 10, gap: 12 },
  message: {
    backgroundColor: C.surface,
    borderRadius: 15,
    borderWidth: 1,
    borderColor: C.border,
    padding: 14,
    gap: 9,
  },
  mine: { borderColor: C.accent },
  quote: {
    borderLeftWidth: 3,
    borderLeftColor: C.accent,
    paddingVertical: 8,
    paddingHorizontal: 12,
    gap: 6,
    backgroundColor: C.raised,
    borderRadius: 8,
  },
  composer: {
    gap: 8,
    borderTopWidth: 1,
    borderTopColor: C.border,
    paddingTop: 10,
    paddingBottom: 6,
  },
  inputLabel: { color: C.muted, fontSize: 12, fontWeight: "600" },
  nativeInput: {
    color: C.text,
    fontSize: 15,
    backgroundColor: C.bg,
    borderWidth: 1,
    borderColor: C.border,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  composerInput: { minHeight: 56, maxHeight: 112, textAlignVertical: "top" },
  multiline: { minHeight: 112, textAlignVertical: "top" },
  preset: {
    borderWidth: 2,
    borderRadius: 12,
    padding: 12,
    gap: 8,
    minWidth: 92,
    minHeight: 86,
    alignItems: "center",
  },
  swatch: { width: 30, height: 30, borderRadius: 15 },
});
