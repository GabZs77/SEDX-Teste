import React, { useCallback, useEffect, useState } from "react";
import { AppState, NativeModules, PermissionsAndroid, Platform, StyleSheet, View } from "react-native";
import type { AppStateStatus, Permission } from "react-native";
import Constants, { ExecutionEnvironment } from "expo-constants";
import { useFocusEffect } from "expo-router";
import { setAudioModeAsync } from "expo-audio";
import type { MediaStream, MediaStreamTrack, RTCPeerConnection, RTCRtpTransceiver } from "react-native-webrtc";
import { Body, Button, C, Card, Empty, Notice, Page, Pill, Row } from "@/components/sedx/ui";
import { useSedx } from "@/lib/sedx/session";
import {
  cleanVoiceName, parseVoiceMessage, serializeVoiceMessage, voiceIceServers, voiceIdentity,
  voiceJoin, voicePing, voiceSignal, voiceState, VOICE_DISCLOSURE, VOICE_MAX_MEMBERS,
  VOICE_PING_INTERVAL_MS, VOICE_SOCKET_URL,
} from "@/lib/sedx/voice-protocol";
import type { VoiceCandidate, VoiceClientMessage, VoicePeerInfo, VoiceServerMessage } from "@/lib/sedx/voice-protocol";

type RtcModule = typeof import("react-native-webrtc");
const inExpoGo = () => Constants.executionEnvironment === ExecutionEnvironment.StoreClient;

/** Never import/registerGlobals at module scope: Expo Go cannot load this native module. */
function loadNativeRtc(): RtcModule {
  if (inExpoGo()) throw new Error("O Expo Go não inclui WebRTC. Use o APK Android ou um development build com o módulo nativo.");
  if (Platform.OS === "web") throw new Error("Chamadas disponíveis apenas no aplicativo nativo.");
  if (!NativeModules.WebRTCModule) throw new Error("WebRTC não está neste build. Instale o APK compilado com react-native-webrtc; atualizar só o JavaScript não basta.");
  // This is the only runtime require. All other WebRTC imports above are type-only.
  return require("react-native-webrtc") as RtcModule;
}

interface Member extends VoicePeerInfo { name: string; connection: string; videoURL?: string }
interface RoomView {
  phase: "idle" | "joining" | "joined";
  message: string;
  error: boolean;
  max: number;
  members: Member[];
  muted: boolean;
  deaf: boolean;
  sharing: boolean;
  busy: boolean;
  speakerRequested: boolean;
  localScreenURL?: string;
}
const initialView = (): RoomView => ({
  phase: "idle", message: "Toque em Entrar para solicitar o microfone e conectar.", error: false,
  max: VOICE_MAX_MEMBERS, members: [], muted: true, deaf: false, sharing: false, busy: false,
  speakerRequested: true,
});
interface Peer {
  info: VoicePeerInfo;
  pc: RTCPeerConnection;
  audio: RTCRtpTransceiver;
  video: RTCRtpTransceiver;
  candidates: VoiceCandidate[];
  audioTracks: Set<MediaStreamTrack>;
  videoStream?: MediaStream;
  videoTrack?: MediaStreamTrack;
  videoLive: boolean;
  listeners: (() => void)[];
}

/** stop() alone only disables a native track; release() also stops the capturer/service. */
function releaseCapture(stream: MediaStream | null) {
  if (!stream) return;
  for (const track of stream.getTracks()) { try { track.stop(); } catch { /* already stopped */ } }
  try { stream.release(); } catch {
    for (const track of stream.getTracks()) { try { track.release(); } catch { /* already released */ } }
  }
}

/** One owner for WS, captures, timers and peers. Epoch checks invalidate every async continuation. */
class NativeVoiceRoom {
  rtc: RtcModule | null = null;
  view = initialView();
  private epoch = 0;
  private disposed = false;
  private focused = true;
  private socket: WebSocket | null = null;
  private id: string | null = null;
  private peers = new Map<string, Peer>();
  private mic: MediaStream | null = null;
  private screen: MediaStream | null = null;
  private micEnded: (() => void) | null = null;
  private screenEnded: (() => void) | null = null;
  private pingTimer: ReturnType<typeof setInterval> | null = null;
  private handshakeTimer: ReturnType<typeof setTimeout> | null = null;
  private permissionTimer: ReturnType<typeof setTimeout> | null = null;
  private pendingPermission = false;
  private controlBusy = false;
  private audioQueue: Promise<void> = Promise.resolve();
  private hasAudioMode = false;

  constructor(private update: (view: RoomView) => void) {}
  activate() { this.disposed = false; }
  private live(token: number) { return !this.disposed && token === this.epoch; }
  private peerLive(peer: Peer, token: number) {
    return this.live(token) && this.peers.get(peer.info.id) === peer && peer.pc.signalingState !== "closed";
  }
  private publish() {
    this.view = {
      ...this.view,
      busy: this.controlBusy || this.pendingPermission,
      localScreenURL: this.screen?.toURL(),
      members: Array.from(this.peers.values()).map(peer => ({
        ...peer.info, name: cleanVoiceName(peer.info.name),
        connection: peer.pc.connectionState,
        videoURL: peer.info.sharing && peer.videoLive ? peer.videoStream?.toURL() : undefined,
      })),
    };
    if (!this.disposed) this.update(this.view);
  }
  private notice(message: string, error = false) {
    this.view = { ...this.view, message, error }; this.publish();
  }
  setFocused(focused: boolean) {
    this.focused = focused;
    if (!focused) this.disconnect("Você saiu da tela de voz. A chamada foi encerrada.");
  }
  onAppState(state: AppStateStatus) {
    if (state === "active") return;
    // iOS permission dialogs can produce transient inactive. Never exempt actual background.
    if (state === "inactive" && this.pendingPermission) return;
    if (this.view.phase !== "idle" || this.pendingPermission) {
      this.disconnect("Chamada encerrada ao sair do primeiro plano. Toque em Entrar para voltar.");
    }
  }
  private beginPermission(token: number) {
    this.pendingPermission = true; this.publish();
    // The OS dialog cannot be dismissed from JS. Late results are always released.
    this.permissionTimer = setTimeout(() => {
      if (this.live(token)) this.disconnect("Permissão não concluída. Feche o diálogo do sistema e tente novamente.");
    }, 60_000);
  }
  private endPermission() {
    this.pendingPermission = false;
    if (this.permissionTimer) clearTimeout(this.permissionTimer);
    this.permissionTimer = null; this.publish();
  }
  private async microphone(token: number): Promise<MediaStream | null> {
    if (!this.rtc || this.pendingPermission) return null;
    this.beginPermission(token);
    try {
      const stream = await this.rtc.mediaDevices.getUserMedia({
        // v155 only types device/video constraints; use its native voice-processing defaults.
        audio: true, video: false,
      });
      if (!this.live(token) || AppState.currentState !== "active" || !this.focused) {
        releaseCapture(stream); return null;
      }
      if (!stream.getAudioTracks().length) { releaseCapture(stream); return null; }
      return stream;
    } catch {
      if (this.live(token)) this.notice("Microfone não liberado. Você pode entrar apenas para ouvir e ativá-lo depois.");
      return null;
    } finally { this.endPermission(); }
  }
  private adoptMicrophone(stream: MediaStream | null, token: number) {
    this.micEnded?.(); this.micEnded = null; this.mic = stream;
    const track = stream?.getAudioTracks()[0];
    if (!track) return;
    const ended = () => {
      if (!this.live(token) || this.mic !== stream) return;
      this.view = { ...this.view, muted: true }; this.publish();
      this.send(voiceState({ muted: true, speaking: false }), token);
      this.notice("O sistema interrompeu o microfone. Toque em Ativar microfone para tentar novamente.");
    };
    track.addEventListener("ended", ended);
    this.micEnded = () => track.removeEventListener("ended", ended);
  }
  private send(message: VoiceClientMessage, token = this.epoch): boolean {
    if (!this.live(token) || this.socket?.readyState !== WebSocket.OPEN) return false;
    try { this.socket.send(serializeVoiceMessage(message)); return true; } catch { return false; }
  }
  private sendDescription(peer: Peer, token: number) {
    if (!this.peerLive(peer, token) || !peer.pc.localDescription) return;
    // Native description instances have _sdp/_type; serialize via toJSON, not their internals.
    this.send(voiceSignal(peer.info.id, { description: peer.pc.localDescription.toJSON() }), token);
  }
  private routeAudio(speaker: boolean, token: number): Promise<void> {
    this.audioQueue = this.audioQueue.catch(() => {}).then(async () => {
      if (!this.live(token) || this.view.phase === "idle") return;
      this.hasAudioMode = true;
      try {
        await setAudioModeAsync({
          allowsRecording: true, playsInSilentMode: true, shouldPlayInBackground: false,
          shouldRouteThroughEarpiece: !speaker,
        });
        if (this.live(token)) { this.view = { ...this.view, speakerRequested: speaker }; this.publish(); }
      } catch {
        if (this.live(token)) this.notice("Não foi possível solicitar essa saída. Use os controles de áudio do dispositivo.");
      }
    });
    return this.audioQueue;
  }
  private resetAudio() {
    if (!this.hasAudioMode) return;
    this.hasAudioMode = false;
    // Serialize behind any in-flight route request, so a late request cannot re-enable recording.
    this.audioQueue = this.audioQueue.catch(() => {}).then(async () => {
      try {
        await setAudioModeAsync({
          allowsRecording: false, playsInSilentMode: true, shouldPlayInBackground: false,
          shouldRouteThroughEarpiece: false,
        });
      } catch { /* system retains its own routing */ }
    });
  }

  async join(identity: { name: string; avatar: string }) {
    if (this.disposed || this.view.phase !== "idle" || this.pendingPermission || this.controlBusy) return;
    if (!this.focused || AppState.currentState !== "active") {
      this.notice("Abra a sala em primeiro plano para entrar."); return;
    }
    try { this.rtc = loadNativeRtc(); }
    catch (error) { this.notice(error instanceof Error ? error.message : "WebRTC indisponível neste build.", true); return; }
    const token = ++this.epoch;
    this.view = { ...initialView(), phase: "joining", message: "Solicitando microfone…" }; this.publish();
    const stream = await this.microphone(token);
    if (!this.live(token)) { releaseCapture(stream); return; }
    if (AppState.currentState !== "active" || !this.focused) {
      releaseCapture(stream); this.disconnect("Entrada cancelada fora do primeiro plano."); return;
    }
    this.adoptMicrophone(stream, token);
    this.view = { ...this.view, muted: !stream, message: stream ? "Conectando à sala…" : "Conectando apenas para ouvir…" };
    this.publish();
    try {
      const ws = new WebSocket(VOICE_SOCKET_URL);
      this.socket = ws;
      let queue = Promise.resolve();
      let queued = 0;
      this.handshakeTimer = setTimeout(() => {
        if (this.live(token)) this.disconnect("A sala não respondeu. Verifique a conexão e tente novamente.", true);
      }, 20_000);
      ws.onopen = () => {
        if (!this.live(token) || this.socket !== ws) { try { ws.close(); } catch { /* closed */ } return; }
        if (!this.send(voiceJoin(identity.name, identity.avatar, this.view.muted), token)) {
          this.disconnect("Não foi possível entrar na sala.", true); return;
        }
        this.pingTimer = setInterval(() => {
          if (!this.send(voicePing(), token) && this.live(token)) this.disconnect("Sinalização perdida. Entre novamente.", true);
        }, VOICE_PING_INTERVAL_MS);
      };
      ws.onmessage = event => {
        if (!this.live(token)) return;
        const message = parseVoiceMessage(event.data);
        if (!message) return;
        if (++queued > 256) { this.disconnect("Excesso de mensagens de sinalização. Conexão encerrada.", true); return; }
        queue = queue.then(async () => {
          if (this.live(token)) await this.handle(message, token);
        }).catch(() => {
          if (this.live(token)) this.notice("Uma conexão P2P falhou. Redes restritas podem exigir TURN, que esta sala não possui.", true);
        }).finally(() => { queued--; });
      };
      ws.onerror = () => {
        if (this.live(token)) this.disconnect("Falha na sinalização. Verifique a rede e entre novamente.", true);
      };
      ws.onclose = event => {
        if (!this.live(token)) return;
        this.disconnect(event.code === 4000 || event.reason === "full"
          ? `Sala cheia: limite de ${this.view.max} participantes.`
          : "A sinalização foi desconectada. A chamada terminou; toque em Entrar para tentar novamente.", true);
      };
    } catch { this.disconnect("Não foi possível abrir a conexão com a sala.", true); }
  }

  private async ensurePeer(info: VoicePeerInfo, token: number): Promise<Peer | null> {
    if (!this.live(token) || !this.rtc || this.view.phase !== "joined" || info.id === this.id) return null;
    const old = this.peers.get(info.id);
    if (old) { old.info = { ...old.info, ...info }; this.publish(); return old; }
    if (this.peers.size >= this.view.max - 1 || this.peers.size >= VOICE_MAX_MEMBERS - 1) return null;
    const pc = new this.rtc.RTCPeerConnection({ iceServers: voiceIceServers() });
    let peer: Peer;
    try {
      peer = {
        info: { ...info, name: cleanVoiceName(info.name) }, pc,
        audio: pc.addTransceiver("audio", { direction: "sendrecv" }),
        video: pc.addTransceiver("video", { direction: "sendrecv" }),
        candidates: [], audioTracks: new Set(), videoLive: false, listeners: [],
      };
    } catch (error) { pc.close(); throw error; }
    this.peers.set(info.id, peer);
    pc.addEventListener("icecandidate", event => {
      if (this.peerLive(peer, token) && event.candidate) {
        this.send(voiceSignal(info.id, { candidate: event.candidate.toJSON() }), token);
      }
    });
    pc.addEventListener("track", event => {
      if (this.peerLive(peer, token) && event.track) this.remoteTrack(peer, event.track, token);
    });
    pc.addEventListener("connectionstatechange", () => {
      if (!this.peerLive(peer, token)) return;
      this.publish();
      if (pc.connectionState === "failed") {
        this.notice(`Áudio P2P de ${cleanVoiceName(peer.info.name)} não conectou. Esta sala não possui TURN; tente outra rede.`, true);
      }
    });
    const audioTrack = this.mic?.getAudioTracks()[0];
    if (audioTrack) await peer.audio.sender.replaceTrack(audioTrack);
    if (!this.peerLive(peer, token)) return null;
    const screenTrack = this.screen?.getVideoTracks()[0];
    if (screenTrack) await peer.video.sender.replaceTrack(screenTrack);
    if (!this.peerLive(peer, token)) return null;
    this.publish(); return peer;
  }
  private remoteTrack(peer: Peer, track: MediaStreamTrack, token: number) {
    if (!this.rtc) return;
    if (track.kind === "audio") {
      track.enabled = !this.view.deaf; peer.audioTracks.add(track);
      const ended = () => { peer.audioTracks.delete(track); };
      track.addEventListener("ended", ended);
      peer.listeners.push(() => track.removeEventListener("ended", ended));
      // Remote audio plays through WebRTC's native audio device; it needs no DOM/RTCView.
    } else if (track.kind === "video") {
      if (peer.videoStream) { try { peer.videoStream.release(false); } catch { /* detached */ } }
      peer.videoStream = new this.rtc.MediaStream([track]); peer.videoTrack = track;
      peer.videoLive = !track.muted && track.readyState !== "ended";
      const refresh = () => {
        if (!this.peerLive(peer, token) || peer.videoTrack !== track) return;
        peer.videoLive = !track.muted && track.readyState !== "ended"; this.publish();
      };
      for (const event of ["mute", "unmute", "ended"] as const) {
        track.addEventListener(event, refresh);
        peer.listeners.push(() => track.removeEventListener(event, refresh));
      }
    }
    this.publish();
  }
  private async offer(peer: Peer, token: number) {
    if (!this.peerLive(peer, token) || peer.pc.signalingState !== "stable") return;
    const offer = await peer.pc.createOffer();
    if (!this.peerLive(peer, token)) return;
    await peer.pc.setLocalDescription(offer);
    this.sendDescription(peer, token);
  }
  private async handle(message: VoiceServerMessage, token: number) {
    if (!this.live(token)) return;
    if (message.type === "full") {
      this.view = { ...this.view, max: message.max };
      this.disconnect(`Sala cheia: limite de ${message.max} participantes.`, true); return;
    }
    if (message.type === "welcome") {
      if (this.view.phase !== "joining") return;
      if (this.handshakeTimer) clearTimeout(this.handshakeTimer);
      this.handshakeTimer = null; this.id = message.id;
      this.view = {
        ...this.view, phase: "joined",
        max: message.max,
        message: this.mic ? "Na sala. O estado dos participantes não confirma sua identidade."
          : "Na sala apenas para ouvir. Toque em Ativar microfone se quiser falar.",
      };
      this.publish();
      this.send(voiceState({ deaf: this.view.deaf, sharing: false, speaking: false }), token);
      void this.routeAudio(this.view.speakerRequested, token);
      // As in the source: newcomer offers to existing peers; peer-joined waits for offers.
      for (const info of message.peers) {
        if (!this.live(token)) break;
        try { const peer = await this.ensurePeer(info, token); if (peer) await this.offer(peer, token); }
        catch { if (this.live(token)) this.notice(`Não foi possível conectar ${cleanVoiceName(info.name)}.`, true); }
      }
      return;
    }
    if (this.view.phase !== "joined") return;
    if (message.type === "peer-left") { this.removePeer(message.id); this.publish(); return; }
    if (message.type === "peer-joined" || message.type === "peer-state") {
      await this.ensurePeer(message.peer, token); return;
    }
    if (message.type !== "signal") return;
    const peer = await this.ensurePeer({ id: message.from }, token);
    if (!peer || !this.peerLive(peer, token)) return;
    if (message.data.description) {
      await peer.pc.setRemoteDescription(new this.rtc!.RTCSessionDescription(message.data.description));
      if (!this.peerLive(peer, token)) return;
      const pending = peer.candidates.splice(0);
      for (const candidate of pending) {
        if (!this.peerLive(peer, token)) return;
        try { await peer.pc.addIceCandidate(new this.rtc!.RTCIceCandidate(candidate)); } catch { /* stale candidate */ }
      }
      if (message.data.description.type === "offer") {
        const answer = await peer.pc.createAnswer();
        if (!this.peerLive(peer, token)) return;
        await peer.pc.setLocalDescription(answer);
        this.sendDescription(peer, token);
      }
    } else if (message.data.candidate) {
      if (peer.pc.remoteDescription) await peer.pc.addIceCandidate(new this.rtc!.RTCIceCandidate(message.data.candidate));
      else if (peer.candidates.length < 128) peer.candidates.push(message.data.candidate);
    }
  }

  async toggleMute() {
    if (this.view.phase !== "joined" || this.controlBusy || this.pendingPermission) return;
    const token = this.epoch; this.controlBusy = true; this.publish();
    try {
      let track = this.mic?.getAudioTracks().find(item => item.readyState !== "ended");
      let muted = !this.view.muted;
      if (!track) {
        this.micEnded?.(); this.micEnded = null;
        releaseCapture(this.mic); this.mic = null;
        const stream = await this.microphone(token);
        if (!this.live(token)) { releaseCapture(stream); return; }
        if (!stream) return;
        this.adoptMicrophone(stream, token); track = stream.getAudioTracks()[0]; muted = false;
        if (!track) return;
        for (const peer of this.peers.values()) {
          if (!this.live(token)) return;
          try { await peer.audio.sender.replaceTrack(track); }
          catch { if (this.live(token)) this.notice(`Microfone não conectado a ${cleanVoiceName(peer.info.name)}.`, true); }
        }
      }
      if (!this.live(token)) return;
      for (const item of this.mic?.getAudioTracks() || []) item.enabled = !muted;
      this.view = { ...this.view, muted }; this.publish();
      this.send(voiceState({ muted, ...(muted ? { speaking: false } : {}) }), token);
    } finally { this.controlBusy = false; this.publish(); }
  }
  toggleDeaf() {
    if (this.view.phase !== "joined" || this.controlBusy || this.pendingPermission) return;
    const deaf = !this.view.deaf;
    for (const peer of this.peers.values()) for (const track of peer.audioTracks) track.enabled = !deaf;
    this.view = { ...this.view, deaf }; this.publish(); this.send(voiceState({ deaf }));
  }
  async toggleSpeaker() {
    if (this.view.phase !== "joined" || this.controlBusy || this.pendingPermission) return;
    const token = this.epoch; this.controlBusy = true; this.publish();
    try {
      await this.routeAudio(!this.view.speakerRequested, token);
      if (this.live(token)) this.notice("Saída solicitada. Fones, Bluetooth e o sistema podem prevalecer; confira onde o áudio está tocando.");
    } finally { this.controlBusy = false; this.publish(); }
  }
  private async projectionPermissions(): Promise<boolean> {
    if (Platform.OS !== "android") return false;
    const version = Number(Platform.Version);
    // These are install-time/manifest permissions, NOT runtime requests. The parent owns config.
    if (version >= 28 && !await PermissionsAndroid.check("android.permission.FOREGROUND_SERVICE" as Permission)) return false;
    if (version >= 34 && !await PermissionsAndroid.check("android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION" as Permission)) return false;
    return true;
  }
  async toggleScreen() {
    if (this.view.phase !== "joined" || this.controlBusy || this.pendingPermission) return;
    const token = this.epoch; this.controlBusy = true; this.publish();
    try {
      if (this.screen) { await this.stopScreen(token); return; }
      if (Platform.OS !== "android" || !this.rtc?.mediaDevices.getDisplayMedia) {
        this.notice("Compartilhamento de tela indisponível neste build/dispositivo. No iOS seria necessária configuração ReplayKit adicional."); return;
      }
      if (!await this.projectionPermissions()) {
        if (this.live(token)) this.notice("O APK precisa declarar FOREGROUND_SERVICE e, no Android 14+, FOREGROUND_SERVICE_MEDIA_PROJECTION. Recompile com essas permissões para compartilhar a tela.", true);
        return;
      }
      if (!this.live(token) || !this.focused || AppState.currentState !== "active") return;
      this.beginPermission(token);
      let stream: MediaStream;
      try {
        // v155 uses Android-specific constraints, not browser video/audio constraints.
        // Its MediaProjectionService starts only after the system's explicit consent.
        stream = await this.rtc.mediaDevices.getDisplayMedia({ android: { resolutionScale: 0.6 } });
      } catch {
        if (this.live(token)) this.notice("Captura cancelada ou indisponível. Verifique a permissão de tela e o serviço de foreground do APK.");
        return;
      } finally { this.endPermission(); }
      if (!this.live(token) || !this.focused || AppState.currentState !== "active") {
        releaseCapture(stream); return;
      }
      const track = stream.getVideoTracks()[0];
      if (!track) { releaseCapture(stream); this.notice("O sistema não retornou uma tela para compartilhar."); return; }
      this.screen = stream;
      const ended = () => { if (this.live(token) && this.screen === stream) void this.stopScreen(token); };
      track.addEventListener("ended", ended);
      this.screenEnded = () => track.removeEventListener("ended", ended);
      try {
        for (const peer of this.peers.values()) {
          if (!this.live(token) || this.screen !== stream) return;
          await peer.video.sender.replaceTrack(track);
        }
        if (!this.live(token) || this.screen !== stream) return;
        this.view = { ...this.view, sharing: true }; this.publish();
        this.send(voiceState({ sharing: true }), token);
        this.notice("Tela compartilhada. Não exponha senhas, dados pessoais ou informações de outros alunos.");
      } catch {
        if (this.live(token)) { await this.stopScreen(token); this.notice("Não foi possível enviar a tela aos participantes.", true); }
      }
    } finally { this.controlBusy = false; this.publish(); }
  }
  private async stopScreen(token: number) {
    const stream = this.screen; this.screen = null;
    this.screenEnded?.(); this.screenEnded = null;
    // Stop the capturer immediately, before potentially slow sender promises.
    releaseCapture(stream);
    if (!this.live(token)) return;
    this.view = { ...this.view, sharing: false }; this.publish();
    this.send(voiceState({ sharing: false }), token);
    for (const peer of this.peers.values()) {
      if (!this.live(token)) return;
      try { await peer.video.sender.replaceTrack(null); } catch { /* closing peer */ }
    }
  }
  private removePeer(id: string) {
    const peer = this.peers.get(id); if (!peer) return;
    this.peers.delete(id);
    for (const remove of peer.listeners) { try { remove(); } catch { /* already removed */ } }
    peer.listeners = []; peer.candidates = [];
    for (const track of peer.audioTracks) { try { track.enabled = false; } catch { /* closed */ } }
    peer.audioTracks.clear();
    if (peer.videoStream) { try { peer.videoStream.release(false); } catch { /* remote stream */ } }
    try { peer.pc.close(); } catch { /* already closed */ }
  }
  disconnect(message = "Você saiu da sala. Microfone e tela foram liberados.", error = false) {
    ++this.epoch;
    if (this.pingTimer) clearInterval(this.pingTimer);
    if (this.handshakeTimer) clearTimeout(this.handshakeTimer);
    if (this.permissionTimer) clearTimeout(this.permissionTimer);
    this.pingTimer = null; this.handshakeTimer = null; this.permissionTimer = null;
    const ws = this.socket; this.socket = null;
    if (ws) {
      ws.onopen = null; ws.onmessage = null; ws.onerror = null; ws.onclose = null;
      // No invented leave message: the reference leaves by closing its WebSocket.
      try { ws.close(1000, "left"); } catch { /* already closed */ }
    }
    this.micEnded?.(); this.micEnded = null;
    this.screenEnded?.(); this.screenEnded = null;
    for (const id of Array.from(this.peers.keys())) this.removePeer(id);
    releaseCapture(this.mic); releaseCapture(this.screen);
    this.mic = null; this.screen = null; this.id = null;
    this.resetAudio();
    // Keep pendingPermission/controlBusy until their original promises settle.
    this.view = { ...initialView(), max: this.view.max, message, error }; this.publish();
  }
  dispose() { this.disposed = true; this.disconnect(); }
}

const connectionLabel = (state: string) => ({
  new: "Preparando P2P", connecting: "Conectando P2P", connected: "P2P conectado",
  disconnected: "P2P instável", failed: "P2P falhou", closed: "Encerrado",
}[state] || "Preparando P2P");

export function VoiceScreen() {
  const { session, profile } = useSedx();
  const [view, setView] = useState<RoomView>(initialView);
  const [room] = useState(() => new NativeVoiceRoom(setView));
  const identity = voiceIdentity(profile, session);
  const expoGo = inExpoGo();
  const RTCView = room.rtc?.RTCView;
  const joined = view.phase === "joined";
  const count = joined ? view.members.length + 1 : 0;
  useEffect(() => {
    room.activate();
    const listener = AppState.addEventListener("change", state => room.onAppState(state));
    return () => { listener.remove(); room.dispose(); };
  }, [room]);
  useFocusEffect(useCallback(() => {
    room.setFocused(true);
    return () => room.setFocused(false);
  }, [room]));
  useEffect(() => {
    // Local access gate is not server-side authentication. Do not leak session tokens to voice.
    if (!session) room.disconnect("Entre no SEDX antes de usar a sala de voz.");
    return () => { room.disconnect("Sessão alterada. A chamada foi encerrada."); };
  }, [room, session?.usuario]);

  return (
    <Page title="Sala de voz" eyebrow="SEDX · ÁUDIO P2P" subtitle="Entre por escolha própria. Até 20 participantes.">
      {expoGo ? <Notice message="O Expo Go não inclui react-native-webrtc e não pode fazer esta chamada. O APK release compilado com o módulo nativo oferece a sala; use esse APK ou um development build. Nenhum microfone foi solicitado." /> : null}
      <Card title="sala-de-voz">
        <Row>
          <Pill label={joined ? "Na sala · sinalização conectada" : view.phase === "joining" ? "Entrando…" : "Fora da sala"} color={joined ? C.green : C.muted} />
          <Pill label={`${count}/${view.max}`} />
        </Row>
        <Body>O estado “na sala” confirma apenas a sinalização. Confira o estado P2P de cada participante abaixo.</Body>
        {!joined && view.phase !== "joining" ? (
          <Button label="Entrar na sala" disabled={expoGo || !session || view.busy} onPress={() => { void room.join(identity); }} />
        ) : <Button label={joined ? "Sair da sala" : "Cancelar entrada"} variant="danger" onPress={() => room.disconnect()} />}
      </Card>
      <Notice message={view.message} kind={view.error ? "error" : "info"} />
      {joined ? (
        <>
          <Card title="Seus controles">
            <Body>{identity.name} (você) · {view.muted ? "Microfone mutado" : "Microfone ativo"}</Body>
            <Row>
              <Button label={view.muted ? "Ativar microfone" : "Mutar"} variant="secondary" disabled={view.busy} onPress={() => { void room.toggleMute(); }} />
              <Button label={view.deaf ? "Ouvir sala" : "Silenciar saída"} variant="secondary" disabled={view.busy} onPress={() => room.toggleDeaf()} />
            </Row>
            <Button label={view.speakerRequested ? "Solicitar auricular" : "Solicitar alto-falante"} variant="secondary" disabled={view.busy} onPress={() => { void room.toggleSpeaker(); }} />
            <Body>Saída solicitada: {view.speakerRequested ? "alto-falante" : "auricular"}. Fones, Bluetooth e o sistema podem prevalecer; a rota real não é detectada pelo app.</Body>
            <Button label={view.sharing ? "Parar compartilhamento" : "Compartilhar tela"} variant={view.sharing ? "danger" : "secondary"} disabled={view.busy || Platform.OS !== "android"} onPress={() => { void room.toggleScreen(); }} />
            <Body>Ao compartilhar, confirme a captura no sistema. A chamada e a captura encerram ao ir para o segundo plano. Uma permissão que coloque o app em segundo plano também cancela a operação; não há retomada automática.</Body>
            {view.localScreenURL && RTCView ? (
              <View style={styles.screen} accessibilityLabel="Prévia da sua tela compartilhada">
                <RTCView streamURL={view.localScreenURL} style={styles.video} objectFit="contain" mirror={false} />
              </View>
            ) : null}
          </Card>
          {view.members.length === 0 ? <Empty title="Só você na sala" description="Outros participantes entram voluntariamente pelo mesmo canal." /> : null}
          {view.members.map(member => (
            <Card key={member.id} title={member.name}>
              <Row>
                <Pill label={member.muted ? "Microfone mutado" : "Microfone declarado ativo"} color={member.muted ? C.muted : C.green} />
                <Pill label={connectionLabel(member.connection)} color={member.connection === "connected" ? C.green : C.muted} />
              </Row>
              {member.deaf ? <Body>Saída silenciada pelo participante.</Body> : null}
              {member.speaking ? <Body>Falando (estado declarado pelo participante).</Body> : null}
              {member.sharing && member.videoURL && RTCView ? (
                <View style={styles.screen} accessibilityLabel={`Tela compartilhada por ${member.name}`}>
                  <RTCView streamURL={member.videoURL} style={styles.video} objectFit="contain" mirror={false} />
                </View>
              ) : member.sharing ? <Body>Aguardando o vídeo da tela remota…</Body> : null}
            </Card>
          ))}
        </>
      ) : null}
      <Notice message={VOICE_DISCLOSURE} />
    </Page>
  );
}
const styles = StyleSheet.create({
  screen: { width: "100%", aspectRatio: 16 / 10, backgroundColor: C.bg, borderColor: C.border, borderWidth: 1, borderRadius: 12, overflow: "hidden" },
  video: { flex: 1 },
});
export default VoiceScreen;
