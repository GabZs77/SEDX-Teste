import React, { useEffect, useState } from "react";
import { ActivityIndicator, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Image } from "expo-image";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Ionicons } from "@expo/vector-icons";
import { Button, C, Input, Notice } from "./ui";
import { useSedx } from "@/lib/sedx/session";
import { makeUsuario, errorMessage } from "@/lib/sedx/contracts";
const SAVED = "sedx_native_saved_ra";
export function LoginScreen() {
  const { signIn, authError, booting } = useSedx();
  const [ra, setRa] = useState(""); const [digit, setDigit] = useState(""); const [uf, setUf] = useState("SP");
  const [senha, setSenha] = useState(""); const [show, setShow] = useState(false);
  const [remember, setRemember] = useState(true); const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState<any>(null);
  useEffect(() => { void AsyncStorage.getItem(SAVED).then(v => { if (v) { try { setSaved(JSON.parse(v)); } catch {} } }); }, []);
  async function login() {
    if (busy) return; setError(null);
    try {
      const usuario = makeUsuario(ra, digit, uf);
      if (!senha) throw new Error("Digite a senha da Secretaria Escolar Digital.");
      setBusy(true);
      await signIn(usuario, senha, remember);
      if (remember) await AsyncStorage.setItem(SAVED, JSON.stringify({ ra, digit, uf }));
      else await AsyncStorage.removeItem(SAVED);
      setSenha("");
    } catch (e) { setError(errorMessage(e)); }
    finally { setBusy(false); }
  }
  if (booting) return <SafeAreaView style={s.safe}><View style={s.loading}><Image source={require("@/assets/images/sedx-logo.png")} style={{ width: 180, height: 110 }} contentFit="contain" /><ActivityIndicator color={C.accent} /><Text style={s.help}>Restaurando sua sessão...</Text></View></SafeAreaView>;
  return <SafeAreaView style={s.safe}><KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : "height"}><ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={s.scroll}>
    <View style={s.brand}><Image source={require("@/assets/images/sedx-logo.png")} style={s.logo} contentFit="contain" accessibilityLabel="SEDX Aluno" /><Text style={s.brandTag}>SUA VIDA ESCOLAR, CONECTADA.</Text></View>
    <View style={s.panel}>
      <Text style={s.eyebrow}>ÁREA DO ALUNO</Text><Text style={s.title}>Entre na sua conta.</Text>
      <Text style={s.description}>Use os mesmos dados da Secretaria Escolar Digital para acessar seu SEDX.</Text>
      {(error || authError) && <Notice message={error || authError || ""} kind="error" />}
      {saved && <Pressable accessibilityRole="button" onPress={() => { setRa(saved.ra || ""); setDigit(saved.digit || ""); setUf(saved.uf || "SP"); }} style={s.saved}><Ionicons name="person-circle-outline" size={22} color={C.text} /><View style={{ flex: 1 }}><Text style={s.savedTitle}>Usar conta salva</Text><Text style={s.help}>RA {saved.ra} · {saved.uf}</Text></View><Ionicons name="chevron-forward" size={18} color={C.muted} /></Pressable>}
      <View style={s.formRow}><View style={{ flex: 1 }}><Input label="RA" value={ra} onChangeText={t => setRa(t.replace(/\D/g, ""))} keyboardType="number-pad" autoCapitalize="none" placeholder="Seu registro do aluno" maxLength={20} autoComplete="username" editable={!busy} /></View><View style={{ width: 65 }}><Input label="Dígito" value={digit} onChangeText={setDigit} placeholder="0" maxLength={1} autoCapitalize="characters" editable={!busy} /></View><View style={{ width: 60 }}><Input label="UF" value={uf} onChangeText={setUf} placeholder="SP" autoCapitalize="characters" maxLength={2} editable={!busy} /></View></View>
      <View style={{ gap: 7 }}><Text style={s.label}>Senha</Text><View style={s.password}><View style={{ flex: 1 }}><Input value={senha} onChangeText={setSenha} secureTextEntry={!show} placeholder="Sua senha da SED" autoComplete="current-password" autoCapitalize="none" autoCorrect={false} onSubmitEditing={() => void login()} returnKeyType="go" editable={!busy} /></View><Pressable accessibilityRole="button" accessibilityLabel={show ? "Ocultar senha" : "Mostrar senha"} onPress={() => setShow(!show)} style={s.eye}><Ionicons name={show ? "eye-off-outline" : "eye-outline"} size={21} color={C.muted} /></Pressable></View></View>
      <Pressable accessibilityRole="checkbox" accessibilityState={{ checked: remember }} onPress={() => setRemember(!remember)} style={s.remember}><Ionicons name={remember ? "checkbox" : "square-outline"} size={21} color={C.text} /><Text style={s.rememberText}>Manter minha sessão neste aparelho</Text></Pressable>
      <Button label={busy ? "Entrando..." : "Entrar na minha conta"} onPress={login} loading={busy} icon="arrow-forward" />
      <View style={s.security}><Ionicons name="lock-closed-outline" size={14} color={C.muted} /><Text style={s.securityText}>Sua senha não é armazenada. A autenticação usa o mesmo serviço do site.</Text></View>
    </View>
    <Text style={s.footer}>SEDX Aluno · Aplicativo nativo</Text>
  </ScrollView></KeyboardAvoidingView></SafeAreaView>;
}
const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg }, scroll: { flexGrow: 1, alignItems: "center", justifyContent: "center", padding: 22, paddingVertical: 30, gap: 25 },
  brand: { alignItems: "center", gap: 12 }, logo: { width: 220, height: 142 }, brandTag: { color: C.muted, letterSpacing: 2, fontSize: 9, fontWeight: "600" },
  panel: { width: "100%", maxWidth: 460, padding: 22, backgroundColor: C.surface, borderWidth: 1, borderColor: C.border, borderRadius: 22, gap: 17 }, eyebrow: { fontSize: 10, color: C.muted, letterSpacing: 1.8, fontWeight: "600" }, title: { fontSize: 27, color: C.text, fontWeight: "800", letterSpacing: -0.8 }, description: { color: C.muted, fontSize: 13, lineHeight: 21, marginBottom: 4 },
  formRow: { flexDirection: "row", gap: 9 }, password: { position: "relative", flexDirection: "row" }, eye: { position: "absolute", right: 0, width: 44, height: 48, alignItems: "center", justifyContent: "center" }, label: { fontSize: 12, fontWeight: "600", color: C.muted },
  remember: { flexDirection: "row", alignItems: "center", gap: 10, minHeight: 40 }, rememberText: { color: C.muted, fontSize: 12, flex: 1 }, security: { flexDirection: "row", gap: 8, alignItems: "flex-start" }, securityText: { color: C.muted, flex: 1, fontSize: 10, lineHeight: 16 },
  footer: { color: "#717171", fontSize: 10 }, saved: { borderWidth: 1, borderColor: C.border, padding: 13, borderRadius: 12, flexDirection: "row", gap: 10, alignItems: "center" }, savedTitle: { fontSize: 12, fontWeight: "600", color: C.text }, help: { fontSize: 11, color: C.muted, marginTop: 3 }, loading: { flex: 1, alignItems: "center", justifyContent: "center", gap: 20 },
});
