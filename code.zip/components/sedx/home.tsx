import React from "react";
import { Pressable, StyleSheet, Text, View, useWindowDimensions } from "react-native";
import { useSedx } from "@/lib/sedx/session";
import { firstName } from "@/lib/sedx/contracts";
import { C, Page, Card, Body, Button, Empty, Icon, Loading, Notice, Pill, Row, go } from "./ui";
export function HomeScreen() {
  const { session, dashboard, dashboardLoading, dashboardError, refreshDashboard, siteState } = useSedx();
  const { width } = useWindowDimensions();
  const tasks = Array.isArray(dashboard?.tarefas) ? dashboard.tarefas : [];
  const agenda = Array.isArray(dashboard?.agenda) ? dashboard.agenda : [];
  const today = new Intl.DateTimeFormat("en-CA", { timeZone: "America/Sao_Paulo", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
  const lessons = agenda.filter((a: any) => a.data === today && a.tipo !== "intervalo");
  const aluno = dashboard?.aluno || {};
  const nome = aluno.nomeAluno || aluno.nome || session?.nome || "Aluno";
  const school = aluno.nomeEscola || aluno.NomeEscola || session?.escola;
  const shortcuts = [
    { title: "Atividades", text: "Suas tarefas e próximos prazos", icon: "checkbox-outline", path: "/tarefas" },
    { title: "Apostilas", text: "Materiais para estudar", icon: "book-outline", path: "/apostilas" },
    { title: "Flash IA", text: "Entenda o que está estudando", icon: "sparkles-outline", path: "/ia" },
    { title: "Comunidade", text: "Converse com outros alunos", icon: "chatbubbles-outline", path: "/comunidade" },
  ];
  return <Page title={`Olá, ${firstName(nome)}.`} eyebrow="SEU PAINEL" subtitle={school || "Agenda, presença e tarefas em um só lugar."} onRefresh={refreshDashboard}>
    {dashboardError && <Notice message={dashboardError} kind="error" />}
    {dashboardLoading && !dashboard && <Loading label="Buscando seus dados na Secretaria..." />}
    <Card style={s.hero}><Row><Pill label="VISÃO GERAL" /><View style={{ flex: 1 }} /><Icon name="school-outline" /></Row><Text style={s.heroTitle}>Um passo de cada vez.{"\n"}Seu futuro começa aqui.</Text><Body>Acompanhe o que precisa de atenção e continue de onde parou.</Body>
      <View style={s.metrics}><View style={s.metric}><Text style={s.number}>{dashboard?.tarefasApiOk === false || !dashboard ? "—" : String(dashboard.pendencias ?? tasks.length)}</Text><Text style={s.metricLabel}>tarefas pendentes</Text></View><View style={s.metric}><Text style={s.number}>{dashboard?.faltas == null ? "—" : String(dashboard.faltas)}</Text><Text style={s.metricLabel}>faltas no bimestre</Text></View><View style={s.metric}><Text style={s.number}>{dashboard ? String(lessons.length) : "—"}</Text><Text style={s.metricLabel}>aulas hoje</Text></View></View>
      <Button label="Ver minhas atividades" icon="arrow-forward" onPress={() => go("/tarefas")} />
    </Card>
    <Text style={s.section}>Seu próximo passo</Text>
    {dashboard?.tarefasApiOk === false ? <Notice message="Não foi possível consultar suas tarefas. Atualize o painel para tentar novamente." kind="error" /> : tasks.length > 0 ? <Card><Pill label={tasks[0].subject || "ATIVIDADE PENDENTE"} /><Text style={s.taskTitle}>{tasks[0].title}</Text><Body>{tasks[0].roomLabel || ""}</Body><Button label="Abrir atividade" variant="secondary" onPress={() => go(`/atividade?taskId=${encodeURIComponent(tasks[0].id)}&room=${encodeURIComponent(tasks[0].room || "")}`)} /></Card> : dashboard && <Card><Empty title="Nenhuma tarefa pendente" description="Quando houver novas atividades, elas aparecerão aqui." /></Card>}
    <Text style={s.section}>Atalhos principais</Text><View style={s.shortcuts}>{shortcuts.map(item => <Pressable key={item.path} accessibilityRole="button" onPress={() => go(item.path)} style={[s.shortcut, { width: width < 390 ? "100%" : "48%" }]}><View style={s.shortcutIcon}><Icon name={item.icon as any} size={22} /></View><Text style={s.shortcutTitle}>{item.title}</Text><Text style={s.shortcutText}>{item.text}</Text><Icon name="arrow-forward" color={C.muted} size={17} /></Pressable>)}</View>
    {lessons.length > 0 && <Card title="Hoje na sua agenda">{lessons.slice(0, 3).map((a: any) => <View key={a.id} style={s.lesson}><Text style={s.lessonTime}>{a.horaInicio || "—"}</Text><View style={{ flex: 1 }}><Text style={s.taskTitle}>{a.nomeDisciplina}</Text><Body>{a.horaFim ? `Até ${a.horaFim}` : a.descricaoTurma}</Body></View></View>)}<Button label="Ver agenda completa" variant="secondary" onPress={() => go("/agenda")} /></Card>}
    {siteState?.notifications?.[0] && <Card title="Último anúncio"><Text style={s.taskTitle}>{siteState.notifications[0].title}</Text><Body>{siteState.notifications[0].description}</Body><Button label="Ver anúncios" variant="secondary" onPress={() => go("/avisos")} /></Card>}
    <Pressable onPress={() => go("/ajuda")} accessibilityRole="button" style={s.help}><Icon name="help-circle-outline" color={C.muted} /><View style={{ flex: 1 }}><Text style={s.taskTitle}>Precisando de uma mão?</Text><Body>A Central de ajuda está aqui para você.</Body></View><Icon name="chevron-forward" color={C.muted} /></Pressable>
  </Page>;
}
const s = StyleSheet.create({ hero: { backgroundColor: "#292929", borderColor: "#5d5d5d" }, heroTitle: { color: C.text, fontSize: 25, lineHeight: 33, fontWeight: "800", letterSpacing: -0.8 }, metrics: { flexDirection: "row", gap: 8, paddingVertical: 10 }, metric: { flex: 1, gap: 7 }, number: { color: C.text, fontSize: 30, fontWeight: "800", letterSpacing: -1 }, metricLabel: { color: C.muted, fontSize: 10, lineHeight: 15 }, section: { fontSize: 16, color: C.text, fontWeight: "700", marginTop: 7 }, taskTitle: { color: C.text, fontSize: 14, fontWeight: "600", lineHeight: 21 }, shortcuts: { flexDirection: "row", flexWrap: "wrap", gap: 12, justifyContent: "space-between" }, shortcut: { padding: 18, gap: 12, backgroundColor: C.surface, borderWidth: 1, borderColor: C.border, borderRadius: 17 }, shortcutIcon: { width: 40, height: 40, borderRadius: 11, alignItems: "center", justifyContent: "center", backgroundColor: C.raised }, shortcutTitle: { fontSize: 14, color: C.text, fontWeight: "700" }, shortcutText: { color: C.muted, fontSize: 11, lineHeight: 18 }, lesson: { flexDirection: "row", alignItems: "center", gap: 14, paddingVertical: 7 }, lessonTime: { color: C.text, fontSize: 16, fontWeight: "700", width: 50 }, help: { paddingVertical: 17, flexDirection: "row", alignItems: "center", gap: 12 } });
