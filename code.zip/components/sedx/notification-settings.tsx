import React, { useState } from "react";
import { Linking } from "react-native";
import { Button, Card, Body, Notice, Row } from "./ui";
import { registerNativePush, unregisterNativePush, nativeNotificationsAvailable } from "@/lib/sedx/notifications";
import { errorMessage } from "@/lib/sedx/contracts";
export function NotificationSettings() {
  const [busy, setBusy] = useState(false); const [message, setMessage] = useState<string | null>(null); const [error, setError] = useState<string | null>(null);
  async function action(enable: boolean) {
    setBusy(true); setMessage(null); setError(null);
    try { if (enable) await registerNativePush(); else await unregisterNativePush(); setMessage(enable ? "Este aparelho foi registrado para receber avisos do SEDX. A entrega depende das permissões do Android e do serviço push." : "Registro deste aparelho removido."); }
    catch (e) { setError(errorMessage(e)); } finally { setBusy(false); }
  }
  return <Card title="Notificações neste aparelho"><Body>Receba comunicados, novas tarefas e lembretes de aula. A ativação pede sua permissão e registra este aparelho no mesmo Worker do site.</Body>{!nativeNotificationsAvailable() && <Notice message="Disponível no APK com Expo/FCM configurado. A prévia Web e o Expo Go não demonstram o push Android." />}{message && <Notice message={message} kind="success" />}{error && <Notice message={error} kind="error" />}<Row><Button label="Ativar notificações" onPress={() => action(true)} loading={busy} disabled={!nativeNotificationsAvailable()} /><Button label="Desativar registro" onPress={() => action(false)} variant="secondary" loading={busy} disabled={!nativeNotificationsAvailable()} /></Row>{nativeNotificationsAvailable() && <Button label="Permissões do Android" variant="secondary" onPress={() => Linking.openSettings()} />}</Card>;
}
