import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Alert, Image, Linking, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { router, useLocalSearchParams, type Href } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';
import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import { worker, useWorker } from '@/lib/sedx/api';
import { useSedx } from '@/lib/sedx/session';
import { scheduleTimerNotification, cancelTimerNotification } from '@/lib/sedx/notifications';
import { C, Page, Card, Button, Input, Notice, Empty, Pill, Body, Title, Label } from '@/components/sedx/ui';
import { apiFailure, buildSubmission, captchaHeaders, chatPayload, durationSeconds, elapsedSeconds, extractQuestions, formatDeadline, htmlMedia, number, object, parseChallenge, parseVerified, pick, plainText, safeHttps, str, studyAttachment, submissionProblems, taskListState, unwrapList, validTarget, verifyBody, type Answers, type CaptchaChallenge, type ChatMessage, type Question, type Task, type VerifiedCaptcha } from '@/lib/sedx/task-utils';

const MINUTES_KEY = 'sedx_task_minutes';
const NativeMediaFailure = createContext<() => void>(() => {});
const PDF_WORKER = 'https://sdf.gabrielreplit56.workers.dev'; // Existing binary /pdf-proxy contract, not a new service.
const errorText = (error: unknown, fallback = 'Não foi possível concluir esta operação.') => error instanceof Error ? error.message : fallback;
const metric = (value: unknown, suffix = '') => number(value) === null ? 'Não informado' : `${number(value)!.toLocaleString('pt-BR', { maximumFractionDigits: 1 })}${suffix}`;
const firstParam = (value: string | string[] | undefined) => Array.isArray(value) ? value[0] ?? '' : value ?? '';

function Loading({ label = 'Consultando a escola...' }: { label?: string }) {
  return <View style={styles.loading}><ActivityIndicator color={C.accent} /><Body>{label}</Body></View>;
}
function Choice({ label, selected, onPress, disabled = false, mode = 'button' }: { label: string; selected: boolean; onPress: () => void; disabled?: boolean; mode?: 'button' | 'radio' | 'checkbox' }) {
  return <Pressable accessibilityRole={mode} accessibilityLabel={label} accessibilityState={{ selected, checked: mode === 'button' ? undefined : selected, disabled }} disabled={disabled} onPress={onPress} style={({ pressed }) => [styles.choice, selected && styles.choiceActive, (pressed || disabled) && styles.dim]}><Text style={[styles.choiceText, selected && styles.choiceTextActive]}>{label}</Text></Pressable>;
}
function Tabs({ options, value, onChange }: { options: { value: string; label: string }[]; value: string; onChange: (value: string) => void }) {
  return <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.tabs}>{options.map(option => <Choice key={option.value} label={option.label} selected={option.value === value} onPress={() => onChange(option.value)} />)}</ScrollView>;
}
function QueryStatus({ query }: { query: { data: any; error: string | null; loading: boolean; refresh: () => Promise<void> } }) {
  const failure = query.error || apiFailure(query.data);
  return <>{query.loading && <Loading />}{failure && <Card><Notice kind="error" message={failure} /><Button label="Tentar novamente" variant="secondary" onPress={() => void query.refresh()} /></Card>}</>;
}
async function openExternal(url: string) {
  const safe = safeHttps(url);
  if (!safe) { Alert.alert('Link bloqueado', 'Esta referência não possui um endereço HTTPS seguro.'); return; }
  try { await Linking.openURL(safe); } catch { Alert.alert('Não foi possível abrir', 'Nenhum aplicativo do sistema conseguiu abrir esta referência.'); }
}
function StudyContent({ content }: { content: unknown }) {
  const media = useMemo(() => htmlMedia(content), [content]);
  return <View style={styles.stack}>{!!plainText(content) && <Text selectable style={styles.content}>{plainText(content)}</Text>}{media.images.map(url => <NativeStudyImage key={url} uri={url} />)}{media.links.map((link, index) => <Button key={`${link.url}-${index}`} label={link.title} variant="secondary" onPress={() => void openExternal(link.url)} />)}{media.unsupported && <Notice message="Este conteúdo inclui mídia ou notação não suportada por este leitor nativo. Não é exibido como página web." />}</View>;
}
function NativeStudyImage({ uri }: { uri: string }) {
  const reportFailure = useContext(NativeMediaFailure);
  const [ratio, setRatio] = useState(1.6), [failed, setFailed] = useState(false);
  useEffect(() => {
    let active = true;
    Image.getSize(uri, (width, height) => { if (active && width && height) setRatio(width / height); }, () => { if (active) { setFailed(true); reportFailure(); } });
    return () => { active = false; };
  }, [uri, reportFailure]);
  return failed ? <Notice kind="error" message="Uma imagem da questão não pôde ser carregada. Confira a referência antes de responder." /> : <Image source={{ uri }} accessibilityLabel="Imagem fornecida no material escolar" resizeMode="contain" style={[styles.studyImage, { aspectRatio: ratio }]} onError={() => { setFailed(true); reportFailure(); }} />;
}

function brazilDay(date = new Date()): string {
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Sao_Paulo', year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(date);
  const values = Object.fromEntries(parts.map(part => [part.type, part.value]));
  return `${values.year}-${values.month}-${values.day}`;
}
function upcomingWeekdays(): string[] {
  const today = new Date(`${brazilDay()}T12:00:00Z`), days: string[] = [];
  for (let offset = 0; days.length < 6 && offset < 14; offset += 1) {
    const day = new Date(today); day.setUTCDate(today.getUTCDate() + offset);
    if (day.getUTCDay() > 0 && day.getUTCDay() < 6) days.push(day.toISOString().slice(0, 10));
  }
  return days;
}
export function AgendaScreen() {
  const query = useWorker('/agenda'), days = useMemo(upcomingWeekdays, []), [day, setDay] = useState(days[0]);
  const rows = unwrapList(query.data).filter(row => str(pick(row, ['data', 'date', 'dataInicio'])).slice(0, 10) === day).sort((a, b) => str(a.horaInicio).localeCompare(str(b.horaInicio)));
  const successful = !!query.data && !query.error && !apiFailure(query.data);
  return <Page title="Agenda" eyebrow="Rotina escolar" subtitle="Disciplinas e horários fornecidos pela sua escola." onRefresh={query.refresh}>
    <Tabs value={day} onChange={setDay} options={days.map(value => ({ value, label: new Date(`${value}T12:00:00Z`).toLocaleDateString('pt-BR', { weekday: 'short', day: '2-digit', month: '2-digit', timeZone: 'America/Sao_Paulo' }) }))} />
    <QueryStatus query={query} />
    {successful && <Label>{new Date(`${day}T12:00:00Z`).toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long', timeZone: 'America/Sao_Paulo' })}</Label>}
    {rows.map((row, index) => <Card key={str(row.id, String(index))}><View style={styles.between}><Pill label={str(row.tipo, 'aula')} color={C.blue} /><Text style={styles.time}>{str(row.horaInicio) || 'Horário não informado'}{row.horaFim ? ` — ${row.horaFim}` : ''}</Text></View><Title>{plainText(row.disciplina ?? row.nomeDisciplina) || 'Evento escolar'}</Title>{!!(row.turma || row.sala) && <Body>{[row.turma, row.sala].filter(Boolean).join(' · ')}</Body>}</Card>)}
    {successful && !query.loading && !rows.length && <Empty title="Nenhuma aula informada neste dia" description="A consulta foi concluída, mas a escola não forneceu registros para esta data." />}
    <Notice message="A agenda consulta os próximos seis dias úteis. Horários ausentes não são estimados." />
  </Page>;
}

export function AttendanceScreen() {
  const query = useWorker('/presenca'), root = object(query.data), rows = unwrapList(query.data);
  const successful = !!query.data && !query.error && !apiFailure(query.data), meta = object(root.meta);
  return <Page title="Presença" eyebrow="Acompanhamento escolar" subtitle="Frequência e faltas registradas na Secretaria." onRefresh={query.refresh}>
    <QueryStatus query={query} />
    {successful && <><Card><Label>Frequência geral · {str(root.anoLetivo)}</Label><Text style={styles.heroMetric}>{metric(root.frequencia, '%')}</Text><View style={styles.between}><Body>Faltas: {metric(root.faltas)}</Body><Body>Aulas: {metric(root.aulasDadas)}</Body></View><Body>Percentual de faltas: {metric(root.porcentagemFaltas, '%')}</Body></Card>
      {(meta.frequenciaApiOk === false || meta.faltasApiOk === false) && <Notice message="A consulta está parcial: um dos serviços de frequência não respondeu. Campos ausentes não significam zero." />}
      <Label>Por bimestre</Label>{rows.map((row, index) => <Card key={`${row.bimestre ?? 'atual'}-${index}`} title={str(row.descricaoBimestre, row.bimestre ? `${row.bimestre}º Bimestre` : 'Período não informado')}><View style={styles.between}><Text style={styles.metric}>{metric(row.frequencia, '%')}</Text><Body>{metric(row.faltas)} faltas</Body></View><Body>{metric(row.aulasDadas)} aulas registradas</Body></Card>)}
      {!rows.length && <Empty title="Sem detalhamento por bimestre" description="O serviço não forneceu registros detalhados. Valores desconhecidos permanecem não informados." />}
      {Array.isArray(root.disciplinas) && root.disciplinas.length > 0 && <><Label>Por disciplina</Label>{root.disciplinas.map((row: any, index: number) => <Card key={str(row.disciplinaId, String(index))} title={plainText(row.nomeDisciplina)}><Body>{metric(row.porcentagemPresencaBimestreAtual ?? row.porcentagemPresenca, '%')} · {metric(row.faltasBimestreAtual ?? row.faltas)} faltas</Body></Card>)}</>}
    </>}
    <Notice message="O Worker atual retorna resumo e bimestres; o detalhamento por disciplina só aparece se fornecido pela API." />
  </Page>;
}

export function GradesScreen() {
  const query = useWorker('/boletim'), [period, setPeriod] = useState('1');
  const rows = unwrapList(query.data).filter(row => period === 'all' || (period === 'year' ? row.bimestre == null : Number(row.bimestre) === Number(period)));
  const successful = !!query.data && !query.error && !apiFailure(query.data);
  return <Page title="Boletim" eyebrow="Seu percurso acadêmico" subtitle="Notas oficiais do aluno autenticado, sem médias inventadas." onRefresh={query.refresh}>
    <Tabs value={period} onChange={setPeriod} options={[1, 2, 3, 4].map(value => ({ value: String(value), label: `${value}º Bimestre` })).concat([{ value: 'year', label: 'Ano letivo' }, { value: 'all', label: 'Todos' }])} />
    <QueryStatus query={query} />
    {successful && <Label>Ano letivo {str(object(query.data).anoLetivo)}</Label>}
    {rows.map((row, index) => <Card key={str(row.id, String(index))}><Title>{plainText(row.disciplina) || 'Disciplina não informada'}</Title>{!!row.descricaoTurma && <Body>{plainText(row.descricaoTurma)}</Body>}<View style={styles.between}><View><Label>Nota</Label><Text style={styles.metric}>{metric(row.nota)}</Text></View><View><Label>Média informada</Label><Text style={styles.metric}>{metric(row.media)}</Text></View><Pill label={str(row.periodo, 'Ano letivo')} /></View></Card>)}
    {successful && !query.loading && !rows.length && <Empty title="Notas ainda não disponíveis" description="A escola não retornou notas para o período escolhido." />}
  </Page>;
}

function TaskCard({ task, onOpen }: { task: Task; onOpen: () => void }) {
  return <Card><View style={styles.between}><Pill label={task.status === 'completed' ? 'Enviada' : task.status === 'expired' ? 'Prazo encerrado' : task.isDraft ? 'Rascunho na plataforma' : 'Em aberto'} color={task.status === 'completed' ? C.green : task.status === 'expired' ? C.red : C.accent} />{task.id && <Label>#{task.id}</Label>}</View><Title>{task.title}</Title>{!!task.subject && <Body>{task.subject}</Body>}{!!task.roomLabel && <Body>{task.roomLabel}</Body>}<Body>Prazo de envio: {formatDeadline(task.due)}</Body><Button label={task.status === 'completed' ? 'Consultar atividade' : 'Abrir atividade'} variant="secondary" onPress={onOpen} disabled={!task.id || !task.room} />{(!task.id || !task.room) && <Notice kind="error" message="Identificador ou sala oficial ausente. Atualize a lista; nenhuma sala será escolhida arbitrariamente." />}</Card>;
}
export function TasksScreen() {
  const sedx = useSedx(), { dashboard, refreshDashboard } = sedx, state = useMemo(() => taskListState(dashboard), [dashboard]);
  const dashboardError = str(object(sedx).dashboardError), dashboardLoading = object(sedx).dashboardLoading === true;
  const [filter, setFilter] = useState('pending'), [minutes, setMinutes] = useState(1), [error, setError] = useState(''), [refreshing, setRefreshing] = useState(false);
  useEffect(() => { AsyncStorage.getItem(MINUTES_KEY).then(value => { const parsed = Number(value); if (Number.isInteger(parsed) && parsed >= 1 && parsed <= 12) setMinutes(parsed); }).catch(() => setError('Não foi possível ler sua preferência de tempo. O mínimo de 1 minuto permanece ativo.')); }, []);
  const refresh = useCallback(async () => { setRefreshing(true); setError(''); try { await refreshDashboard(); } catch (failure) { setError(errorText(failure)); } finally { setRefreshing(false); } }, [refreshDashboard]);
  useEffect(() => { if (!dashboard && !dashboardLoading && !dashboardError) void refresh(); }, [dashboard, dashboardLoading, dashboardError, refresh]);
  async function changeMinutes(next: number) { setMinutes(next); try { await AsyncStorage.setItem(MINUTES_KEY, String(next)); } catch { setError('O tempo foi ajustado nesta tela, mas não pôde ser salvo para a próxima atividade.'); } }
  const tasks = state.tasks.filter(task => filter === 'all' || task.status === filter);
  return <Page title="Tarefas" eyebrow="Atividades da sua turma" subtitle="Responda no seu ritmo. Só você escolhe quando enviar." onRefresh={refresh}>
    <Card title="Tempo mínimo de estudo"><Body>O cronômetro começa após liberar o enunciado. O envio é manual e nunca ocorre ao terminar o tempo.</Body><View style={styles.between}><Button label="−" variant="secondary" disabled={minutes <= 1} onPress={() => void changeMinutes(minutes - 1)} /><Text style={styles.metric}>{minutes} min</Text><Button label="+" variant="secondary" disabled={minutes >= 12} onPress={() => void changeMinutes(minutes + 1)} /></View><Body>Essa preferência vale para a próxima abertura, não reduz o tempo de uma atividade em andamento.</Body></Card>
    <Tabs value={filter} onChange={setFilter} options={[{ value: 'pending', label: 'Em aberto' }, { value: 'expired', label: 'Expiradas' }, { value: 'completed', label: 'Enviadas' }, { value: 'all', label: 'Todas' }]} />
    {(refreshing || dashboardLoading) && <Loading label="Atualizando atividades..." />}{(error || dashboardError || state.error) && <Notice kind="error" message={error || dashboardError || state.error!} />}
    {!dashboard && !refreshing && <Card><Notice message="As tarefas ainda não foram consultadas." /><Button label="Carregar tarefas" onPress={() => void refresh()} /></Card>}
    {dashboard && !state.confirmed && !state.error && <Notice message="O serviço não confirmou a consulta das tarefas. Uma lista vazia não significa que você está sem pendências." />}
    {tasks.map((task, index) => <TaskCard key={`${task.id}-${index}`} task={task} onOpen={() => router.push(`/atividade?taskId=${encodeURIComponent(task.id)}&room=${encodeURIComponent(task.room)}` as Href)} />)}
    {state.confirmed && !state.error && !error && !dashboardError && !dashboardLoading && !refreshing && !tasks.length && <Empty title="Nenhuma atividade neste filtro" description="A consulta foi confirmada. Escolha outro filtro para ver os demais registros." />}
    <Button label="Atualizar lista" variant="secondary" loading={refreshing} onPress={() => void refresh()} />
  </Page>;
}

/** No OCR, AI, solver, token reuse across operations, or background submission. */
function CaptchaGate({ title, description, onVerified, disabled = false }: { title: string; description: string; onVerified: (captcha: VerifiedCaptcha) => Promise<void>; disabled?: boolean }) {
  const [challenge, setChallenge] = useState<CaptchaChallenge | null>(null), [answer, setAnswer] = useState(''), [busy, setBusy] = useState(false), [error, setError] = useState(''), [imageFailed, setImageFailed] = useState(false);
  const mounted = useRef(true), lock = useRef(false), generation = useRef(0);
  const load = useCallback(async () => {
    if (lock.current) return;
    lock.current = true; const requestId = ++generation.current;
    setBusy(true); setChallenge(null); setAnswer(''); setError(''); setImageFailed(false);
    try { const result = parseChallenge(await worker('/captcha/challenge', { method: 'POST', body: { realm: 'edusp', type: 'image' } })); if (mounted.current && requestId === generation.current) setChallenge(result); }
    catch (failure) { if (mounted.current) setError(errorText(failure)); }
    finally { lock.current = false; if (mounted.current) setBusy(false); }
  }, []);
  useEffect(() => { mounted.current = true; void load(); return () => { mounted.current = false; }; }, [load]);
  async function verify() {
    if (lock.current || !challenge || !answer.trim() || disabled || imageFailed) return;
    lock.current = true; setBusy(true); setError('');
    const current = challenge;
    try {
      const verified = parseVerified(await worker('/captcha/verify', { method: 'POST', body: verifyBody(current, answer) }), current);
      setChallenge(null); setAnswer(''); // This challenge is consumed exactly once.
      await onVerified(verified);
    } catch (failure) {
      if (mounted.current) { setError(errorText(failure)); setChallenge(null); setAnswer(''); }
    } finally { lock.current = false; if (mounted.current) setBusy(false); }
  }
  return <Card title={title}><Body>{description}</Body><Notice message="Digite pessoalmente o código da imagem. O app não resolve, interpreta nem contorna o CAPTCHA." />
    {busy && <Loading label="Consultando o desafio protegido..." />}
    {challenge && <><View style={styles.captchaFrame}><Image source={{ uri: challenge.image }} style={styles.captcha} resizeMode="contain" accessibilityLabel="Desafio visual da Sala do Futuro. Digite o código manualmente." onError={() => { setImageFailed(true); setError('A imagem do CAPTCHA não abriu no dispositivo. Gere outro desafio; a validação está bloqueada.'); }} /></View><Input label="Código exibido na imagem" value={answer} onChangeText={setAnswer} autoCapitalize="none" autoCorrect={false} maxLength={24} editable={!busy && !disabled} placeholder="Digite o código, respeitando a imagem" /><Button label="Validar código" onPress={() => void verify()} loading={busy} disabled={!answer.trim() || imageFailed || disabled} /></>}
    {!!error && <Notice kind="error" message={error} />}<Button label="Gerar outro CAPTCHA" variant="secondary" disabled={busy} onPress={() => void load()} />
  </Card>;
}

function QuestionEditor({ question, index, value, onChange, disabled }: { question: Question; index: number; value: unknown; onChange: (value: unknown) => void; disabled: boolean }) {
  const labels: Record<Question['type'], string> = { single: 'Uma alternativa', multi: 'Todas as alternativas aplicáveis', 'true-false': 'Certo ou errado', text: 'Resposta escrita', fill: 'Preencha as lacunas', ordering: 'Ordene os itens', info: 'Material de apoio', unknown: 'Não suportada' };
  const selected = Array.isArray(value) ? value : value == null ? [] : [value], values = object(value);
  return <Card><View style={styles.between}><Label>{question.type === 'info' ? 'Informação' : `Questão ${index + 1}`}</Label><Pill label={labels[question.type]} /></View><StudyContent content={question.statement} />
    {question.problem && <Notice kind="error" message={question.problem} />}
    {!question.problem && (question.type === 'single' || question.type === 'multi') && question.options.map(option => <View key={option.id} style={styles.option}><Choice label={`${selected.includes(option.id) ? 'Selecionada' : 'Selecionar'} · ${plainText(option.text) || 'Alternativa visual'}`} selected={selected.includes(option.id)} disabled={disabled} mode={question.type === 'single' ? 'radio' : 'checkbox'} onPress={() => onChange(question.type === 'single' ? option.id : selected.includes(option.id) ? selected.filter(id => id !== option.id) : [...selected, option.id])} />{htmlMedia(option.text).images.length > 0 && <StudyContent content={option.text} />}</View>)}
    {!question.problem && question.type === 'true-false' && (question.options.length ? question.options : [{ id: '0', text: question.statement, wireKey: '0' }]).map(option => <View key={option.id} style={styles.stack}><StudyContent content={option.text} /><View style={styles.wrap}><Choice label="Certo" mode="radio" selected={values[option.id] === true} disabled={disabled} onPress={() => onChange({ ...values, [option.id]: true })} /><Choice label="Errado" mode="radio" selected={values[option.id] === false} disabled={disabled} onPress={() => onChange({ ...values, [option.id]: false })} /></View></View>)}
    {!question.problem && question.type === 'text' && <><Input label="Sua resposta" multiline textAlignVertical="top" value={typeof value === 'string' ? value : ''} onChangeText={onChange} editable={!disabled} maxLength={question.maxLength ?? undefined} style={styles.answerInput} placeholder="Escreva com suas palavras" />{question.maxLength && <Body>{typeof value === 'string' ? value.length : 0}/{question.maxLength} caracteres</Body>}</>}
    {!question.problem && question.type === 'fill' && question.segments.map((segment, position) => segment.gap ? <View key={segment.key} style={styles.stack}><Label>Lacuna {question.segments.slice(0, position + 1).filter(item => item.gap).length}</Label>{question.bank.length ? <View style={styles.wrap}>{Array.from(new Set(question.bank)).map(word => <Choice key={word} label={word} mode="radio" selected={values[segment.key] === word} disabled={disabled} onPress={() => onChange({ ...values, [segment.key]: word })} />)}</View> : <Input value={str(values[segment.key])} onChangeText={text => onChange({ ...values, [segment.key]: text })} editable={!disabled} placeholder="Preencha esta lacuna" />}</View> : <Body key={segment.key}>{segment.text}</Body>)}
    {!question.problem && question.type === 'ordering' && <><Label>Sua sequência · toque para remover um item</Label><View style={styles.wrap}>{selected.map((bankIndex, position) => <Choice key={`${bankIndex}-${position}`} label={`${position + 1}. ${question.bank[Number(bankIndex)] ?? 'Item inválido'}`} selected disabled={disabled} onPress={() => onChange(selected.filter((_, index) => index !== position))} />)}</View><Label>Itens disponíveis · escolha na ordem desejada</Label><View style={styles.wrap}>{question.bank.map((word, bankIndex) => <Choice key={bankIndex} label={word} selected={selected.includes(bankIndex)} disabled={disabled || selected.includes(bankIndex)} onPress={() => onChange([...selected, bankIndex])} />)}</View><Button label="Limpar sequência" variant="secondary" disabled={disabled} onPress={() => onChange([])} /></>}
  </Card>;
}

type LocalDraft = { version: 1; signature: string; answers: Answers; startedAt: number; minimumSeconds: number; updatedAt: number };
function signature(questions: Question[]) { return JSON.stringify(questions.map(question => [question.id, question.rawType, question.statement, question.options, question.bank, question.segments])); }
function accountId(session: any): string { return str(pick(session, ['cdUsuarioCurto', 'codigoAluno', 'cdAluno', 'cdUsuario'])).replace(/[^a-zA-Z0-9._-]/g, '_'); }
const protectedOptions = { keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY };
async function readProtectedDraft(key: string): Promise<string | null> {
  const saved = await SecureStore.getItemAsync(key, protectedOptions);
  if (!saved) return null;
  const manifest = object(JSON.parse(saved));
  if (!manifest.chunks) return saved; // Read earlier single-value drafts without migrating silently.
  if (!Number.isInteger(manifest.chunks) || manifest.chunks < 1 || manifest.chunks > 1000 || !['a', 'b'].includes(manifest.slot)) throw new Error('Rascunho local inválido.');
  let json = '';
  for (let index = 0; index < manifest.chunks; index += 1) {
    const chunk = await SecureStore.getItemAsync(`${key}.${manifest.slot}.${index}`, protectedOptions);
    if (chunk === null) throw new Error('Rascunho local incompleto.');
    json += chunk;
  }
  return json;
}
async function writeProtectedDraft(key: string, draft: LocalDraft) {
  const json = JSON.stringify(draft), chunks = json.match(/.{1,400}/gs) || [];
  if (chunks.length > 1000) throw new Error('O rascunho excede o limite seguro deste dispositivo.');
  const old = await SecureStore.getItemAsync(key, protectedOptions);
  const manifest = old ? object(JSON.parse(old)) : {}, slot = manifest.slot === 'a' ? 'b' : 'a';
  // Write the inactive bank, then switch its manifest. A interrupted save keeps the prior draft intact.
  for (let start = 0; start < chunks.length; start += 8) await Promise.all(chunks.slice(start, start + 8).map((chunk, offset) => SecureStore.setItemAsync(`${key}.${slot}.${start + offset}`, chunk, protectedOptions)));
  await SecureStore.setItemAsync(key, JSON.stringify({ chunks: chunks.length, slot }), protectedOptions);
}
async function deleteProtectedDraft(key: string) {
  const saved = await SecureStore.getItemAsync(key, protectedOptions), manifest = saved ? object(JSON.parse(saved)) : {};
  await SecureStore.deleteItemAsync(key, protectedOptions);
  const count = Math.min(1000, Number(manifest.chunks) || 0);
  for (let index = 0; index < count; index += 1) await Promise.all(['a', 'b'].map(slot => SecureStore.deleteItemAsync(`${key}.${slot}.${index}`, protectedOptions)));
}

export function TaskDetailScreen() {
  const params = useLocalSearchParams<{ taskId?: string | string[]; room?: string | string[] }>(), taskId = firstParam(params.taskId), room = firstParam(params.room);
  const { session, dashboard, refreshDashboard } = useSedx(), task = taskListState(dashboard).tasks.find(item => item.id === taskId && item.room === room);
  const account = accountId(session), draftKey = account && taskId ? `sedx.draft.${account}.${taskId.replace(/[^a-zA-Z0-9._-]/g, '_')}` : '';
  const [detail, setDetail] = useState<any>(null), [answers, setAnswers] = useState<Answers>({}), [startedAt, setStartedAt] = useState(0), [minimum, setMinimum] = useState(60), [now, setNow] = useState(Date.now()), [mode, setMode] = useState<'read' | 'edit' | 'submit' | 'done'>('read'), [error, setError] = useState(''), [draftNote, setDraftNote] = useState(''), [saving, setSaving] = useState(false), [sending, setSending] = useState(false);
  const questions = useMemo(() => extractQuestions(detail), [detail]), writes = useRef(Promise.resolve()), sendLock = useRef(false), operation = useRef(0), loaded = useRef(false);
  const [mediaFailures, setMediaFailures] = useState(false);
  const [reminderId, setReminderId] = useState<string | null>(null), [reminderBusy, setReminderBusy] = useState(false), [reminderNote, setReminderNote] = useState('');
  const reminderKey = `sedx.reminder.${account}.${taskId}`, saveDelay = useRef<ReturnType<typeof setTimeout> | null>(null), pendingSave = useRef<(() => void) | null>(null);
  const reportMediaFailure = useCallback(() => setMediaFailures(true), []);
  useEffect(() => { operation.current += 1; loaded.current = false; setDetail(null); setAnswers({}); setStartedAt(0); setMode('read'); setError(''); setDraftNote(''); setMediaFailures(false); }, [taskId, room, account]);
  useEffect(() => { if (!startedAt || mode === 'done') return; const timer = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(timer); }, [startedAt, mode]);
  useEffect(() => {
    let active = true; setReminderId(null); setReminderNote('');
    AsyncStorage.getItem(reminderKey).then(id => { if (active) setReminderId(id); }).catch(() => {});
    return () => { active = false; if (saveDelay.current) clearTimeout(saveDelay.current); pendingSave.current?.(); pendingSave.current = null; operation.current += 1; };
  }, [reminderKey]);
  async function toggleReminder() {
    if (reminderBusy) return;
    setReminderBusy(true); setReminderNote('');
    try {
      if (reminderId) { await cancelTimerNotification(reminderId); await AsyncStorage.removeItem(reminderKey); setReminderId(null); setReminderNote('Lembrete local cancelado.'); }
      else {
        if (!startedAt || elapsedSeconds(startedAt) >= minimum) throw new Error('O tempo já terminou; não há lembrete futuro para agendar.');
        const id = await scheduleTimerNotification(new Date(startedAt + minimum * 1000), task?.title || 'Atividade escolar');
        if (!id) throw new Error('O dispositivo não autorizou ou não disponibilizou notificações locais. Nenhum aviso foi agendado.');
        setReminderId(id); await AsyncStorage.setItem(reminderKey, id); setReminderNote('Lembrete local autorizado. Ele apenas avisa que o tempo terminou; não envia respostas.');
      }
    } catch (failure) { setReminderNote(errorText(failure)); } finally { setReminderBusy(false); }
  }
  // Preflight every prompt image; a failed image cannot silently become an answerable prompt.
  useEffect(() => {
    let active = true;
    const urls = questions.flatMap(question => [question.statement, ...question.options.map(option => option.text)].flatMap(content => htmlMedia(content).images));
    urls.forEach(url => Image.getSize(url, () => {}, () => { if (active) setMediaFailures(true); }));
    return () => { active = false; };
  }, [questions]);
  async function read(captcha: VerifiedCaptcha) {
    const id = operation.current;
    if (!taskId || !room) throw new Error('Identificador e sala da atividade são obrigatórios. Abra pela lista de tarefas.');
    const result = await worker(`/task-details?task_id=${encodeURIComponent(taskId)}&room_name=${encodeURIComponent(room)}`, { method: 'GET', headers: captchaHeaders(captcha) });
    const failure = apiFailure(result); if (failure) throw new Error(failure);
    const nextQuestions = extractQuestions(result), currentSignature = signature(nextQuestions);
    let selected = 1;
    try { const stored = Number(await AsyncStorage.getItem(MINUTES_KEY)); if (Number.isInteger(stored) && stored >= 1 && stored <= 12) selected = stored; } catch { /* Worker minimum remains enforced. */ }
    let start = Date.now(), nextAnswers: Answers = {}, nextMinimum = durationSeconds(selected, result), note = 'Rascunho local protegido no dispositivo; não é enviado ao Worker.';
    if (draftKey && Platform.OS !== 'web') {
      try {
        const saved = await readProtectedDraft(draftKey), draft = saved ? object(JSON.parse(saved)) : {};
        if (draft.version === 1 && draft.signature === currentSignature && draft.startedAt > 0 && draft.startedAt <= Date.now() && Date.now() - draft.startedAt < 30 * 24 * 60 * 60 * 1000) {
          nextAnswers = object(draft.answers); start = draft.startedAt; nextMinimum = Math.max(nextMinimum, Number(draft.minimumSeconds) || 60); note = 'Rascunho local restaurado. Revise todas as respostas antes de enviar.';
        } else if (saved) note = 'O conteúdo mudou ou o rascunho expirou. As respostas antigas não foram aplicadas.';
      } catch { note = 'Não foi possível restaurar o rascunho protegido. Você pode responder, mas confira o salvamento local.'; }
    } else note = 'O armazenamento protegido de rascunhos exige Android ou iOS. Nesta prévia, as respostas ficam apenas na memória.';
    if (id !== operation.current) return;
    setDetail(result); setAnswers(nextAnswers); setStartedAt(start); setMinimum(nextMinimum); setNow(Date.now()); setDraftNote(note); setMode('edit'); loaded.current = true;
  }
  function persist(next: Answers) {
    if (!draftKey || !loaded.current || Platform.OS === 'web') return;
    const draft: LocalDraft = { version: 1, signature: signature(questions), answers: next, startedAt, minimumSeconds: minimum, updatedAt: Date.now() };
    // Serialize writes: an earlier autosave must not overwrite the latest voluntary edits.
    if (saveDelay.current) clearTimeout(saveDelay.current);
    const current = operation.current;
    const write = () => {
      pendingSave.current = null;
      writes.current = writes.current.catch(() => {}).then(() => writeProtectedDraft(draftKey, draft)).catch(() => { if (current === operation.current) setDraftNote('Não foi possível salvar o rascunho protegido. Mantenha esta tela aberta ou copie suas respostas.'); });
    };
    pendingSave.current = write; saveDelay.current = setTimeout(write, 700);
  }
  function change(questionId: string, value: unknown) { const next = { ...answers, [questionId]: value }; setAnswers(next); setError(''); persist(next); }
  async function save() { setSaving(true); persist(answers); if (saveDelay.current) clearTimeout(saveDelay.current); pendingSave.current?.(); await writes.current; setSaving(false); }
  const remaining = Math.max(0, minimum - elapsedSeconds(startedAt, now)), problems = submissionProblems(questions, answers);
  function requestSubmit() {
    if (mode !== 'edit' || sending) return;
    if (task?.status === 'completed' || task?.status === 'expired') { setError('Esta atividade está enviada ou com prazo encerrado. O envio nativo está bloqueado.'); return; }
    if (mediaFailures) { setError('Uma imagem da atividade não abriu. Reabra a tarefa para tentar carregar o conteúdo completo.'); return; }
    if (!validTarget(room)) { setError('A sala retornada não é um alvo de publicação suportado. Atualize a lista.'); return; }
    if (problems.length) { setError(problems.join('\n')); return; }
    if (elapsedSeconds(startedAt) < minimum) { setError('Aguarde completar o tempo mínimo real antes de enviar.'); return; }
    Alert.alert('Enviar suas respostas?', 'Você revisou todas as respostas? Será necessário um NOVO CAPTCHA. Validá-lo confirmará o envio definitivo à Sala do Futuro.', [{ text: 'Continuar revisando', style: 'cancel' }, { text: 'Revisado, continuar', onPress: () => { setError(''); setMode('submit'); } }]);
  }
  async function send(captcha: VerifiedCaptcha) {
    if (sendLock.current || mode !== 'submit') throw new Error('Envio já iniciado ou cancelado.');
    sendLock.current = true; setSending(true); setError('');
    try {
      if (mediaFailures || task?.status === 'completed' || task?.status === 'expired') throw new Error('Conteúdo incompleto ou atividade indisponível para envio.');
      const body = buildSubmission({ taskId, room, questions, answers, session, captcha, startedAt, minimumSeconds: minimum });
      const result = await worker('/answer-task', { method: 'POST', headers: captchaHeaders(captcha), body });
      if (result?.ok !== true) throw new Error(str(result?.error, 'O serviço não confirmou o envio. Confira o status antes de tentar novamente.'));
      setMode('done'); loaded.current = false;
      if (saveDelay.current) clearTimeout(saveDelay.current); pendingSave.current = null;
      await writes.current;
      if (draftKey && Platform.OS !== 'web') { try { await deleteProtectedDraft(draftKey); } catch { setDraftNote('Atividade enviada. O rascunho protegido não pôde ser removido do dispositivo.'); } }
      if (reminderId) { try { await cancelTimerNotification(reminderId); await AsyncStorage.removeItem(reminderKey); setReminderId(null); } catch { setReminderNote('Envio confirmado. Não foi possível cancelar o lembrete local.'); } }
      try { await refreshDashboard(); } catch { setError('Envio confirmado, mas a lista não pôde ser atualizada. Atualize-a manualmente.'); }
    } finally { sendLock.current = false; setSending(false); }
  }
  if (!taskId || !room) return <Page title="Atividade"><Empty title="Atividade não identificada" description="Abra uma atividade pela lista de tarefas para receber o identificador e a sala oficiais." /><Button label="Ir para tarefas" onPress={() => router.replace('/tarefas' as Href)} /></Page>;
  return <NativeMediaFailure.Provider value={reportMediaFailure}><Page title={task?.title || 'Atividade escolar'} eyebrow="Respostas manuais" subtitle={task?.subject || `Atividade ${taskId}`}>
    <View style={styles.between}><Pill label={mode === 'done' ? 'Envio confirmado' : mode === 'read' ? 'Leitura protegida' : 'Você controla suas respostas'} color={mode === 'done' ? C.green : C.accent} /><Button label="Voltar" variant="secondary" disabled={sending} onPress={() => router.back()} /></View>
    {!!error && <Notice kind={mode === 'done' ? 'info' : 'error'} message={error} />}
    {mode === 'read' && <CaptchaGate key={`read-${account}-${taskId}-${room}`} title="Libere o enunciado" description="Valide um CAPTCHA novo para consultar esta atividade usando sua sessão oficial." onVerified={read} />}
    {mode === 'done' && <Card title="Atividade enviada"><Notice kind="success" message="O Worker confirmou o envio à Sala do Futuro. Não haverá outro envio automático." /><Body>Comentários de correção e acordos não são confirmados automaticamente por este aplicativo.</Body><Button label="Ver minhas tarefas" onPress={() => router.replace('/tarefas' as Href)} /></Card>}
    {detail && mode !== 'done' && <><Card><Label>Tempo mínimo de estudo</Label><Text style={styles.metric}>{Math.floor(Math.min(minimum, elapsedSeconds(startedAt, now)) / 60)}:{String(Math.min(minimum, elapsedSeconds(startedAt, now)) % 60).padStart(2, '0')} / {Math.floor(minimum / 60)}:{String(minimum % 60).padStart(2, '0')}</Text><Body>{remaining ? `Envio liberado em ${Math.floor(remaining / 60)}:${String(remaining % 60).padStart(2, '0')}.` : 'Tempo concluído. Revise e escolha enviar quando quiser.'}</Body></Card>
      {(remaining > 0 || reminderId) && <Button label={reminderId ? 'Cancelar lembrete local' : 'Avisar quando liberar'} variant="secondary" loading={reminderBusy} disabled={sending} onPress={() => void toggleReminder()} />}{!!reminderNote && <Notice message={reminderNote} />}
      {!!draftNote && <Notice message={draftNote} />}{mediaFailures && <Notice kind="error" message="Uma imagem necessária não pôde ser carregada. O envio está bloqueado; reabra a atividade para tentar novamente." />}
      <StudyContent content={pick(detail, ['statement', 'description', 'enunciado']) ?? pick(object(detail).task, ['statement', 'description'])} />
      {questions.map((question, index) => <QuestionEditor key={`${question.id}-${index}`} question={question} index={index} value={answers[question.id]} onChange={value => change(question.id, value)} disabled={mode !== 'edit' || sending} />)}
      {!questions.length && <Empty title="Nenhuma questão estruturada" description="O enunciado foi consultado, mas este formato não pode ser respondido ou enviado pelo app." />}
      {mode === 'edit' && <><Button label="Salvar rascunho neste dispositivo" variant="secondary" loading={saving} onPress={() => void save()} /><Button label={remaining ? 'Aguarde o tempo mínimo' : 'Revisar e enviar'} disabled={!!remaining || !questions.length || mediaFailures || task?.status === 'completed' || task?.status === 'expired'} onPress={requestSubmit} /></>}
      {mode === 'submit' && <><CaptchaGate key={`submit-${account}-${taskId}`} title="Confirme seu envio" description="Suas respostas estão congeladas. Digite o novo CAPTCHA; validar o código enviará estas respostas definitivamente." onVerified={send} disabled={sending} /><Button label="Cancelar envio e continuar revisando" variant="secondary" disabled={sending} onPress={() => setMode('edit')} /></>}
    </>}
  </Page></NativeMediaFailure.Provider>;
}

// Actual EF/EM repository inventory. These are catalog paths, not invented lesson data.
const BOOK_FILES: Record<string, { title: string; file: string }[]> = {
  science: [{ title: 'Ciências / Inglês / Projeto de Vida', file: 'ciencias-ingles-projeto-vida.pdf' }, { title: 'Geografia / História', file: 'geografia-historia.pdf' }, { title: 'Português / Matemática', file: 'portugues-matematica.pdf' }],
  high: [{ title: 'Biologia / Física / Química', file: 'biologia-fisica-quimica.pdf' }, { title: 'História / Geografia / Inglês', file: 'historia-geografia-ingles.pdf' }, { title: 'Português / Matemática', file: 'portugues-matematica.pdf' }],
  final: [{ title: 'História / Física / Inglês', file: 'historia-fisica-ingles.pdf' }, { title: 'Português / Matemática', file: 'portugues-matematica.pdf' }],
};
export function BooksScreen() {
  const [level, setLevel] = useState('EM'), [grade, setGrade] = useState('1'), [busy, setBusy] = useState(''), [error, setError] = useState(''), [status, setStatus] = useState('');
  const downloadLock = useRef(false), grades = level === 'EM' ? [1, 2, 3] : [6, 7, 8, 9], books = BOOK_FILES[level === 'EF' ? 'science' : grade === '3' ? 'final' : 'high'];
  async function openBook(book: { title: string; file: string }) {
    if (downloadLock.current) return;
    downloadLock.current = true; setBusy(book.file); setError(''); setStatus('');
    let local = '';
    try {
      if (Platform.OS === 'web') throw new Error('A abertura nativa de PDF está disponível no Android e iOS. Esta prévia não usa leitor web.');
      if (!await Sharing.isAvailableAsync()) throw new Error('O compartilhamento nativo de arquivos não está disponível neste dispositivo.');
      if (!FileSystem.cacheDirectory) throw new Error('O dispositivo não disponibilizou uma pasta segura de cache.');
      const directory = `${FileSystem.cacheDirectory}sedx-books/`;
      await FileSystem.makeDirectoryAsync(directory, { intermediates: true });
      local = `${directory}${level}-${grade}-${book.file}`;
      const raw = `https://raw.githubusercontent.com/GabZs77/Sed/main/${level}/${grade}ano/${book.file}`;
      const response = await FileSystem.downloadAsync(`${PDF_WORKER}/pdf-proxy?url=${encodeURIComponent(raw)}`, local);
      if (response.status < 200 || response.status >= 300) throw new Error(`A apostila não está acessível no serviço (HTTP ${response.status}). O repositório é privado e o proxy não autentica no GitHub.`);
      const header = await FileSystem.readAsStringAsync(local, { encoding: FileSystem.EncodingType.Base64, position: 0, length: 5 });
      if (!header.startsWith('JVBERi0')) throw new Error('O serviço não devolveu um PDF válido. O arquivo não será compartilhado como apostila.');
      await Sharing.shareAsync(local, { mimeType: 'application/pdf', UTI: 'com.adobe.pdf', dialogTitle: `Abrir ${book.title} em um aplicativo de PDF` });
      setStatus('PDF transferido ao compartilhamento do sistema. Escolha um leitor de PDF instalado; o arquivo ficará no cache temporário do app.');
    } catch (failure) {
      setError(errorText(failure, 'A apostila não pôde ser obtida. Nenhum material alternativo foi inventado.'));
      if (local) await FileSystem.deleteAsync(local, { idempotent: true }).catch(() => {});
    } finally { downloadLock.current = false; setBusy(''); }
  }
  return <Page title="Apostilas" eyebrow="Biblioteca de estudos" subtitle="Catálogo original de materiais EF e EM. Leitura em aplicativos nativos de PDF.">
    <Tabs value={level} onChange={value => { setLevel(value); setGrade(value === 'EM' ? '1' : '6'); setError(''); }} options={[{ value: 'EM', label: 'Ensino Médio' }, { value: 'EF', label: 'Ensino Fundamental' }]} />
    <Tabs value={grade} onChange={setGrade} options={grades.map(value => ({ value: String(value), label: `${value}º Ano` }))} />
    <Notice message="O catálogo existe no repositório de origem, mas os PDFs podem estar inacessíveis por serem privados. O proxy existente não possui autenticação GitHub. O app informa o erro real e não inclui cópias fictícias." />
    {!!error && <Notice kind="error" message={error} />}{!!status && <Notice kind="success" message={status} />}
    {books.map(book => <Card key={book.file}><Pill label="PDF · Material de apoio" color={C.blue} /><Title>{book.title}</Title><Body>{level} · {grade}º Ano</Body><Button label="Baixar e abrir no sistema" loading={busy === book.file} disabled={!!busy && busy !== book.file} onPress={() => void openBook(book)} /></Card>)}
    <Notice message="Não há WebView nem leitor embutido. A análise automática do texto de PDFs não está disponível neste módulo; você pode copiar um trecho para estudar com o Flash IA." />
  </Page>;
}

export function AIScreen() {
  const { session, dashboard, refreshDashboard } = useSedx(), state = taskListState(dashboard);
  const [messages, setMessages] = useState<ChatMessage[]>([]), [input, setInput] = useState(''), [route, setRoute] = useState('/groq-chat'), [sending, setSending] = useState(false), [error, setError] = useState(''), [attachment, setAttachment] = useState(''), [attachmentTitle, setAttachmentTitle] = useState(''), [attaching, setAttaching] = useState<Task | null>(null), [selecting, setSelecting] = useState(false);
  const lock = useRef(false), abort = useRef<AbortController | null>(null);
  useEffect(() => () => abort.current?.abort(), []);
  async function send() {
    if (lock.current || !input.trim()) return;
    lock.current = true; setSending(true); setError('');
    const prompt = input.trim(), selectedAttachment = attachment;
    const controller = new AbortController(); abort.current = controller;
    try {
      if (!session?.token2) throw new Error('Entre novamente para usar o tutor de estudos.');
      const body = chatPayload(messages, prompt, selectedAttachment), result = await worker(route, { method: 'POST', body, signal: controller.signal });
      const failure = apiFailure(result), response = str(result?.response).trim();
      if (failure || !response) throw new Error(failure || 'O tutor não retornou uma resposta. Sua mensagem não foi apagada.');
      setMessages(previous => [...previous, { role: 'user', content: prompt + (selectedAttachment ? `\n\nMaterial anexado: ${attachmentTitle}` : '') }, { role: 'assistant', content: response }]);
      setInput('');
    } catch (failure) { if (!controller.signal.aborted) setError(errorText(failure)); }
    finally { lock.current = false; setSending(false); abort.current = null; }
  }
  async function chooseAttachment() {
    setSelecting(true); setError('');
    if (!dashboard) { try { await refreshDashboard(); } catch (failure) { setError(errorText(failure)); } }
  }
  async function attach(captcha: VerifiedCaptcha) {
    const task = attaching;
    if (!task?.id || !task.room) throw new Error('Selecione uma atividade com identificador e sala oficiais.');
    const result = await worker(`/task-details?task_id=${encodeURIComponent(task.id)}&room_name=${encodeURIComponent(task.room)}`, { method: 'GET', headers: captchaHeaders(captcha) });
    const failure = apiFailure(result); if (failure) throw new Error(failure);
    const text = studyAttachment(result, task.title);
    setAttachment(text); setAttachmentTitle(task.title); setAttaching(null); setSelecting(false);
  }
  return <Page title="Flash IA" eyebrow="Tutor de estudos" subtitle="Entenda conceitos e construa seu raciocínio. Sem respostas ou envios automáticos.">
    <Tabs value={route} onChange={setRoute} options={[{ value: '/groq-chat', label: 'Conversar' }, { value: '/groq-help', label: 'Tirar dúvida' }, { value: '/groq-research', label: 'Organizar pesquisa' }]} />
    <Notice message="O tutor usa as rotas já existentes do SEDX. As respostas podem conter erros; revise com seu material e professor. Não há navegação ou pesquisa externa garantida." />
    {!messages.length && <Card title="O que você quer compreender?"><Body>Peça uma explicação, um exemplo semelhante ou um plano de revisão. Você também pode anexar o texto de uma atividade após resolver um CAPTCHA pessoalmente.</Body></Card>}
    {messages.map((message, index) => <Card key={index} style={message.role === 'user' ? styles.userMessage : undefined}><Label>{message.role === 'user' ? 'Você' : 'Flash IA'}</Label><Text selectable style={styles.content}>{message.content}</Text></Card>)}
    {!!error && <Notice kind="error" message={error} />}
    {!!attachment && <Card><Label>Material anexado · {attachmentTitle}</Label><Body>{attachment.length.toLocaleString('pt-BR')} caracteres de material de estudo. Será compartilhado com o tutor ao enviar sua pergunta.</Body><Button label="Remover anexo" variant="secondary" disabled={sending} onPress={() => { setAttachment(''); setAttachmentTitle(''); }} /></Card>}
    <Button label="Anexar atividade para estudar" variant="secondary" disabled={sending || !!attaching} onPress={() => void chooseAttachment()} />
    {selecting && !attaching && <Card title="Escolha uma atividade">{state.error && <Notice kind="error" message={state.error} />}{!state.confirmed && !state.error && <Notice message="A consulta de atividades ainda não foi confirmada. Atualize a lista." />}{state.tasks.filter(task => task.id && task.room).map((task, index) => <Button key={`${task.id}-${index}`} label={task.title} variant="secondary" onPress={() => setAttaching(task)} />)}{state.confirmed && !state.error && !state.tasks.length && <Empty title="Sem atividades para anexar" />}<Button label="Atualizar tarefas" variant="secondary" onPress={() => { refreshDashboard().catch(failure => setError(errorText(failure))); }} /><Button label="Cancelar" variant="secondary" onPress={() => setSelecting(false)} /></Card>}
    {attaching && <><CaptchaGate key={`${attaching.id}-${attaching.room}`} title="Autorize a leitura do material" description={`Resolva manualmente o CAPTCHA para anexar: ${attaching.title}. Apenas o texto é anexado; imagens não são analisadas e nenhuma resposta sua é preenchida.`} onVerified={attach} /><Button label="Cancelar anexo" variant="secondary" onPress={() => setAttaching(null)} /></>}
    <Card><Input label="Sua dúvida" value={input} onChangeText={setInput} multiline textAlignVertical="top" maxLength={12_000} style={styles.answerInput} editable={!sending} placeholder="Por exemplo: explique este conceito passo a passo" /><Button label="Enviar pergunta" onPress={() => void send()} loading={sending} disabled={!input.trim() || !!attaching} />{sending && <Button label="Interromper espera" variant="secondary" onPress={() => abort.current?.abort()} />}</Card>
    {messages.length > 0 && <Button label="Limpar conversa neste dispositivo" variant="secondary" disabled={sending} onPress={() => Alert.alert('Limpar conversa?', 'As mensagens desta tela serão removidas da memória. Isso não apaga registros do serviço de IA.', [{ text: 'Cancelar', style: 'cancel' }, { text: 'Limpar', style: 'destructive', onPress: () => setMessages([]) }])} />}
  </Page>;
}

const styles = StyleSheet.create({
  stack: { gap: 12 }, loading: { paddingVertical: 16, alignItems: 'center', gap: 10 },
  tabs: { gap: 8, paddingVertical: 4 }, wrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  between: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 },
  choice: { minHeight: 44, borderRadius: 13, paddingHorizontal: 14, paddingVertical: 12, borderWidth: 1, borderColor: C.border, backgroundColor: C.raised, justifyContent: 'center', flexShrink: 1 },
  choiceActive: { borderColor: C.accent, backgroundColor: C.surface }, choiceText: { color: C.text, fontSize: 14, lineHeight: 20 }, choiceTextActive: { color: C.accent, fontWeight: '700' }, dim: { opacity: 0.55 },
  time: { color: C.accent, fontSize: 15, fontWeight: '700' }, content: { color: C.text, fontSize: 15, lineHeight: 24 },
  heroMetric: { color: C.accent, fontSize: 42, fontWeight: '800', paddingVertical: 8 }, metric: { color: C.text, fontSize: 25, fontWeight: '700' },
  captchaFrame: { backgroundColor: '#FFFFFF', borderRadius: 14, padding: 12, alignItems: 'center' }, captcha: { width: '100%', height: 120 },
  studyImage: { width: '100%', minHeight: 80, maxHeight: 600, backgroundColor: C.raised, borderRadius: 12 },
  option: { gap: 8 }, answerInput: { minHeight: 130 }, userMessage: { borderColor: C.accent },
});
