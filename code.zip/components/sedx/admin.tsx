import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Image,
  KeyboardAvoidingView,
  Linking,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  View,
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import * as ImageManipulator from "expo-image-manipulator";
import { worker, useWorker } from "@/lib/sedx/api";
import { useSedx } from "@/lib/sedx/session";
import {
  C,
  Page,
  Card,
  Button,
  Input,
  Notice,
  Empty,
  Pill,
  Body,
  Title,
  Label,
} from "@/components/sedx/ui";

// Authorization comes exclusively from the session provider's real /admin/data check.
// No owner RA list, credentials, local seed records or browser APIs belong here.
type NoticeRecord = {
  id: string;
  title: string;
  description: string;
  audience: string;
  image?: string;
  publishedAt?: string;
};
type UserRecord = {
  ra: string;
  name: string;
  role: string;
  status: string;
  lastSeen: string;
};
type AuditRecord = {
  id: string | number;
  actor: string;
  action: string;
  detail: string;
  at: string;
};
type Settings = {
  siteName?: string;
  logo?: string;
  favicon?: string;
  welcome?: string;
  support?: string;
  maintenanceMessage?: string;
  maintenance?: boolean;
  featureIa?: boolean;
  featureApostilas?: boolean;
  supportAssistant?: boolean;
  activeTheme?: string;
};
type Ticket = {
  id: string;
  userRa: string;
  userName: string;
  type: string;
  content: string;
  image?: string;
  status: string;
  adminReply?: string;
  createdAt?: string;
};
type HelpMessage = {
  id: string;
  authorRa?: string;
  authorName?: string;
  authorRole?: string;
  mine?: boolean;
  content: string;
  deleted?: boolean;
  editedAt?: string;
  createdAt?: string;
};
type Partnership = {
  id: string;
  title: string;
  description: string;
  logo: string;
  banner: string;
  destinationUrl: string;
  type: string;
  isPublished: boolean | number | string;
  createdAt?: string;
  updatedAt?: string;
};
type ToolRecord = {
  id: string;
  title: string;
  description: string;
  image?: string;
  actionType: string;
  content: string;
};
type ChatMessage = {
  id: string;
  authorRa: string;
  author?: { name?: string };
  content: string;
  deleted?: boolean;
  attachmentName?: string;
  createdAt?: string;
};
type AdminData = {
  ok?: boolean;
  settings: Settings;
  users: UserRecord[];
  notices: NoticeRecord[];
  audit: AuditRecord[];
  feedback: Ticket[];
  stats?: {
    users?: number;
    notices?: number;
    active?: number;
    accesses?: number;
  };
};
type RequestOptions = {
  method?: string;
  body?: any;
  headers?: Record<string, string>;
};
type ConfirmOptions = {
  title: string;
  message: string;
  label?: string;
  danger?: boolean;
};
type Actions = {
  busy: boolean;
  error?: string;
  confirm: (options: ConfirmOptions) => Promise<boolean>;
  run: (
    path: string,
    options: RequestOptions,
    message: string,
    syncPublic?: boolean,
    after?: () => unknown | Promise<unknown>,
  ) => Promise<boolean>;
};
type Tab =
  | "overview"
  | "notices"
  | "users"
  | "settings"
  | "audit"
  | "tools"
  | "partnerships"
  | "help"
  | "moderation";
const TABS: { id: Tab; label: string }[] = [
  { id: "overview", label: "Visão geral" },
  { id: "notices", label: "Avisos" },
  { id: "users", label: "Usuários" },
  { id: "settings", label: "Configurações" },
  { id: "partnerships", label: "Parcerias" },
  { id: "tools", label: "Ferramentas" },
  { id: "help", label: "Atendimentos" },
  { id: "moderation", label: "Moderação" },
  { id: "audit", label: "Auditoria" },
];
const THEMES = [
  { value: "default", label: "Original" },
  { value: "halloween", label: "Halloween" },
  { value: "christmas", label: "Natal" },
  { value: "kids", label: "Dia das crianças" },
];
const STATUS = [
  { value: "aberto", label: "Recebido" },
  { value: "em_analise", label: "Em análise" },
  { value: "resolvido", label: "Resolvido" },
  { value: "arquivado", label: "Arquivado" },
];
const IMAGE_DATA =
  /^data:image\/(?:png|jpeg|webp|gif);base64,([A-Za-z0-9+/]+={0,2})$/i;
const digits = (value: unknown) => String(value ?? "").replace(/\D/g, "");
const published = (value: Partnership["isPublished"]) =>
  value === true || value === 1 || value === "1";
const errorMessage = (error: unknown) =>
  error instanceof Error
    ? error.message
    : String(error || "Não foi possível concluir a operação.");
const list = <T,>(value: T[] | undefined | null): T[] =>
  Array.isArray(value) ? value : [];
const dateLabel = (value?: string) => {
  if (!value) return "Não informado";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString("pt-BR");
};
function validUrl(value: string) {
  try {
    const url = new URL(value.trim());
    return (
      ["http:", "https:"].includes(url.protocol) &&
      !!url.hostname &&
      !url.username &&
      !url.password &&
      !/\s/.test(value.trim())
    );
  } catch {
    return false;
  }
}
function validImage(value: string, maxBytes: number, allowRemote = false) {
  if (!value) return true;
  if (allowRemote && value.length <= 2048 && validUrl(value)) return true;
  const match = value.match(IMAGE_DATA);
  if (!match || match[1].length % 4 !== 0) return false;
  const bytes =
    (match[1].length * 3) / 4 -
    (match[1].endsWith("==") ? 2 : match[1].endsWith("=") ? 1 : 0);
  return bytes <= maxBytes && (maxBytes > 250 * 1024 || value.length <= 350000);
}
function imageUri(value: string) {
  return validImage(value, 5 * 1024 * 1024, true) ? value : "";
}
function validatePartnership(draft: Partnership) {
  if (!draft.id || draft.id.length > 100)
    return "Identificador de parceria inválido.";
  if (!draft.title.trim() || draft.title.trim().length > 120)
    return "Informe um título de até 120 caracteres.";
  if (!draft.description.trim() || draft.description.trim().length > 2000)
    return "Informe uma descrição de até 2.000 caracteres.";
  if (
    draft.destinationUrl.trim().length > 2048 ||
    !validUrl(draft.destinationUrl)
  )
    return "Informe um destino http:// ou https:// válido, sem usuário e senha na URL.";
  if (!["Discord", "WhatsApp", "Outro"].includes(draft.type))
    return "Selecione um tipo de parceria válido.";
  if (
    !validImage(draft.logo, 250 * 1024) ||
    !validImage(draft.banner, 250 * 1024)
  )
    return "Logo e banner precisam ser imagens PNG, JPEG, WebP ou GIF em base64, de até 250 KB cada.";
  return "";
}

function Choices({
  label,
  value,
  options,
  onChange,
  disabled,
}: {
  label: string;
  value: string;
  options: { value: string; label: string }[];
  onChange: (value: string) => void;
  disabled?: boolean;
}) {
  return (
    <View style={s.field}>
      <Label>{label}</Label>
      <View style={s.wrap}>
        {options.map((option) => (
          <Pressable
            key={option.value}
            accessibilityRole="radio"
            accessibilityLabel={option.label}
            accessibilityState={{ checked: value === option.value, disabled }}
            disabled={disabled}
            onPress={() => onChange(option.value)}
            style={[
              s.choice,
              value === option.value && s.choiceActive,
              disabled && s.disabled,
            ]}
          >
            <Text
              style={[
                s.choiceText,
                value === option.value && s.choiceTextActive,
              ]}
            >
              {option.label}
            </Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}
function Toggle({
  label,
  description,
  value,
  onChange,
  disabled,
}: {
  label: string;
  description?: string;
  value: boolean;
  onChange: (value: boolean) => void;
  disabled?: boolean;
}) {
  return (
    <View style={s.toggle}>
      <View style={s.flex}>
        <Text style={s.label}>{label}</Text>
        {description ? <Text style={s.muted}>{description}</Text> : null}
      </View>
      <Switch
        accessibilityLabel={label}
        value={value}
        onValueChange={onChange}
        disabled={disabled}
        trackColor={{ false: C.border, true: C.accent }}
        thumbColor={C.text}
      />
    </View>
  );
}
function RemoteImage({
  uri,
  label,
  logo = false,
}: {
  uri?: string;
  label: string;
  logo?: boolean;
}) {
  const [failedUri, setFailedUri] = useState<string | null>(null);
  const safe = uri ? imageUri(uri) : "";
  if (!safe) return null;
  if (failedUri === safe)
    return (
      <Notice
        kind="error"
        message={`Não foi possível exibir ${label.toLowerCase()}. Verifique a imagem antes de salvar.`}
      />
    );
  return (
    <Image
      accessibilityLabel={label}
      source={{ uri: safe }}
      resizeMode={logo ? "contain" : "cover"}
      onError={() => setFailedUri(safe)}
      style={logo ? s.logo : s.image}
    />
  );
}
function LoadState({
  loading,
  error,
  refresh,
}: {
  loading: boolean;
  error: string | null;
  refresh: () => unknown;
}) {
  return (
    <>
      {loading ? (
        <View style={s.loading}>
          <ActivityIndicator color={C.accent} />
          <Body>Carregando dados do servidor…</Body>
        </View>
      ) : null}
      {error ? (
        <View style={s.stack}>
          <Notice kind="error" message={error} />
          <Button
            label="Tentar novamente"
            variant="secondary"
            onPress={() => {
              void refresh();
            }}
          />
        </View>
      ) : null}
    </>
  );
}
function EditorWindow({
  title,
  children,
  onClose,
  busy,
  error,
}: {
  title: string;
  children: React.ReactNode;
  onClose: () => void;
  busy?: boolean;
  error?: string;
}) {
  return (
    <Modal
      visible
      transparent
      animationType="fade"
      onRequestClose={() => {
        if (!busy) onClose();
      }}
    >
      <KeyboardAvoidingView
        style={s.backdrop}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <View style={s.modal} accessibilityViewIsModal>
          <View style={s.modalHeader}>
            <View style={s.flex}>
              <Title>{title}</Title>
            </View>
            <Button
              label="Fechar"
              variant="secondary"
              disabled={busy}
              onPress={onClose}
            />
          </View>
          <ScrollView
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={s.modalContent}
          >
            {error ? <Notice kind="error" message={error} /> : null}
            {children}
          </ScrollView>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}
function ImageField({
  label,
  value,
  onChange,
  maxBytes = 250 * 1024,
  allowRemote = false,
  disabled,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  maxBytes?: number;
  allowRemote?: boolean;
  disabled?: boolean;
}) {
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState("");
  const pick = async () => {
    setError("");
    setProcessing(true);
    try {
      const permission =
        await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted)
        throw new Error("Autorize o acesso às fotos para escolher uma imagem.");
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ["images"],
        allowsEditing: false,
        quality: 1,
      });
      if (result.canceled || !result.assets?.[0]) return;
      const asset = result.assets[0];
      let width = Math.min(
        asset.width || 1400,
        maxBytes > 250 * 1024 ? 1400 : 1800,
      );
      let encoded = "";
      // Aspect ratio is preserved. Native manipulation also strips metadata and normalizes to JPEG.
      for (let attempt = 0; attempt < 9; attempt++) {
        const output = await ImageManipulator.manipulateAsync(
          asset.uri,
          [{ resize: { width: Math.max(1, Math.round(width)) } }],
          {
            format: ImageManipulator.SaveFormat.JPEG,
            compress: Math.max(0.34, 0.86 - attempt * 0.065),
            base64: true,
          },
        );
        encoded = output.base64
          ? `data:image/jpeg;base64,${output.base64}`
          : "";
        if (encoded && validImage(encoded, maxBytes)) break;
        width *= 0.8;
      }
      if (!encoded || !validImage(encoded, maxBytes))
        throw new Error(
          `A imagem não pôde ser reduzida para ${maxBytes > 250 * 1024 ? "5 MB" : "250 KB"}. Escolha outra.`,
        );
      onChange(encoded);
    } catch (error) {
      setError(errorMessage(error));
    } finally {
      setProcessing(false);
    }
  };
  return (
    <View style={s.stack}>
      <Label>{label} · opcional</Label>
      <Body>
        {allowRemote
          ? "URL http/https ou imagem da galeria, até 5 MB."
          : "Galeria: PNG, JPEG, WebP ou GIF. Otimização para JPEG, até 250 KB; transparência pode ser removida."}
      </Body>
      {allowRemote ? (
        <Input
          accessibilityLabel={`${label}: URL`}
          placeholder="https://…"
          autoCapitalize="none"
          autoCorrect={false}
          editable={!disabled && !processing}
          value={value.startsWith("data:") ? "" : value}
          onChangeText={onChange}
        />
      ) : null}
      <View style={s.wrap}>
        <Button
          label={value ? "Trocar imagem" : "Escolher imagem"}
          variant="secondary"
          onPress={() => {
            void pick();
          }}
          loading={processing}
          disabled={disabled}
        />
        {value ? (
          <Button
            label="Remover imagem"
            variant="secondary"
            disabled={disabled || processing}
            onPress={() => {
              onChange("");
              setError("");
            }}
          />
        ) : null}
      </View>
      <RemoteImage uri={value} label={label} />
      {error ? <Notice message={error} kind="error" /> : null}
    </View>
  );
}

export function AdminScreen() {
  const { isAdmin, session } = useSedx();
  if (!session)
    return (
      <Page title="Administração" eyebrow="ÁREA RESTRITA">
        <Empty
          title="Entre na sua conta"
          description="Uma sessão válida e autorização do servidor são necessárias."
        />
      </Page>
    );
  if (!isAdmin)
    return (
      <Page title="Administração" eyebrow="ÁREA RESTRITA">
        <Notice
          kind="error"
          message="Acesso administrativo não autorizado pelo servidor. Não há liberação local por RA ou perfil."
        />
      </Page>
    );
  return <AdminPanel />;
}

function AdminPanel() {
  const { isAdmin, session, refreshSiteState } = useSedx();
  const query = useWorker<AdminData>(isAdmin ? "/admin/data" : null);
  const [tab, setTab] = useState<Tab>("overview");
  const [busy, setBusy] = useState(false);
  const lock = useRef(false);
  const authorized = useRef(isAdmin);
  const [feedback, setFeedback] = useState<{
    message: string;
    kind: "error" | "success" | "info";
  } | null>(null);
  const [pending, setPending] = useState<ConfirmOptions | null>(null);
  const resolver = useRef<((value: boolean) => void) | null>(null);
  useEffect(() => {
    authorized.current = isAdmin;
    return () => {
      authorized.current = false;
      resolver.current?.(false);
      resolver.current = null;
    };
  }, [isAdmin]);
  const settle = (value: boolean) => {
    const resolve = resolver.current;
    resolver.current = null;
    setPending(null);
    resolve?.(value);
  };
  const confirm = useCallback(
    (options: ConfirmOptions) =>
      new Promise<boolean>((resolve) => {
        if (!authorized.current || lock.current || resolver.current) {
          resolve(false);
          return;
        }
        resolver.current = resolve;
        if (Platform.OS !== "web") {
          const finish = (value: boolean) => {
            if (resolver.current !== resolve) return;
            resolver.current = null;
            resolve(value);
          };
          Alert.alert(
            options.title,
            options.message,
            [
              {
                text: "Cancelar",
                style: "cancel",
                onPress: () => finish(false),
              },
              {
                text: options.label || "Confirmar",
                style: options.danger ? "destructive" : "default",
                onPress: () => finish(true),
              },
            ],
            { cancelable: true, onDismiss: () => finish(false) },
          );
        } else {
          setPending(options);
        }
      }),
    [],
  );
  const run: Actions["run"] = async (
    path,
    options,
    message,
    syncPublic = false,
    after,
  ) => {
    if (lock.current || !authorized.current) return false;
    lock.current = true;
    setBusy(true);
    setFeedback(null);
    try {
      const result = await worker<{ ok?: boolean; erro?: string }>(
        path,
        options,
      );
      if (!result || result.ok !== true || result.erro)
        throw new Error(
          result?.erro ||
            "O servidor não confirmou a alteração. Atualize os dados antes de tentar novamente.",
        );
      setFeedback({ kind: "success", message });
      // A successful write is never retried because a subsequent read failed.
      try {
        await query.refresh();
        if (syncPublic) await refreshSiteState();
        if (after) await after();
      } catch (error) {
        setFeedback({
          kind: "info",
          message: `${message} A atualização da tela falhou: ${errorMessage(error)}. Atualize antes de repetir a ação.`,
        });
      }
      return true;
    } catch (error) {
      setFeedback({ kind: "error", message: errorMessage(error) });
      return false;
    } finally {
      lock.current = false;
      setBusy(false);
    }
  };
  const actions: Actions = {
    busy,
    confirm,
    run,
    error: feedback?.kind === "error" ? feedback.message : undefined,
  };
  const data = query.data;
  const usable = !!data && data.ok !== false && !!data.settings;
  const refresh = async () => {
    if (lock.current) return;
    setFeedback(null);
    try {
      await query.refresh();
    } catch (error) {
      setFeedback({ kind: "error", message: errorMessage(error) });
    }
  };
  return (
    <Page
      title="Administração"
      eyebrow="CONTROLE SEDX"
      subtitle={`Sessão autorizada · ${String(session?.usuario || "")}`}
      onRefresh={refresh}
    >
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={s.tabs}
      >
        {TABS.map((item) => (
          <Pressable
            key={item.id}
            accessibilityRole="tab"
            accessibilityState={{ selected: tab === item.id, disabled: busy }}
            disabled={busy}
            onPress={() => {
              setTab(item.id);
              setFeedback(null);
            }}
            style={[s.tab, tab === item.id && s.choiceActive]}
          >
            <Text style={[s.choiceText, tab === item.id && s.choiceTextActive]}>
              {item.label}
            </Text>
          </Pressable>
        ))}
      </ScrollView>
      <LoadState
        loading={query.loading}
        error={query.error}
        refresh={refresh}
      />
      {feedback ? <Notice {...feedback} /> : null}
      {busy ? (
        <View style={s.loading}>
          <ActivityIndicator color={C.accent} />
          <Body>Aplicando alteração no servidor…</Body>
        </View>
      ) : null}
      {!usable && !query.loading && !query.error ? (
        <Notice
          kind="error"
          message="O servidor não retornou os dados administrativos esperados. Atualize ou entre novamente."
        />
      ) : null}
      {usable && !query.error ? (
        <View style={s.stack}>
          {tab === "overview" ? <Overview data={data!} onTab={setTab} /> : null}
          {tab === "notices" ? (
            <Notices items={list(data!.notices)} actions={actions} />
          ) : null}
          {tab === "users" ? (
            <Users
              items={list(data!.users)}
              actions={actions}
              ownRa={digits(session?.usuario)}
            />
          ) : null}
          {tab === "settings" ? (
            <SettingsTab settings={data!.settings} actions={actions} />
          ) : null}
          {tab === "audit" ? <Audit actions={actions} /> : null}
          {tab === "tools" ? <Tools actions={actions} /> : null}
          {tab === "partnerships" ? <Partnerships actions={actions} /> : null}
          {tab === "help" ? (
            <Help actions={actions} sessionRa={digits(session?.usuario)} />
          ) : null}
          {tab === "moderation" ? <Moderation actions={actions} /> : null}
        </View>
      ) : null}
      {pending ? (
        <Modal
          transparent
          visible
          animationType="fade"
          onRequestClose={() => settle(false)}
        >
          <View style={s.backdrop}>
            <View style={s.confirm} accessibilityViewIsModal>
              <Title>{pending.title}</Title>
              <Body>{pending.message}</Body>
              <View style={s.wrap}>
                <Button
                  label="Cancelar"
                  variant="secondary"
                  onPress={() => settle(false)}
                />
                <Button
                  label={pending.label || "Confirmar"}
                  variant={pending.danger ? "danger" : "primary"}
                  onPress={() => settle(true)}
                />
              </View>
            </View>
          </View>
        </Modal>
      ) : null}
    </Page>
  );
}

function Overview({
  data,
  onTab,
}: {
  data: AdminData;
  onTab: (tab: Tab) => void;
}) {
  const metrics = [
    {
      label: "Leituras do estado público",
      value: data.stats?.accesses,
      note: "Contador real do Worker; não representa visitantes únicos.",
    },
    {
      label: "Usuários registrados",
      value: data.stats?.users ?? list(data.users).length,
      note: "Contas retornadas pelo servidor.",
    },
    {
      label: "Usuários ativos",
      value:
        data.stats?.active ??
        list(data.users).filter((user) => user.status === "Ativo").length,
      note: "Classificação registrada no backend.",
    },
    {
      label: "Avisos publicados",
      value: data.stats?.notices ?? list(data.notices).length,
      note: "Até 100 avisos na consulta atual.",
    },
  ];
  return (
    <>
      <View style={s.metrics}>
        {metrics.map((metric) => (
          <Card key={metric.label} style={s.metric}>
            <Label>{metric.label}</Label>
            <Text style={s.metricValue}>
              {metric.value == null
                ? "—"
                : Number(metric.value).toLocaleString("pt-BR")}
            </Text>
            <Text style={s.muted}>{metric.note}</Text>
          </Card>
        ))}
      </View>
      <Card title="Estado global">
        <View style={s.stack}>
          <Pill
            label={
              data.settings.maintenance
                ? "Manutenção ativa"
                : "Manutenção desativada"
            }
            color={data.settings.maintenance ? C.red : C.green}
          />
          <Body>
            Tema publicado:{" "}
            {THEMES.find((theme) => theme.value === data.settings.activeTheme)
              ?.label || "Original"}
          </Body>
          <Body>
            Assistente de suporte:{" "}
            {data.settings.supportAssistant ? "ativo" : "desativado"}
          </Body>
          <Notice message="A consulta administrativa respondeu. Esta tela não realiza testes de saúde dos serviços SED ou EduSP nem exibe métricas simuladas." />
        </View>
      </Card>
      <Card title="Acesso rápido">
        <View style={s.wrap}>
          <Button label="Publicar aviso" onPress={() => onTab("notices")} />
          <Button
            label="Gerenciar usuários"
            variant="secondary"
            onPress={() => onTab("users")}
          />
          <Button
            label="Parcerias"
            variant="secondary"
            onPress={() => onTab("partnerships")}
          />
          <Button
            label="Manutenção e tema"
            variant="secondary"
            onPress={() => onTab("settings")}
          />
        </View>
      </Card>
    </>
  );
}

function Notices({
  items,
  actions,
}: {
  items: NoticeRecord[];
  actions: Actions;
}) {
  const [editor, setEditor] = useState<NoticeRecord | null>(null);
  const remove = async (item: NoticeRecord) => {
    if (
      await actions.confirm({
        title: "Excluir aviso?",
        message: `“${item.title}” será removido para todos os alunos. Esta ação não pode ser desfeita.`,
        danger: true,
        label: "Excluir aviso",
      })
    )
      await actions.run(
        `/admin/notification?id=${encodeURIComponent(item.id)}`,
        { method: "DELETE" },
        "Aviso excluído.",
        true,
      );
  };
  return (
    <>
      <Card title="Avisos e notificações">
        <View style={s.stack}>
          <Body>Comunicados reais publicados para os alunos.</Body>
          <Button
            label="Novo aviso"
            disabled={actions.busy}
            onPress={() =>
              setEditor({
                id: "",
                title: "",
                description: "",
                audience: "Todos os alunos",
                image: "",
              })
            }
          />
        </View>
      </Card>
      {!items.length ? (
        <Empty
          title="Nenhum aviso publicado"
          description="Crie o primeiro comunicado quando estiver pronto."
        />
      ) : (
        items.map((item) => (
          <Card key={item.id} title={item.title}>
            <View style={s.stack}>
              <Text style={s.muted}>
                {dateLabel(item.publishedAt)} ·{" "}
                {item.audience || "Todos os alunos"}
              </Text>
              <Body>{item.description}</Body>
              <RemoteImage uri={item.image} label="Imagem do aviso" />
              <View style={s.wrap}>
                <Button
                  label="Editar"
                  variant="secondary"
                  disabled={actions.busy}
                  onPress={() => setEditor(item)}
                />
                <Button
                  label="Excluir"
                  variant="danger"
                  disabled={actions.busy}
                  onPress={() => {
                    void remove(item);
                  }}
                />
              </View>
            </View>
          </Card>
        ))
      )}
      {editor ? (
        <NoticeEditor
          key={editor.id || "new"}
          initial={editor}
          actions={actions}
          close={() => setEditor(null)}
        />
      ) : null}
    </>
  );
}
function NoticeEditor({
  initial,
  actions,
  close,
}: {
  initial: NoticeRecord;
  actions: Actions;
  close: () => void;
}) {
  const [draft, setDraft] = useState(initial);
  const [error, setError] = useState("");
  const [preview, setPreview] = useState(false);
  const change = (key: keyof NoticeRecord, value: string) =>
    setDraft((current) => ({ ...current, [key]: value }));
  const validate = () => {
    if (
      !draft.title.trim() ||
      draft.title.trim().length > 120 ||
      !draft.description.trim() ||
      draft.description.trim().length > 1000
    )
      return "Informe título (até 120) e descrição (até 1.000 caracteres).";
    if (!draft.audience.trim() || draft.audience.trim().length > 80)
      return "Informe o público, com até 80 caracteres.";
    if (!validImage(draft.image || "", 5 * 1024 * 1024, true))
      return "Imagem inválida. Use URL http/https sem credenciais ou imagem da galeria até 5 MB.";
    return "";
  };
  const save = async () => {
    const invalid = validate();
    setError(invalid);
    if (invalid) return;
    if (
      !(await actions.confirm({
        title: initial.id ? "Atualizar aviso?" : "Publicar aviso?",
        message: `O comunicado “${draft.title.trim()}” ficará visível para ${draft.audience.trim()}.`,
        label: initial.id ? "Salvar alteração" : "Publicar",
      }))
    )
      return;
    const ok = await actions.run(
      "/admin/notification",
      {
        method: initial.id ? "PUT" : "POST",
        body: {
          ...(initial.id ? { id: initial.id } : {}),
          title: draft.title.trim(),
          description: draft.description.trim(),
          audience: draft.audience.trim(),
          image: draft.image || "",
          ...(initial.publishedAt ? { publishedAt: initial.publishedAt } : {}),
        },
      },
      "Aviso salvo no servidor.",
      true,
    );
    if (ok) close();
    else
      setError(
        "O aviso não foi salvo. Verifique o erro do servidor no painel e tente novamente.",
      );
  };
  return (
    <EditorWindow
      title={initial.id ? "Editar aviso" : "Novo aviso"}
      busy={actions.busy}
      error={actions.error || error}
      onClose={close}
    >
      {preview ? (
        <Card title={draft.title}>
          <View style={s.stack}>
            <Pill label={draft.audience} />
            <Body>{draft.description}</Body>
            <RemoteImage uri={draft.image} label="Prévia do aviso" />
          </View>
        </Card>
      ) : (
        <>
          <Input
            label="Título"
            value={draft.title}
            maxLength={120}
            editable={!actions.busy}
            onChangeText={(value) => change("title", value)}
          />
          <Input
            label="Descrição"
            value={draft.description}
            multiline
            maxLength={1000}
            style={s.multiline}
            editable={!actions.busy}
            onChangeText={(value) => change("description", value)}
          />
          <Input
            label="Público / área de publicação"
            value={draft.audience}
            maxLength={80}
            editable={!actions.busy}
            onChangeText={(value) => change("audience", value)}
          />
          <ImageField
            label="Imagem do aviso"
            value={draft.image || ""}
            onChange={(value) => change("image", value)}
            maxBytes={5 * 1024 * 1024}
            allowRemote
            disabled={actions.busy}
          />
        </>
      )}
      <View style={s.wrap}>
        <Button
          label={preview ? "Voltar à edição" : "Pré-visualizar"}
          variant="secondary"
          disabled={actions.busy}
          onPress={() => {
            const invalid = validate();
            setError(invalid);
            if (!invalid || preview) setPreview(!preview);
          }}
        />
        {preview ? (
          <Button
            label={initial.id ? "Salvar alterações" : "Publicar aviso"}
            loading={actions.busy}
            onPress={() => {
              void save();
            }}
          />
        ) : null}
      </View>
    </EditorWindow>
  );
}

function Users({
  items,
  actions,
  ownRa,
}: {
  items: UserRecord[];
  actions: Actions;
  ownRa: string;
}) {
  const [search, setSearch] = useState("");
  const [editor, setEditor] = useState<UserRecord | null>(null);
  const filtered = items.filter((item) =>
    `${item.name} ${item.ra}`
      .toLowerCase()
      .includes(search.toLowerCase().trim()),
  );
  const toggle = async (item: UserRecord) => {
    const active = item.status === "Ativo";
    if (
      !(await actions.confirm({
        title: active ? "Suspender usuário?" : "Reativar usuário?",
        message: `${item.name} · RA ${item.ra}.${digits(item.ra) === ownRa ? " Você está alterando a própria conta." : ""} A alteração será registrada no servidor.`,
        danger: active,
        label: active ? "Suspender" : "Reativar",
      }))
    )
      return;
    await actions.run(
      "/admin/user",
      {
        method: "PUT",
        body: { ...item, status: active ? "Suspenso" : "Ativo" },
      },
      "Status do usuário atualizado.",
    );
  };
  return (
    <>
      <Card title="Contas e permissões">
        <View style={s.stack}>
          <Input
            label="Buscar nome ou RA"
            value={search}
            onChangeText={setSearch}
            placeholder="Digite para filtrar"
          />
          <Body>
            {filtered.length} de {items.length} contas reais
          </Body>
          <Notice message="A permissão Administrador está restrita aos proprietários autorizados pelo backend. Alterar um rótulo não libera acesso localmente." />
        </View>
      </Card>
      {!filtered.length ? (
        <Empty
          title={
            items.length ? "Nenhum resultado" : "Nenhum usuário registrado"
          }
        />
      ) : (
        filtered.map((item) => (
          <Card key={item.ra} title={item.name || item.ra}>
            <View style={s.stack}>
              <Body>
                RA {item.ra}
                {digits(item.ra) === ownRa ? " · Sua conta" : ""}
              </Body>
              <View style={s.wrap}>
                <Pill label={item.role || "Aluno"} />
                <Pill
                  label={item.status}
                  color={item.status === "Ativo" ? C.green : C.red}
                />
              </View>
              <Text style={s.muted}>
                Último acesso: {dateLabel(item.lastSeen)}
              </Text>
              <View style={s.wrap}>
                <Button
                  label="Editar perfil"
                  variant="secondary"
                  disabled={actions.busy}
                  onPress={() => setEditor(item)}
                />
                <Button
                  label={item.status === "Ativo" ? "Suspender" : "Reativar"}
                  variant={item.status === "Ativo" ? "danger" : "secondary"}
                  disabled={actions.busy}
                  onPress={() => {
                    void toggle(item);
                  }}
                />
              </View>
            </View>
          </Card>
        ))
      )}
      {editor ? (
        <UserEditor
          initial={editor}
          actions={actions}
          close={() => setEditor(null)}
        />
      ) : null}
    </>
  );
}
function UserEditor({
  initial,
  actions,
  close,
}: {
  initial: UserRecord;
  actions: Actions;
  close: () => void;
}) {
  const [name, setName] = useState(initial.name);
  const [role, setRole] = useState(initial.role || "Aluno");
  const [error, setError] = useState("");
  const save = async () => {
    if (!name.trim() || name.trim().length > 120) {
      setError("Informe um nome de até 120 caracteres.");
      return;
    }
    if (
      !(await actions.confirm({
        title: "Atualizar usuário?",
        message: `RA ${initial.ra}: nome “${name.trim()}”, permissão ${role}. O servidor verificará a autorização.`,
        label: "Salvar perfil",
        danger: role !== initial.role,
      }))
    )
      return;
    if (
      await actions.run(
        "/admin/user",
        { method: "PUT", body: { ...initial, name: name.trim(), role } },
        "Perfil do usuário atualizado.",
      )
    )
      close();
    else
      setError(
        "O perfil não foi salvo. Consulte a resposta do servidor no painel.",
      );
  };
  return (
    <EditorWindow
      title="Editar usuário"
      busy={actions.busy}
      error={actions.error || error}
      onClose={close}
    >
      <Body>RA {initial.ra} · identificador não editável</Body>
      <Input
        label="Nome"
        value={name}
        onChangeText={setName}
        maxLength={120}
        editable={!actions.busy}
      />
      <Choices
        label="Permissão"
        value={role}
        options={["Aluno", "Moderador", "Administrador"].map((value) => ({
          value,
          label: value,
        }))}
        onChange={setRole}
        disabled={actions.busy}
      />
      <Button
        label="Salvar perfil"
        onPress={() => {
          void save();
        }}
        loading={actions.busy}
      />
    </EditorWindow>
  );
}

function SettingsTab({
  settings,
  actions,
}: {
  settings: Settings;
  actions: Actions;
}) {
  const [editing, setEditing] = useState(false);
  const theme =
    THEMES.find((item) => item.value === settings.activeTheme)?.label ||
    "Original";
  const maintenance = async () => {
    const next = !settings.maintenance;
    if (
      !(await actions.confirm({
        title: next ? "Ativar manutenção?" : "Encerrar manutenção?",
        message: next
          ? "O modo de manutenção será publicado para todos os alunos. Novas operações podem ficar indisponíveis até ser desativado."
          : "O modo de manutenção será desativado globalmente.",
        danger: next,
        label: next ? "Ativar manutenção" : "Desativar",
      }))
    )
      return;
    await actions.run(
      "/admin/settings",
      {
        method: "PUT",
        body: {
          maintenance: next,
          maintenanceMessage: settings.maintenanceMessage || "",
        },
      },
      next ? "Manutenção ativada." : "Manutenção desativada.",
      true,
    );
  };
  return (
    <>
      <Card title="Configurações globais">
        <View style={s.stack}>
          <Body>{settings.siteName || "SEDX"}</Body>
          <Body>{settings.welcome || "Mensagem inicial não definida."}</Body>
          <Body>Suporte: {settings.support || "Não definido"}</Body>
          <Body>Tema: {theme}</Body>
          <Body>
            Assistente de suporte:{" "}
            {settings.supportAssistant ? "ativo" : "desativado"}
          </Body>
          <Button
            label="Editar configurações e tema"
            disabled={actions.busy}
            onPress={() => setEditing(true)}
          />
        </View>
      </Card>
      <Card title="Operação e manutenção">
        <View style={s.stack}>
          <Pill
            label={
              settings.maintenance
                ? "Manutenção ativa"
                : "Manutenção desativada"
            }
            color={settings.maintenance ? C.red : C.green}
          />
          <Body>
            {settings.maintenanceMessage ||
              "Mensagem de manutenção não definida."}
          </Body>
          <Button
            label={
              settings.maintenance
                ? "Desativar manutenção"
                : "Ativar manutenção"
            }
            variant={settings.maintenance ? "secondary" : "danger"}
            disabled={actions.busy}
            onPress={() => {
              void maintenance();
            }}
          />
          <Notice message="Não há limpeza de cache global no backend. Atualizar a tela apenas consulta o estado real; não apaga a sessão nem registros de auditoria." />
        </View>
      </Card>
      {editing ? (
        <SettingsEditor
          initial={settings}
          actions={actions}
          close={() => setEditing(false)}
        />
      ) : null}
    </>
  );
}
function SettingsEditor({
  initial,
  actions,
  close,
}: {
  initial: Settings;
  actions: Actions;
  close: () => void;
}) {
  const [draft, setDraft] = useState<Settings>({ ...initial });
  const [error, setError] = useState("");
  const change = <K extends keyof Settings>(key: K, value: Settings[K]) =>
    setDraft((current) => ({ ...current, [key]: value }));
  const save = async () => {
    if (!draft.siteName?.trim() || draft.siteName.trim().length > 120) {
      setError("Informe o nome do site, com até 120 caracteres.");
      return;
    }
    for (const key of ["logo", "favicon"] as const) {
      const value = draft[key]?.trim() || "";
      if (
        value &&
        !(value.startsWith("/") && !value.startsWith("//")) &&
        !validUrl(value)
      ) {
        setError(
          `${key === "logo" ? "Logo" : "Favicon"}: use URL http/https sem credenciais ou um caminho relativo iniciado por /.`,
        );
        return;
      }
    }
    const support = draft.support?.trim() || "";
    if (
      support &&
      !validUrl(support) &&
      !/^(?:mailto:)?[^\s@]+@[^\s@]+\.[^\s@]+$/.test(support)
    ) {
      setError("Suporte deve ser um link http/https válido ou e-mail.");
      return;
    }
    if (
      !(await actions.confirm({
        title: "Salvar configurações globais?",
        message:
          "Nome, mensagens, recursos, tema e assistente de suporte serão alterados para o site. A escolha de tema é sincronizada pelo servidor.",
        label: "Salvar configurações",
      }))
    )
      return;
    // Send only editable keys, never an arbitrary server object or session metadata.
    const body: Settings = {
      siteName: draft.siteName.trim(),
      logo: draft.logo?.trim() || "",
      favicon: draft.favicon?.trim() || "",
      welcome: draft.welcome?.trim() || "",
      support,
      maintenanceMessage: draft.maintenanceMessage?.trim() || "",
    };
    for (const key of [
      "featureIa",
      "featureApostilas",
      "supportAssistant",
    ] as const)
      if (typeof draft[key] === "boolean") body[key] = draft[key];
    if (
      draft.activeTheme &&
      THEMES.some((item) => item.value === draft.activeTheme)
    )
      body.activeTheme = draft.activeTheme;
    if (
      await actions.run(
        "/admin/settings",
        { method: "PUT", body },
        "Configurações salvas.",
        true,
      )
    )
      close();
    else
      setError(
        "As configurações não foram salvas. Consulte o erro do servidor no painel.",
      );
  };
  return (
    <EditorWindow
      title="Identidade e comportamento"
      busy={actions.busy}
      error={actions.error || error}
      onClose={close}
    >
      <Input
        label="Nome do site"
        value={draft.siteName || ""}
        maxLength={120}
        onChangeText={(value) => change("siteName", value)}
        editable={!actions.busy}
      />
      <Input
        label="URL ou caminho do logotipo"
        value={draft.logo || ""}
        maxLength={2048}
        autoCapitalize="none"
        onChangeText={(value) => change("logo", value)}
        editable={!actions.busy}
      />
      <Input
        label="URL ou caminho do favicon (site)"
        value={draft.favicon || ""}
        maxLength={2048}
        autoCapitalize="none"
        onChangeText={(value) => change("favicon", value)}
        editable={!actions.busy}
      />
      <Input
        label="Mensagem inicial"
        value={draft.welcome || ""}
        multiline
        style={s.multiline}
        maxLength={1000}
        onChangeText={(value) => change("welcome", value)}
        editable={!actions.busy}
      />
      <Input
        label="E-mail ou link de suporte"
        value={draft.support || ""}
        maxLength={2048}
        autoCapitalize="none"
        onChangeText={(value) => change("support", value)}
        editable={!actions.busy}
      />
      <Input
        label="Mensagem de manutenção"
        value={draft.maintenanceMessage || ""}
        multiline
        style={s.multiline}
        maxLength={2000}
        onChangeText={(value) => change("maintenanceMessage", value)}
        editable={!actions.busy}
      />
      <Toggle
        label="Inteligência artificial"
        description="Ativação global registrada no servidor."
        value={draft.featureIa === true}
        onChange={(value) => change("featureIa", value)}
        disabled={actions.busy}
      />
      <Toggle
        label="Apostilas"
        value={draft.featureApostilas === true}
        onChange={(value) => change("featureApostilas", value)}
        disabled={actions.busy}
      />
      <Toggle
        label="Assistente de suporte"
        description="Respostas automáticas na Central de Ajuda."
        value={draft.supportAssistant === true}
        onChange={(value) => change("supportAssistant", value)}
        disabled={actions.busy}
      />
      <Choices
        label="Tema global"
        value={draft.activeTheme || "default"}
        options={THEMES}
        onChange={(value) => change("activeTheme", value)}
        disabled={actions.busy}
      />
      <Notice message="Temas alteram o estado compartilhado. Efeitos sazonais dependem do suporte de cada tela do aplicativo. O favicon se aplica somente ao site." />
      <Button
        label="Salvar configurações"
        loading={actions.busy}
        onPress={() => {
          void save();
        }}
      />
    </EditorWindow>
  );
}

function Audit({ actions }: { actions: Actions }) {
  const query = useWorker<{ audit: AuditRecord[] }>("/admin/audit");
  const [search, setSearch] = useState("");
  const entries = list(query.data?.audit).filter((item) =>
    `${item.action} ${item.detail} ${item.actor}`
      .toLowerCase()
      .includes(search.toLowerCase().trim()),
  );
  return (
    <>
      <Card title="Rastreabilidade">
        <View style={s.stack}>
          <Body>Últimos 100 registros do backend, em ordem decrescente.</Body>
          <Input
            label="Filtrar ação, detalhe ou autor"
            value={search}
            onChangeText={setSearch}
          />
          <Button
            label="Atualizar auditoria"
            variant="secondary"
            disabled={actions.busy || query.loading}
            onPress={() => {
              void query.refresh();
            }}
          />
          <Notice message="Registros somente para leitura. O Worker ativo não oferece rota para limpar auditoria." />
        </View>
      </Card>
      <LoadState
        loading={query.loading}
        error={query.error}
        refresh={query.refresh}
      />
      {!query.loading && !query.error && !entries.length ? (
        <Empty title="Nenhum registro encontrado" />
      ) : null}
      {!query.error
        ? entries.map((item) => (
            <Card key={item.id} title={item.action}>
              <View style={s.stack}>
                <Body>{item.detail}</Body>
                <Text style={s.muted}>
                  {dateLabel(item.at)} · RA {item.actor}
                </Text>
              </View>
            </Card>
          ))
        : null}
    </>
  );
}

function Tools({ actions }: { actions: Actions }) {
  const query = useWorker<{ tools: ToolRecord[] }>("/site-state");
  const [editing, setEditing] = useState(false);
  return (
    <>
      <Card title="Ferramentas publicadas">
        <View style={s.stack}>
          <Body>
            Publique um texto para copiar ou um link de site. O Worker permite
            criação, não edição ou exclusão de ferramentas.
          </Body>
          <Button
            label="Criar ferramenta"
            disabled={actions.busy}
            onPress={() => setEditing(true)}
          />
          <Button
            label="Atualizar lista"
            variant="secondary"
            disabled={actions.busy || query.loading}
            onPress={() => {
              void query.refresh();
            }}
          />
        </View>
      </Card>
      <LoadState
        loading={query.loading}
        error={query.error}
        refresh={query.refresh}
      />
      {!query.error && !query.loading && !list(query.data?.tools).length ? (
        <Empty title="Nenhuma ferramenta publicada" />
      ) : null}
      {!query.error
        ? list(query.data?.tools).map((item) => (
            <Card key={item.id} title={item.title}>
              <View style={s.stack}>
                <Pill
                  label={item.actionType === "site" ? "Site" : "Copiar texto"}
                />
                <Body>{item.description}</Body>
                <RemoteImage uri={item.image} label="Imagem da ferramenta" />
                <Text selectable style={s.content}>
                  {item.content}
                </Text>
              </View>
            </Card>
          ))
        : null}
      {editing ? (
        <ToolEditor
          actions={actions}
          close={() => setEditing(false)}
          refresh={query.refresh}
        />
      ) : null}
    </>
  );
}
function ToolEditor({
  actions,
  close,
  refresh,
}: {
  actions: Actions;
  close: () => void;
  refresh: () => unknown;
}) {
  const [draft, setDraft] = useState<ToolRecord>(() => ({
    id: `tool-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    title: "",
    description: "",
    image: "",
    actionType: "copy",
    content: "",
  }));
  const [error, setError] = useState("");
  const [preview, setPreview] = useState(false);
  const change = (key: keyof ToolRecord, value: string) =>
    setDraft((current) => ({ ...current, [key]: value }));
  const validate = () => {
    if (
      !draft.title.trim() ||
      draft.title.trim().length > 120 ||
      !draft.description.trim() ||
      draft.description.trim().length > 1000
    )
      return "Informe título (até 120) e descrição (até 1.000 caracteres).";
    if (
      !draft.content.trim() ||
      draft.content.trim().length > (draft.actionType === "site" ? 2048 : 4000)
    )
      return "Conteúdo obrigatório: até 2.048 caracteres para site ou 4.000 para texto.";
    if (draft.actionType === "site" && !validUrl(draft.content))
      return "Use um site http/https válido sem credenciais na URL.";
    if (!validImage(draft.image || "", 250 * 1024))
      return "Imagem inválida ou maior que 250 KB.";
    return "";
  };
  const save = async () => {
    const invalid = validate();
    setError(invalid);
    if (invalid) return;
    if (
      !(await actions.confirm({
        title: "Publicar ferramenta?",
        message: `“${draft.title.trim()}” ficará disponível para todos os alunos. Não há endpoint de exclusão no backend ativo.`,
        label: "Publicar",
      }))
    )
      return;
    if (
      await actions.run(
        "/admin/tools",
        {
          method: "POST",
          body: {
            ...draft,
            title: draft.title.trim(),
            description: draft.description.trim(),
            content: draft.content.trim(),
          },
        },
        "Ferramenta publicada.",
        true,
        refresh,
      )
    )
      close();
    else
      setError(
        "A ferramenta não foi publicada. Consulte o erro do servidor no painel.",
      );
  };
  return (
    <EditorWindow
      title="Nova ferramenta"
      busy={actions.busy}
      error={actions.error || error}
      onClose={close}
    >
      {preview ? (
        <Card title={draft.title}>
          <View style={s.stack}>
            <Body>{draft.description}</Body>
            <Pill
              label={
                draft.actionType === "site" ? "Abrir site" : "Copiar texto"
              }
            />
            <RemoteImage uri={draft.image} label="Prévia da ferramenta" />
            <Text selectable style={s.content}>
              {draft.content}
            </Text>
          </View>
        </Card>
      ) : (
        <>
          <Input
            label="Título"
            value={draft.title}
            maxLength={120}
            onChangeText={(value) => change("title", value)}
            editable={!actions.busy}
          />
          <Input
            label="Descrição"
            value={draft.description}
            maxLength={1000}
            multiline
            style={s.multiline}
            onChangeText={(value) => change("description", value)}
            editable={!actions.busy}
          />
          <Choices
            label="Ação"
            value={draft.actionType}
            options={[
              { value: "copy", label: "Copiar texto" },
              { value: "site", label: "Abrir site" },
            ]}
            onChange={(value) => change("actionType", value)}
            disabled={actions.busy}
          />
          <Input
            label={
              draft.actionType === "site" ? "URL do site" : "Texto para copiar"
            }
            value={draft.content}
            maxLength={draft.actionType === "site" ? 2048 : 4000}
            multiline
            style={s.multiline}
            autoCapitalize="none"
            onChangeText={(value) => change("content", value)}
            editable={!actions.busy}
          />
          <ImageField
            label="Imagem da ferramenta"
            value={draft.image || ""}
            onChange={(value) => change("image", value)}
            disabled={actions.busy}
          />
        </>
      )}
      <View style={s.wrap}>
        <Button
          label={preview ? "Voltar à edição" : "Pré-visualizar"}
          variant="secondary"
          disabled={actions.busy}
          onPress={() => {
            const invalid = validate();
            setError(invalid);
            if (!invalid || preview) setPreview(!preview);
          }}
        />
        {preview ? (
          <Button
            label="Publicar ferramenta"
            loading={actions.busy}
            onPress={() => {
              void save();
            }}
          />
        ) : null}
      </View>
    </EditorWindow>
  );
}

function PartnershipCard({
  item,
  preview = false,
}: {
  item: Partnership;
  preview?: boolean;
}) {
  let host = "";
  try {
    host = new URL(item.destinationUrl).host;
  } catch {
    host = item.destinationUrl;
  }
  return (
    <View style={s.stack}>
      {item.banner ? (
        <RemoteImage uri={item.banner} label="Banner da parceria" />
      ) : (
        <View style={s.banner}>
          <Text style={s.bannerText}>PARCERIA SEDX</Text>
        </View>
      )}
      <RemoteImage uri={item.logo} label="Logo da parceria" logo />
      <View style={s.wrap}>
        <Pill label={item.type} />
        <Pill
          label={
            preview
              ? "Pré-visualização"
              : published(item.isPublished)
                ? "Publicada"
                : "Rascunho"
          }
          color={!preview && published(item.isPublished) ? C.green : C.muted}
        />
      </View>
      <Title>{item.title || "Título da parceria"}</Title>
      <Body>{item.description}</Body>
      <Text selectable style={s.muted}>
        {host}
      </Text>
      {preview ? (
        <View style={s.previewButton}>
          <Text style={s.label}>Conhecer parceria</Text>
        </View>
      ) : null}
    </View>
  );
}
function Partnerships({ actions }: { actions: Actions }) {
  const query = useWorker<{ partnerships: Partnership[] }>(
    "/admin/partnerships",
  );
  const [editor, setEditor] = useState<{
    item: Partnership;
    preview: boolean;
    statusOnly: boolean;
  } | null>(null);
  const [filter, setFilter] = useState("all");
  const [linkError, setLinkError] = useState("");
  const items = list(query.data?.partnerships).filter(
    (item) =>
      filter === "all" ||
      (filter === "published"
        ? published(item.isPublished)
        : !published(item.isPublished)),
  );
  const open = (item?: Partnership, preview = false, statusOnly = false) =>
    setEditor({
      item: item || {
        id: `partnership-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        title: "",
        description: "",
        logo: "",
        banner: "",
        destinationUrl: "",
        type: "Outro",
        isPublished: false,
      },
      preview,
      statusOnly,
    });
  const remove = async (item: Partnership) => {
    if (
      await actions.confirm({
        title: "Excluir parceria?",
        message: `“${item.title}” será excluída permanentemente, incluindo seu rascunho. Esta ação não pode ser desfeita.`,
        danger: true,
        label: "Excluir parceria",
      })
    )
      await actions.run(
        `/admin/partnerships?id=${encodeURIComponent(item.id)}`,
        { method: "DELETE" },
        "Parceria excluída.",
        true,
        query.refresh,
      );
  };
  const unpublish = async (item: Partnership) => {
    if (
      await actions.confirm({
        title: "Despublicar parceria?",
        message: `“${item.title}” deixará de aparecer aos alunos e ficará como rascunho administrativo.`,
        danger: true,
        label: "Despublicar",
      })
    )
      await actions.run(
        "/admin/partnerships/status",
        { method: "PUT", body: { id: item.id, isPublished: false } },
        "Parceria despublicada.",
        true,
        query.refresh,
      );
  };
  const visit = async (item: Partnership) => {
    setLinkError("");
    if (!validUrl(item.destinationUrl)) return;
    if (
      await actions.confirm({
        title: "Abrir link externo?",
        message: `Você sairá do aplicativo para acessar ${item.destinationUrl}.`,
        label: "Abrir link",
      })
    ) {
      try {
        await Linking.openURL(item.destinationUrl);
      } catch (error) {
        setLinkError(`Não foi possível abrir o link: ${errorMessage(error)}`);
      }
    }
  };
  return (
    <>
      <Card title="Conexões que somam">
        <View style={s.stack}>
          <Body>
            Cadastre, revise e publique parcerias. Rascunhos são retornados
            apenas na listagem administrativa.
          </Body>
          <View style={s.wrap}>
            <Button
              label="Nova parceria"
              disabled={actions.busy}
              onPress={() => open()}
            />
            <Button
              label="Atualizar"
              variant="secondary"
              disabled={actions.busy || query.loading}
              onPress={() => {
                void query.refresh();
              }}
            />
          </View>
          <Choices
            label="Exibir"
            value={filter}
            options={[
              { value: "all", label: "Todas" },
              { value: "published", label: "Publicadas" },
              { value: "draft", label: "Rascunhos" },
            ]}
            onChange={setFilter}
          />
        </View>
      </Card>
      {linkError ? <Notice kind="error" message={linkError} /> : null}
      <LoadState
        loading={query.loading}
        error={query.error}
        refresh={query.refresh}
      />
      {!query.loading && !query.error && !items.length ? (
        <Empty
          title="Nenhuma parceria encontrada"
          description="Cadastre uma parceria ou altere o filtro."
        />
      ) : null}
      {!query.error
        ? items.map((item) => (
            <Card key={item.id}>
              <View style={s.stack}>
                <PartnershipCard item={item} />
                <Text style={s.muted}>
                  Atualizada: {dateLabel(item.updatedAt)}
                </Text>
                <View style={s.wrap}>
                  <Button
                    label="Editar"
                    variant="secondary"
                    disabled={actions.busy}
                    onPress={() => open(item)}
                  />
                  <Button
                    label={
                      published(item.isPublished)
                        ? "Despublicar"
                        : "Revisar e publicar"
                    }
                    variant="secondary"
                    disabled={actions.busy}
                    onPress={() => {
                      if (published(item.isPublished)) void unpublish(item);
                      else open(item, true, true);
                    }}
                  />
                  <Button
                    label="Excluir"
                    variant="danger"
                    disabled={actions.busy}
                    onPress={() => {
                      void remove(item);
                    }}
                  />
                  {validUrl(item.destinationUrl) ? (
                    <Button
                      label="Abrir destino"
                      variant="secondary"
                      disabled={actions.busy}
                      onPress={() => {
                        void visit(item);
                      }}
                    />
                  ) : null}
                </View>
              </View>
            </Card>
          ))
        : null}
      {editor ? (
        <PartnershipEditor
          key={editor.item.id}
          initial={editor.item}
          previewFirst={editor.preview}
          statusOnly={editor.statusOnly}
          actions={actions}
          close={() => setEditor(null)}
          refresh={query.refresh}
        />
      ) : null}
    </>
  );
}
function PartnershipEditor({
  initial,
  previewFirst,
  statusOnly,
  actions,
  close,
  refresh,
}: {
  initial: Partnership;
  previewFirst: boolean;
  statusOnly: boolean;
  actions: Actions;
  close: () => void;
  refresh: () => unknown;
}) {
  const [draft, setDraft] = useState<Partnership>({
    ...initial,
    isPublished: published(initial.isPublished),
  });
  const [preview, setPreview] = useState(previewFirst);
  const [unchanged, setUnchanged] = useState(statusOnly);
  const [error, setError] = useState("");
  const change = (key: keyof Partnership, value: string) => {
    setUnchanged(false);
    setDraft((current) => ({ ...current, [key]: value }));
  };
  const showPreview = () => {
    const invalid = validatePartnership(draft);
    setError(invalid);
    if (!invalid) setPreview(true);
  };
  const save = async (isPublished: boolean) => {
    const invalid = validatePartnership(draft);
    setError(invalid);
    if (invalid) {
      setPreview(false);
      return;
    }
    if (isPublished && !preview) {
      showPreview();
      return;
    }
    if (
      !(await actions.confirm({
        title: isPublished
          ? published(initial.isPublished)
            ? "Atualizar parceria publicada?"
            : "Publicar parceria?"
          : "Salvar rascunho?",
        message: isPublished
          ? `A prévia de “${draft.title.trim()}” ficará visível para todos os alunos. Destino: ${draft.destinationUrl.trim()}`
          : `“${draft.title.trim()}” será salva sem ficar visível aos alunos.`,
        label: isPublished ? "Confirmar publicação" : "Salvar rascunho",
      }))
    )
      return;
    const useStatus = unchanged && isPublished;
    const body = useStatus
      ? { id: draft.id, isPublished: true }
      : {
          id: draft.id,
          title: draft.title.trim(),
          description: draft.description.trim(),
          logo: draft.logo,
          banner: draft.banner,
          destinationUrl: draft.destinationUrl.trim(),
          type: draft.type,
          isPublished,
        };
    const ok = await actions.run(
      useStatus ? "/admin/partnerships/status" : "/admin/partnerships",
      { method: useStatus ? "PUT" : "POST", body },
      isPublished ? "Parceria publicada / atualizada." : "Rascunho salvo.",
      true,
      refresh,
    );
    if (ok) close();
    else
      setError(
        "Não foi possível salvar. Consulte a resposta do servidor no painel. O formulário foi preservado.",
      );
  };
  return (
    <EditorWindow
      title={preview ? "Revisão antes de publicar" : "Editar parceria"}
      busy={actions.busy}
      error={actions.error || error}
      onClose={close}
    >
      {preview ? (
        <>
          <Notice message="Confira o texto, as imagens e o destino. Esta prévia não publica nem abre o link." />
          <PartnershipCard item={draft} preview />
        </>
      ) : (
        <>
          <Input
            label="Título"
            value={draft.title}
            maxLength={120}
            onChangeText={(value) => change("title", value)}
            editable={!actions.busy}
          />
          <Input
            label="Descrição"
            value={draft.description}
            maxLength={2000}
            multiline
            style={s.multiline}
            onChangeText={(value) => change("description", value)}
            editable={!actions.busy}
          />
          <ImageField
            label="Logo"
            value={draft.logo}
            onChange={(value) => change("logo", value)}
            disabled={actions.busy}
          />
          <ImageField
            label="Banner"
            value={draft.banner}
            onChange={(value) => change("banner", value)}
            disabled={actions.busy}
          />
          <Input
            label="Link de destino"
            value={draft.destinationUrl}
            maxLength={2048}
            autoCapitalize="none"
            autoCorrect={false}
            keyboardType="url"
            placeholder="https://…"
            onChangeText={(value) => change("destinationUrl", value)}
            editable={!actions.busy}
          />
          <Choices
            label="Tipo"
            value={draft.type}
            options={["Discord", "WhatsApp", "Outro"].map((value) => ({
              value,
              label: value,
            }))}
            onChange={(value) => change("type", value)}
            disabled={actions.busy}
          />
        </>
      )}
      <View style={s.wrap}>
        <Button
          label={preview ? "Voltar à edição" : "Pré-visualizar"}
          variant="secondary"
          disabled={actions.busy}
          onPress={() => {
            if (preview) {
              setPreview(false);
              setError("");
            } else showPreview();
          }}
        />
        {!published(initial.isPublished) ? (
          <Button
            label="Salvar rascunho"
            variant="secondary"
            disabled={actions.busy}
            onPress={() => {
              void save(false);
            }}
          />
        ) : null}
        {preview ? (
          <Button
            label={
              published(initial.isPublished)
                ? "Salvar alterações"
                : "Publicar parceria"
            }
            loading={actions.busy}
            onPress={() => {
              void save(true);
            }}
          />
        ) : null}
      </View>
    </EditorWindow>
  );
}

function Help({ actions, sessionRa }: { actions: Actions; sessionRa: string }) {
  const query = useWorker<{ feedback: Ticket[] }>("/admin/feedback");
  const [selected, setSelected] = useState<Ticket | null>(null);
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const tickets = list(query.data?.feedback).filter(
    (item) =>
      (filter === "all" || item.status === filter) &&
      `${item.userName} ${item.userRa} ${item.content}`
        .toLowerCase()
        .includes(search.trim().toLowerCase()),
  );
  const remove = async (ticket: Ticket) => {
    if (
      await actions.confirm({
        title: "Excluir atendimento?",
        message: `Atendimento de ${ticket.userName || ticket.userRa}: todas as mensagens serão apagadas. Esta ação não pode ser desfeita.`,
        label: "Excluir atendimento",
        danger: true,
      })
    )
      await actions.run(
        `/admin/feedback?id=${encodeURIComponent(ticket.id)}`,
        { method: "DELETE" },
        "Atendimento excluído.",
        false,
        query.refresh,
      );
  };
  return (
    <>
      <Card title="Central de ajuda">
        <View style={s.stack}>
          <Body>
            Atendimentos enviados pelos alunos. As respostas são enviadas pelo
            servidor, sem conversas simuladas.
          </Body>
          <Input
            label="Buscar atendimento"
            value={search}
            onChangeText={setSearch}
          />
          <Choices
            label="Status"
            value={filter}
            options={[{ value: "all", label: "Todos" }, ...STATUS]}
            onChange={setFilter}
          />
          <Button
            label="Atualizar atendimentos"
            variant="secondary"
            disabled={actions.busy || query.loading}
            onPress={() => {
              void query.refresh();
            }}
          />
        </View>
      </Card>
      <LoadState
        loading={query.loading}
        error={query.error}
        refresh={query.refresh}
      />
      {!query.loading && !query.error && !tickets.length ? (
        <Empty title="Nenhum atendimento encontrado" />
      ) : null}
      {!query.error
        ? tickets.map((ticket) => (
            <Card
              key={ticket.id}
              title={ticket.userName || `RA ${ticket.userRa}`}
            >
              <View style={s.stack}>
                <Body>
                  RA {ticket.userRa} · {dateLabel(ticket.createdAt)}
                </Body>
                <View style={s.wrap}>
                  <Pill
                    label={
                      ticket.type === "bug" ? "Problema" : "Sugestão / dúvida"
                    }
                  />
                  <Pill
                    label={
                      STATUS.find((item) => item.value === ticket.status)
                        ?.label || ticket.status
                    }
                  />
                </View>
                <Body>{ticket.content}</Body>
                <RemoteImage uri={ticket.image} label="Anexo do atendimento" />
                {ticket.adminReply ? (
                  <Body>Resposta: {ticket.adminReply}</Body>
                ) : null}
                <View style={s.wrap}>
                  <Button
                    label="Abrir atendimento"
                    variant="secondary"
                    disabled={actions.busy}
                    onPress={() => setSelected(ticket)}
                  />
                  <Button
                    label="Excluir"
                    variant="danger"
                    disabled={actions.busy}
                    onPress={() => {
                      void remove(ticket);
                    }}
                  />
                </View>
              </View>
            </Card>
          ))
        : null}
      {selected ? (
        <TicketEditor
          key={selected.id}
          initial={selected}
          sessionRa={sessionRa}
          actions={actions}
          close={() => setSelected(null)}
          refreshList={query.refresh}
        />
      ) : null}
    </>
  );
}
function TicketEditor({
  initial,
  sessionRa,
  actions,
  close,
  refreshList,
}: {
  initial: Ticket;
  sessionRa: string;
  actions: Actions;
  close: () => void;
  refreshList: () => unknown;
}) {
  const [thread, setThread] = useState<{
    ticket: Ticket;
    messages: HelpMessage[];
    admin?: boolean;
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [status, setStatus] = useState(initial.status || "aberto");
  const [reply, setReply] = useState(initial.adminReply || "");
  const [content, setContent] = useState("");
  const [editing, setEditing] = useState<{
    id: string;
    content: string;
  } | null>(null);
  const request = useRef<AbortController | null>(null);
  // /feedback/* does not receive the parent's /admin/* header injection. This
  // non-secret identity header is required by the original support contract.
  const headers = { "X-Admin-User": sessionRa };
  const load = useCallback(async () => {
    request.current?.abort();
    const controller = new AbortController();
    request.current = controller;
    setLoading(true);
    setLoadError(null);
    try {
      const data = await worker<{
        ticket: Ticket;
        messages: HelpMessage[];
        admin?: boolean;
      }>(`/feedback/ticket?id=${encodeURIComponent(initial.id)}`, {
        headers: { "X-Admin-User": sessionRa },
        signal: controller.signal,
      });
      if (!data.ticket?.id)
        throw new Error("O servidor não retornou o atendimento solicitado.");
      if (!controller.signal.aborted) setThread(data);
    } catch (error) {
      if (!controller.signal.aborted) setLoadError(errorMessage(error));
    } finally {
      if (!controller.signal.aborted) setLoading(false);
    }
  }, [initial.id, sessionRa]);
  useEffect(() => {
    let active = true;
    // Initial loading is already true. Start I/O asynchronously and do not
    // start a queued request if the modal has been closed in the meantime.
    void Promise.resolve().then(() => {
      if (active) return load();
    });
    return () => {
      active = false;
      request.current?.abort();
    };
  }, [load]);
  const after = async () => {
    await load();
    await refreshList();
  };
  const send = async () => {
    if (!content.trim() || content.trim().length > 2000) {
      setError("Escreva uma mensagem de até 2.000 caracteres.");
      return;
    }
    if (
      !(await actions.confirm({
        title: "Enviar resposta?",
        message: "A mensagem será enviada ao aluno nesta conversa.",
        label: "Enviar resposta",
      }))
    )
      return;
    if (
      await actions.run(
        "/feedback/message",
        {
          method: "POST",
          headers,
          body: { ticketId: initial.id, content: content.trim() },
        },
        "Resposta enviada.",
        false,
        after,
      )
    ) {
      setContent("");
      setError("");
    } else
      setError(
        "A resposta não foi enviada. Consulte o erro do servidor no painel.",
      );
  };
  const saveStatus = async () => {
    if (
      !(await actions.confirm({
        title: "Salvar atendimento?",
        message:
          "O status e a resposta administrativa serão atualizados para o aluno.",
        label: "Salvar atendimento",
      }))
    )
      return;
    if (
      !(await actions.run(
        "/admin/feedback",
        {
          method: "PUT",
          body: { id: initial.id, status, adminReply: reply.trim() },
        },
        "Atendimento atualizado.",
        false,
        after,
      ))
    )
      setError(
        "Não foi possível atualizar. Consulte o erro do servidor no painel.",
      );
    else setError("");
  };
  const removeMessage = async (message: HelpMessage) => {
    if (
      await actions.confirm({
        title: "Excluir mensagem?",
        message:
          "A mensagem será removida desta conversa. Esta ação não pode ser desfeita.",
        label: "Excluir mensagem",
        danger: true,
      })
    ) {
      if (
        !(await actions.run(
          `/feedback/message?id=${encodeURIComponent(message.id)}`,
          { method: "DELETE", headers },
          "Mensagem excluída.",
          false,
          after,
        ))
      )
        setError(
          "Não foi possível excluir a mensagem. Consulte o erro do servidor.",
        );
    }
  };
  const saveMessage = async () => {
    if (!editing?.content.trim() || editing.content.trim().length > 2000) {
      setError("Mensagem obrigatória, até 2.000 caracteres.");
      return;
    }
    if (
      !(await actions.confirm({
        title: "Editar mensagem enviada?",
        message: "O conteúdo anterior será substituído na conversa do aluno.",
        label: "Salvar edição",
      }))
    )
      return;
    if (
      await actions.run(
        "/feedback/message",
        {
          method: "PUT",
          headers,
          body: { id: editing.id, content: editing.content.trim() },
        },
        "Mensagem editada.",
        false,
        after,
      )
    ) {
      setEditing(null);
      setError("");
    } else setError("A edição não foi salva. Consulte o erro do servidor.");
  };
  const ticket = thread?.ticket || initial;
  return (
    <EditorWindow
      title={`Atendimento #${initial.id.slice(-6)}`}
      busy={actions.busy}
      error={actions.error || error}
      onClose={close}
    >
      <Card title={ticket.userName || ticket.userRa}>
        <View style={s.stack}>
          <Body>RA {ticket.userRa}</Body>
          <Body>{ticket.content}</Body>
          <RemoteImage uri={ticket.image} label="Anexo original" />
        </View>
      </Card>
      <LoadState loading={loading} error={loadError} refresh={load} />
      {!loadError
        ? list(thread?.messages).map((message) => {
            const mine =
              message.mine === true ||
              (!!sessionRa && digits(message.authorRa) === sessionRa);
            const canDelete =
              mine ||
              (thread?.admin === true &&
                message.authorRole === "admin" &&
                message.authorRa === "assistente");
            return (
              <Card
                key={message.id}
                title={
                  message.authorRole === "admin"
                    ? "Equipe SEDX"
                    : message.authorName || "Aluno"
                }
              >
                <View style={s.stack}>
                  {editing?.id === message.id ? (
                    <>
                      <Input
                        label="Editar mensagem"
                        value={editing.content}
                        onChangeText={(value) =>
                          setEditing({ id: message.id, content: value })
                        }
                        multiline
                        style={s.multiline}
                        maxLength={2000}
                        editable={!actions.busy}
                      />
                      <View style={s.wrap}>
                        <Button
                          label="Cancelar edição"
                          variant="secondary"
                          disabled={actions.busy}
                          onPress={() => setEditing(null)}
                        />
                        <Button
                          label="Salvar edição"
                          loading={actions.busy}
                          onPress={() => {
                            void saveMessage();
                          }}
                        />
                      </View>
                    </>
                  ) : (
                    <>
                      <Text selectable style={s.content}>
                        {message.deleted
                          ? "Mensagem excluída"
                          : message.content}
                      </Text>
                      <Text style={s.muted}>
                        {dateLabel(message.createdAt)}
                        {message.editedAt ? " · editada" : ""}
                      </Text>
                      {!message.deleted ? (
                        <View style={s.wrap}>
                          {mine ? (
                            <Button
                              label="Editar"
                              variant="secondary"
                              disabled={actions.busy}
                              onPress={() =>
                                setEditing({
                                  id: message.id,
                                  content: message.content,
                                })
                              }
                            />
                          ) : null}
                          {canDelete ? (
                            <Button
                              label="Excluir mensagem"
                              variant="danger"
                              disabled={actions.busy}
                              onPress={() => {
                                void removeMessage(message);
                              }}
                            />
                          ) : null}
                        </View>
                      ) : null}
                    </>
                  )}
                </View>
              </Card>
            );
          })
        : null}
      {thread &&
      !loadError &&
      !list(thread.messages).length &&
      ticket.adminReply ? (
        <Card title="Resposta administrativa">
          <Body>{ticket.adminReply}</Body>
        </Card>
      ) : null}
      <Choices
        label="Status do atendimento"
        value={status}
        options={STATUS}
        onChange={setStatus}
        disabled={actions.busy}
      />
      <Input
        label="Resposta administrativa (até 1.000 caracteres)"
        value={reply}
        onChangeText={setReply}
        multiline
        style={s.multiline}
        maxLength={1000}
        editable={!actions.busy}
      />
      <Button
        label="Salvar status e resposta"
        loading={actions.busy}
        onPress={() => {
          void saveStatus();
        }}
      />
      <Input
        label="Nova mensagem na conversa"
        value={content}
        onChangeText={setContent}
        multiline
        style={s.multiline}
        maxLength={2000}
        editable={!actions.busy && !loading && !loadError}
      />
      <Button
        label="Enviar mensagem"
        disabled={!content.trim() || loading || !!loadError || !thread}
        loading={actions.busy}
        onPress={() => {
          void send();
        }}
      />
    </EditorWindow>
  );
}

function Moderation({ actions }: { actions: Actions }) {
  const query = useWorker<{ messages: ChatMessage[] }>(
    "/chat/messages?limit=100",
  );
  const [target, setTarget] = useState<{ ra: string; name: string } | null>(
    null,
  );
  const [duration, setDuration] = useState("60");
  const [reason, setReason] = useState("");
  const [error, setError] = useState("");
  const messages = list(query.data?.messages);
  const remove = async (message: ChatMessage) => {
    if (
      await actions.confirm({
        title: "Apagar mensagem da comunidade?",
        message: `Mensagem de ${message.author?.name || message.authorRa}: “${message.content.slice(0, 180)}”. A remoção será registrada em auditoria.`,
        danger: true,
        label: "Apagar mensagem",
      })
    )
      await actions.run(
        `/admin/chat/messages/${encodeURIComponent(message.id)}/delete`,
        { method: "POST", body: {} },
        "Mensagem removida da comunidade.",
        false,
        query.refresh,
      );
  };
  const moderate = async (ban: boolean) => {
    if (!target || !digits(target.ra)) return;
    const minutes = duration === "forever" ? null : Number(duration);
    if (
      !ban &&
      minutes !== null &&
      (!Number.isFinite(minutes) || minutes <= 0)
    ) {
      setError("Selecione uma duração válida.");
      return;
    }
    if (
      !(await actions.confirm({
        title: ban ? "Banir da comunidade?" : "Silenciar na comunidade?",
        message: `${target.name} · RA ${target.ra}. ${ban ? "O aluno será impedido de entrar no chat. Não há rota de desfazer banimento neste Worker." : `Silenciamento ${minutes === null ? "indefinido, sem rota de remoção no Worker ativo" : `por ${minutes} minutos`}.`}`,
        danger: true,
        label: ban ? "Confirmar banimento" : "Silenciar",
      }))
    )
      return;
    const ok = await actions.run(
      ban ? "/admin/chat/ban" : "/admin/chat/mute",
      {
        method: "POST",
        body: ban
          ? { userRa: digits(target.ra), reason: reason.trim() }
          : { userRa: digits(target.ra), durationMinutes: minutes },
      },
      ban ? "Aluno banido da comunidade." : "Aluno silenciado.",
      false,
      query.refresh,
    );
    if (ok) {
      setTarget(null);
      setError("");
    } else
      setError(
        "A ação não foi aplicada. Consulte o erro do servidor no painel.",
      );
  };
  return (
    <>
      <Card title="Moderação da comunidade">
        <View style={s.stack}>
          <Body>
            Revise as últimas 100 mensagens reais antes de selecionar um aluno.
            As ações afetam o chat e são auditadas.
          </Body>
          <Notice message="O Worker ativo oferece apagar mensagem, silenciar e banir. Não há listagem de punições nem rotas de desbanir ou remover silêncio." />
          <Button
            label="Atualizar mensagens"
            variant="secondary"
            disabled={actions.busy || query.loading}
            onPress={() => {
              void query.refresh();
            }}
          />
        </View>
      </Card>
      <LoadState
        loading={query.loading}
        error={query.error}
        refresh={query.refresh}
      />
      {!query.loading && !query.error && !messages.length ? (
        <Empty title="Nenhuma mensagem encontrada" />
      ) : null}
      {!query.error
        ? [...messages].reverse().map((message) => (
            <Card
              key={message.id}
              title={message.author?.name || `RA ${message.authorRa}`}
            >
              <View style={s.stack}>
                <Body>
                  RA {message.authorRa} · {dateLabel(message.createdAt)}
                </Body>
                <Text selectable style={s.content}>
                  {message.deleted
                    ? "Mensagem excluída"
                    : message.content || "Mensagem com anexo"}
                </Text>
                {message.attachmentName ? (
                  <Text style={s.muted}>Anexo: {message.attachmentName}</Text>
                ) : null}
                <View style={s.wrap}>
                  {!message.deleted ? (
                    <Button
                      label="Apagar mensagem"
                      variant="danger"
                      disabled={actions.busy}
                      onPress={() => {
                        void remove(message);
                      }}
                    />
                  ) : null}
                  <Button
                    label="Moderar aluno"
                    variant="secondary"
                    disabled={actions.busy || !digits(message.authorRa)}
                    onPress={() => {
                      setTarget({
                        ra: message.authorRa,
                        name: message.author?.name || "Aluno",
                      });
                      setDuration("60");
                      setReason("");
                      setError("");
                    }}
                  />
                </View>
              </View>
            </Card>
          ))
        : null}
      {target ? (
        <EditorWindow
          title="Moderar aluno"
          busy={actions.busy}
          error={actions.error || error}
          onClose={() => setTarget(null)}
        >
          <Body>
            {target.name} · RA {target.ra}
          </Body>
          <Choices
            label="Duração do silêncio"
            value={duration}
            options={[
              { value: "15", label: "15 minutos" },
              { value: "60", label: "1 hora" },
              { value: "1440", label: "24 horas" },
              { value: "forever", label: "Indefinido" },
            ]}
            onChange={setDuration}
            disabled={actions.busy}
          />
          <Button
            label="Silenciar aluno"
            variant="danger"
            disabled={actions.busy}
            onPress={() => {
              void moderate(false);
            }}
          />
          <Input
            label="Motivo do banimento (opcional)"
            value={reason}
            onChangeText={setReason}
            maxLength={500}
            multiline
            style={s.multiline}
            editable={!actions.busy}
          />
          <Button
            label="Banir aluno da comunidade"
            variant="danger"
            disabled={actions.busy}
            onPress={() => {
              void moderate(true);
            }}
          />
        </EditorWindow>
      ) : null}
    </>
  );
}

const s = StyleSheet.create({
  stack: { gap: 14 },
  flex: { flex: 1 },
  wrap: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
    alignItems: "center",
  },
  field: { gap: 9 },
  tabs: { gap: 8, paddingVertical: 6, paddingRight: 8 },
  tab: {
    paddingHorizontal: 16,
    paddingVertical: 13,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: C.border,
    backgroundColor: C.surface,
  },
  choice: {
    paddingHorizontal: 14,
    paddingVertical: 11,
    minHeight: 44,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: C.border,
    backgroundColor: C.raised,
  },
  choiceActive: { borderColor: C.accent, backgroundColor: C.raised },
  choiceText: { color: C.muted, fontSize: 14, fontWeight: "600" },
  choiceTextActive: { color: C.accent },
  disabled: { opacity: 0.5 },
  toggle: {
    flexDirection: "row",
    gap: 14,
    alignItems: "center",
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: C.border,
  },
  label: { color: C.text, fontSize: 15, fontWeight: "600" },
  muted: { color: C.muted, fontSize: 12, lineHeight: 19 },
  content: { color: C.text, fontSize: 15, lineHeight: 23 },
  loading: {
    flexDirection: "row",
    gap: 12,
    alignItems: "center",
    paddingVertical: 10,
  },
  metrics: { flexDirection: "row", flexWrap: "wrap", gap: 12 },
  metric: { flexGrow: 1, flexBasis: "45%", minWidth: 140 },
  metricValue: {
    color: C.text,
    fontSize: 32,
    fontWeight: "800",
    marginVertical: 8,
  },
  image: {
    width: "100%",
    height: 180,
    borderRadius: 14,
    backgroundColor: C.raised,
  },
  logo: { width: 76, height: 76, borderRadius: 18, backgroundColor: C.raised },
  banner: {
    height: 150,
    borderRadius: 14,
    backgroundColor: C.raised,
    borderWidth: 1,
    borderColor: C.border,
    alignItems: "center",
    justifyContent: "center",
  },
  bannerText: {
    color: C.muted,
    fontSize: 13,
    letterSpacing: 3,
    fontWeight: "700",
  },
  previewButton: {
    backgroundColor: C.raised,
    borderWidth: 1,
    borderColor: C.accent,
    borderRadius: 12,
    padding: 15,
    alignItems: "center",
  },
  multiline: { minHeight: 108, textAlignVertical: "top" },
  backdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.78)",
    justifyContent: "center",
    padding: 16,
  },
  modal: {
    maxHeight: "94%",
    width: "100%",
    maxWidth: 760,
    alignSelf: "center",
    backgroundColor: C.surface,
    borderRadius: 22,
    borderWidth: 1,
    borderColor: C.border,
    overflow: "hidden",
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    padding: 18,
    borderBottomWidth: 1,
    borderBottomColor: C.border,
  },
  modalContent: { padding: 18, paddingBottom: 28, gap: 16 },
  confirm: {
    width: "100%",
    maxWidth: 500,
    alignSelf: "center",
    backgroundColor: C.surface,
    borderRadius: 20,
    padding: 24,
    gap: 18,
    borderWidth: 1,
    borderColor: C.border,
  },
});
