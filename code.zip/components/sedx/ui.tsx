import React, { createContext, useContext, useState } from "react";
import { ActivityIndicator, Modal, Pressable, RefreshControl, ScrollView, StyleSheet, Text, TextInput, TextInputProps, View, ViewStyle, StyleProp, useWindowDimensions } from "react-native";
import { Image } from "expo-image";
import { Ionicons } from "@expo/vector-icons";
import { router, usePathname, Href } from "expo-router";
import { SafeAreaView, useSafeAreaInsets } from "react-native-safe-area-context";
import { useSedx } from "@/lib/sedx/session";

export const C = { bg: "#161616", surface: "#242424", raised: "#2a2a2a", border: "#404040", text: "#f7f7f7", muted: "#a4a4a4", accent: "#dadada", green: "#7bddab", red: "#ff8b8b", blue: "#8fc7ff" };
const ThemeAccent = createContext(C.accent);
const nav: { path: string; label: string; icon: React.ComponentProps<typeof Ionicons>["name"]; group: string }[] = [
  { path: "/", label: "Início", icon: "home-outline", group: "Seu SEDX" },
  { path: "/tarefas", label: "Atividades", icon: "checkbox-outline", group: "Seu SEDX" },
  { path: "/agenda", label: "Agenda", icon: "calendar-outline", group: "Vida escolar" },
  { path: "/presenca", label: "Presença", icon: "checkmark-circle-outline", group: "Vida escolar" },
  { path: "/boletim", label: "Boletim", icon: "bar-chart-outline", group: "Vida escolar" },
  { path: "/apostilas", label: "Apostilas", icon: "book-outline", group: "Estudo" },
  { path: "/ia", label: "Flash IA", icon: "sparkles-outline", group: "Estudo" },
  { path: "/comunidade", label: "Comunidade", icon: "chatbubbles-outline", group: "Conecte-se" },
  { path: "/avisos", label: "Anúncios", icon: "notifications-outline", group: "Conecte-se" },
  { path: "/voz", label: "Sala de voz", icon: "mic-outline", group: "Conecte-se" },
  { path: "/ferramentas", label: "Ferramentas", icon: "construct-outline", group: "Conecte-se" },
  { path: "/parcerias", label: "Parcerias", icon: "people-outline", group: "Conecte-se" },
  { path: "/ajuda", label: "Central de ajuda", icon: "help-circle-outline", group: "Sua conta" },
  { path: "/perfil", label: "Perfil", icon: "person-circle-outline", group: "Sua conta" },
  { path: "/sobre", label: "Sobre o SEDX", icon: "information-circle-outline", group: "Sua conta" },
];
const bottom = [nav[0], nav[7], nav[5], nav[10], nav[13]];
export function go(path: string) { router.push(path as Href); }
export function Icon({ name, size = 22, color = C.text }: { name: React.ComponentProps<typeof Ionicons>["name"]; size?: number; color?: string }) { return <Ionicons name={name} size={size} color={color} />; }
export function Page({ title, eyebrow, subtitle, children, onRefresh, scroll = true }: { title: string; eyebrow?: string; subtitle?: string; children: React.ReactNode; onRefresh?: () => Promise<void> | void; scroll?: boolean }) {
  const { width } = useWindowDimensions();
  const { session, siteState, isAdmin, signOut, profile } = useSedx();
  const insets = useSafeAreaInsets();
  const path = usePathname();
  const [drawer, setDrawer] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const wide = width >= 940;
  const seasonal: Record<string, string> = { halloween: "#fb923c", christmas: "#8ad8a1", kids: "#c5a0ff", default: C.accent };
  const accent = seasonal[siteState?.activeTheme] || C.accent;
  const navigate = (p: string) => { setDrawer(false); if (p === "/") router.replace("/" as Href); else go(p); };
  const menu = <View style={s.menu}>
    <Image source={require("@/assets/images/sedx-logo.png")} style={{ width: 148, height: 88 }} contentFit="contain" accessibilityLabel="SEDX" />
    <Text style={s.menuName}>{session?.nome || "Sua área do aluno"}</Text>
    <ScrollView showsVerticalScrollIndicator={false}>
      {nav.map((item, i) => <React.Fragment key={item.path}>
        {(i === 0 || nav[i - 1].group !== item.group) && <Text style={s.menuGroup}>{item.group}</Text>}
        <Pressable accessibilityRole="button" accessibilityLabel={item.label} onPress={() => navigate(item.path)} style={[s.menuItem, path === item.path && { backgroundColor: C.raised, borderColor: accent }]}>
          <Icon name={item.icon} color={path === item.path ? accent : C.muted} size={20} /><Text style={s.menuLabel}>{item.label}</Text>
        </Pressable>
      </React.Fragment>)}
      {isAdmin && <Pressable accessibilityRole="button" onPress={() => navigate("/admin")} style={s.menuItem}><Icon name="shield-checkmark-outline" /><Text style={s.menuLabel}>Administração</Text></Pressable>}
      <Pressable accessibilityRole="button" onPress={() => { setDrawer(false); void signOut(); }} style={[s.menuItem, { marginTop: 22 }]}><Icon name="log-out-outline" color={C.red} /><Text style={[s.menuLabel, { color: C.red }]}>Sair da conta</Text></Pressable>
    </ScrollView>
  </View>;
  const content = <View style={s.pageContent}>
    <View style={s.heading}>{eyebrow && <Text style={s.eyebrow}>{eyebrow}</Text>}<Text style={s.pageTitle}>{title}</Text>{subtitle && <Text style={s.subtitle}>{subtitle}</Text>}</View>
    {children}
    <View style={{ height: 20 }} />
  </View>;
  return <ThemeAccent.Provider value={accent}><SafeAreaView style={s.safe} edges={["top", "left", "right"]}>
    <View style={s.shell}>
      {wide && <View style={s.sidebar}>{menu}</View>}
      <View style={s.main}>
        <View style={s.header}>
          {!wide && <Pressable accessibilityRole="button" accessibilityLabel="Abrir menu de navegação" onPress={() => setDrawer(true)} style={s.iconButton}><Icon name="menu" size={26} /></Pressable>}
          <Image source={require("@/assets/images/sedx-logo.png")} style={{ width: 77, height: 44 }} contentFit="contain" />
          <View style={{ flex: 1 }} />
          <Pressable accessibilityRole="button" accessibilityLabel="Abrir anúncios" onPress={() => navigate("/avisos")} style={s.iconButton}><Icon name="notifications-outline" />{siteState?.notifications?.length > 0 && <View style={[s.dot, { backgroundColor: accent }]} />}</Pressable>
          <Pressable accessibilityRole="button" accessibilityLabel="Abrir perfil" onPress={() => navigate("/perfil")} style={s.avatar}>{profile?.photo ? <Image source={{ uri: profile.photo }} style={{ width: 36, height: 36, borderRadius: 18 }} /> : <Text style={s.initial}>{session?.nome?.slice(0, 1).toUpperCase() || "S"}</Text>}</Pressable>
        </View>
        {scroll ? <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} contentContainerStyle={{ flexGrow: 1 }} refreshControl={onRefresh ? <RefreshControl tintColor={accent} refreshing={refreshing} onRefresh={async () => { setRefreshing(true); try { await onRefresh(); } finally { setRefreshing(false); } }} /> : undefined}>{content}</ScrollView> : <View style={{ flex: 1 }}>{content}</View>}
        {!wide && <View style={[s.bottom, { paddingBottom: Math.max(insets.bottom, 10) }]}>{bottom.map(item => <Pressable key={item.path} accessibilityRole="button" accessibilityLabel={item.label} onPress={() => navigate(item.path)} style={s.bottomItem}><Icon name={item.icon} size={22} color={path === item.path ? accent : C.muted} /><Text style={[s.bottomLabel, path === item.path && { color: accent }]}>{item.label}</Text></Pressable>)}</View>}
      </View>
    </View>
    <Modal visible={drawer && !wide} animationType="slide" transparent onRequestClose={() => setDrawer(false)}><View style={s.modalBackdrop}><View style={[s.drawer, { paddingTop: Math.max(insets.top, 16), paddingBottom: insets.bottom }]}><Pressable onPress={() => setDrawer(false)} accessibilityLabel="Fechar menu" style={[s.iconButton, { alignSelf: "flex-end" }]}><Icon name="close" /></Pressable>{menu}</View><Pressable style={{ flex: 1 }} accessibilityLabel="Fechar menu" onPress={() => setDrawer(false)} /></View></Modal>
  </SafeAreaView></ThemeAccent.Provider>;
}
export function Card({ title, children, style }: { title?: string; children: React.ReactNode; style?: StyleProp<ViewStyle> }) { return <View style={[s.card, style]}>{title && <Text style={s.cardTitle}>{title}</Text>}{children}</View>; }
export function Title({ children }: { children: React.ReactNode }) { return <Text style={s.cardTitle}>{children}</Text>; }
export function Label({ children }: { children: React.ReactNode }) { return <Text style={s.label}>{children}</Text>; }
export function Body({ children }: { children: React.ReactNode }) { return <Text style={s.body}>{children}</Text>; }
export function Row({ children }: { children: React.ReactNode }) { return <View style={s.row}>{children}</View>; }
export function Button({ label, onPress, loading, disabled, variant = "primary", icon }: { label: string; onPress: () => unknown | Promise<unknown>; loading?: boolean; disabled?: boolean; variant?: "primary" | "secondary" | "danger"; icon?: string }) {
  const accent = useContext(ThemeAccent); const off = loading || disabled;
  const color = variant === "primary" ? C.bg : variant === "danger" ? C.red : C.text;
  return <Pressable accessibilityRole="button" accessibilityState={{ disabled: Boolean(off), busy: Boolean(loading) }} onPress={() => { void onPress(); }} disabled={off} style={({ pressed }) => [s.button, variant === "primary" ? { backgroundColor: accent, borderColor: accent } : variant === "danger" ? { borderColor: C.red + "55" } : { backgroundColor: C.raised }, { opacity: off ? 0.45 : pressed ? 0.78 : 1 }]}>{loading ? <ActivityIndicator color={color} /> : icon ? <Ionicons name={icon as any} size={18} color={color} /> : null}<Text style={[s.buttonLabel, { color }]}>{label}</Text></Pressable>;
}
export function Input({ label, style, ...props }: TextInputProps & { label?: string; ref?: React.Ref<TextInput> }) { return <View style={{ gap: 7, minWidth: 0 }}>{label && <Label>{label}</Label>}<TextInput placeholderTextColor="#8d8d8d" selectionColor={C.accent} style={[s.input, props.multiline && { minHeight: 96, textAlignVertical: "top" }, style]} {...props} /></View>; }
export function Notice({ message, kind = "info" }: { message: string; kind?: "error" | "info" | "success" }) { const color = kind === "error" ? C.red : kind === "success" ? C.green : C.blue; return <View accessibilityRole="alert" style={[s.notice, { borderColor: color + "44" }]}><Icon name={kind === "error" ? "alert-circle-outline" : "information-circle-outline"} color={color} size={19} /><Text style={[s.noticeText, { color }]}>{message}</Text></View>; }
export function Empty({ title, description }: { title: string; description?: string }) { return <View style={s.empty}><Icon name="albums-outline" color={C.muted} size={32} /><Text style={s.cardTitle}>{title}</Text>{description && <Text style={[s.body, { textAlign: "center" }]}>{description}</Text>}</View>; }
export function Pill({ label, color = C.muted }: { label: string; color?: string }) { return <View style={[s.pill, { borderColor: color + "55" }]}><Text style={{ color, fontSize: 11, fontWeight: "600" }}>{label}</Text></View>; }
export function Loading({ label = "Carregando..." }: { label?: string }) { return <View style={s.empty}><ActivityIndicator color={C.accent} /><Body>{label}</Body></View>; }
const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg }, shell: { flex: 1, flexDirection: "row" }, main: { flex: 1, minWidth: 0 }, sidebar: { width: 248, borderRightWidth: 1, borderRightColor: C.border },
  header: { height: 66, borderBottomWidth: 1, borderBottomColor: C.border, paddingHorizontal: 18, flexDirection: "row", alignItems: "center", gap: 12 },
  iconButton: { width: 44, height: 44, alignItems: "center", justifyContent: "center" }, avatar: { width: 36, height: 36, borderRadius: 18, backgroundColor: C.raised, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: C.border }, initial: { color: C.text, fontWeight: "700" }, dot: { width: 5, height: 5, borderRadius: 3, position: "absolute", right: 9, top: 9 },
  pageContent: { width: "100%", maxWidth: 1050, alignSelf: "center", padding: 20, gap: 16, flexGrow: 1 }, heading: { gap: 8, marginBottom: 7 }, eyebrow: { color: C.muted, fontSize: 10, fontWeight: "700", letterSpacing: 2, textTransform: "uppercase" }, pageTitle: { color: C.text, fontSize: 29, fontWeight: "800", letterSpacing: -0.9 }, subtitle: { color: C.muted, fontSize: 14, lineHeight: 21 },
  card: { backgroundColor: C.surface, borderWidth: 1, borderColor: C.border, borderRadius: 18, padding: 18, gap: 13 }, cardTitle: { color: C.text, fontSize: 17, fontWeight: "700" }, label: { color: C.muted, fontSize: 12, fontWeight: "600" }, body: { color: C.muted, fontSize: 14, lineHeight: 22 }, row: { flexDirection: "row", flexWrap: "wrap", gap: 10, alignItems: "center" },
  button: { minHeight: 46, borderRadius: 12, borderWidth: 1, borderColor: C.border, paddingVertical: 12, paddingHorizontal: 16, flexDirection: "row", gap: 8, alignItems: "center", justifyContent: "center" }, buttonLabel: { fontSize: 13, fontWeight: "700" }, input: { color: C.text, fontSize: 15, backgroundColor: C.bg, borderRadius: 12, borderColor: C.border, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 13, minHeight: 48 },
  notice: { flexDirection: "row", alignItems: "flex-start", gap: 10, borderWidth: 1, borderRadius: 12, backgroundColor: C.raised, padding: 13 }, noticeText: { flex: 1, fontSize: 13, lineHeight: 20 }, empty: { alignItems: "center", justifyContent: "center", padding: 28, gap: 13 }, pill: { borderRadius: 8, borderWidth: 1, paddingHorizontal: 8, paddingVertical: 5 },
  bottom: { flexDirection: "row", borderTopWidth: 1, borderTopColor: C.border, backgroundColor: C.bg, paddingTop: 11, paddingHorizontal: 5 }, bottomItem: { flex: 1, alignItems: "center", gap: 5, minHeight: 43 }, bottomLabel: { color: C.muted, fontSize: 9, fontWeight: "600" },
  menu: { flex: 1, paddingHorizontal: 16, paddingVertical: 15 }, menuName: { color: C.text, fontSize: 12, marginBottom: 14 }, menuGroup: { color: C.muted, fontSize: 9, textTransform: "uppercase", letterSpacing: 1.4, paddingVertical: 13 }, menuItem: { minHeight: 43, flexDirection: "row", alignItems: "center", gap: 12, borderRadius: 10, paddingHorizontal: 12, borderWidth: 1, borderColor: "transparent", marginBottom: 3 }, menuLabel: { color: C.text, fontSize: 13 }, modalBackdrop: { flex: 1, backgroundColor: "#00000099", flexDirection: "row" }, drawer: { width: "82%", maxWidth: 330, backgroundColor: C.bg },
});
