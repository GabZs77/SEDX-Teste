# SEDX Android — build e limites de integração

## Projeto e segurança

O aplicativo é Expo Router / React Native, sem WebView. Login, dashboard, vida escolar, suporte, perfil, ferramentas, chat e painel administrativo usam as APIs atuais do Worker `sdf`. O Android fala com o Worker diretamente; a rota Express `/api/sedx` existe exclusivamente como ponte CORS da prévia Web. Tokens de sessão ficam no SecureStore Android e senha não é gravada.

Com autorização do usuário, o Worker `sdf` foi atualizado sem substituir seus sete módulos, os valores de segredos, o binding D1 ou o Web Push. As rotas adicionadas são `DELETE /chat/messages/:id` (para a mensagem associada ao RA do cabeçalho de chat do contrato atual) e `POST /push/native/register`/`POST /push/native/unregister`. O registro guarda o ExpoPushToken no D1, compartilha o fluxo de notificações existente e continua usando as sessões cifradas já previstas para tarefas/aulas. A versão respondida pela Cloudflare API: `f3d59a1f5f3e419f9f3f3fa0e6f45a65`.

**Limite de autorização existente no Worker:** o contrato atual do chat considera autenticada uma solicitação que apresenta `X-Usuario` e `X-Token2`; o próprio Worker não valida criptograficamente que o JWT pertence ao RA nessa rota. A exclusão escopa o SQL ao RA declarado, mas não elimina essa limitação preexistente. Trate contas/canais do chat segundo os controles existentes e não interprete isso como uma nova prova de identidade.

## Gerar o APK pelo painel

1. Salve/checkpoint do código Expo na branch `main` gerenciada.
2. No Dashboard, use **Connect Expo**, autentique a conta Expo do usuário pelo formulário do próprio Dashboard e aguarde sincronização. Não cole token/senha em chat nem em código.
3. Confirme o projeto EAS e o UUID `extra.eas.projectId`; prepare credenciais FCM V1 para o package Android já preservado por este app. Isso é necessário para que o registro push retorne um token e o serviço de notificações entregue avisos.
4. No painel, inicie um build Android de **APK** e aguarde seu resultado. Use o artefato gerado para instalar em aparelho físico; uma prévia Web, Metro ou Expo Go não é APK de produção e não valida módulos nativos.
5. Baixe/entregue o APK apenas após a conclusão real do build. Não execute EAS/Gradle de release dentro do servidor Metro.

## Funcionalidades que dependem de confirmação no APK

- Sala de voz usa o Worker de sinalização `sedx-voice` e WebRTC P2P/STUN; o servidor não valida a identidade SED, não fornece TURN/SFU e a rede do usuário pode bloquear mídia. Voz não é conferida com uma conta real.
- Compartilhamento de tela exige permissão explícita Android MediaProjection e serviço foreground; o manifesto inclui as permissões Android 14, mas precisa ser conferido no APK resultante.
- Expo Push precisa de um projeto EAS/UUID configurado, permissão Android e credenciais FCM V1. Até isso estar ativo, a interface reporta os erros reais e não mostra o push como configurado.
- Os PDFs das apostilas no site usam URLs `raw.githubusercontent.com`. Como o repositório original é privado e não há catálogo autenticado de apostilas no Worker, abrir alguns materiais pode requerer distribuição pública/autorizada ou endpoint próprio; nenhum token GitHub é empacotado no app.
- Nenhuma tarefa acadêmica foi enviada nem operação administrativa com dados de produção foi testada durante a implementação.
