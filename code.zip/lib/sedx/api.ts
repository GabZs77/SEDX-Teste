import { useCallback, useEffect, useRef, useState } from "react";
import { AppState, Platform } from "react-native";
import Constants from "expo-constants";
import { WORKER_URL, SedxSession, errorMessage } from "./contracts";

let currentSession: SedxSession | null = null;
export function configureWorkerSession(session: SedxSession | null) { currentSession = session; }
export function getWorkerSession() { return currentSession; }
export class WorkerError extends Error {
  constructor(message: string, public status: number, public payload: any) { super(message); }
}
export interface WorkerOptions {
  method?: string;
  body?: any;
  headers?: Record<string, string>;
  signal?: AbortSignal;
  timeout?: number;
  anonymous?: boolean;
}
function messageFrom(data: any, status: number): string {
  for (const v of [data?.erro, data?.error, data?.message, data?.error?.message]) {
    if (typeof v === "string" && v.trim()) return v;
  }
  return `Não foi possível consultar os dados (HTTP ${status}).`;
}
export function sessionHeaders(s: SedxSession | null, admin = false): Record<string, string> {
  if (!s) return {};
  return {
    "X-Token": s.token, "X-Token2": s.token2, "X-Cd-Usuario": s.cdUsuarioCurto,
    "X-Task-User": s.apelido, "X-Usuario": s.usuario,
    ...(s.profileKey ? { "X-Profile-Key": s.profileKey } : {}),
    ...(admin ? { "X-Admin-User": s.usuario.replace(/\D/g, "") } : {}),
  };
}
export async function worker<T = any>(path: string, options: WorkerOptions = {}): Promise<T> {
  if (!path.startsWith("/") || path.startsWith("//") || /[\r\n]/.test(path)) {
    throw new Error("Endereço da API inválido.");
  }
  const headers: Record<string, string> = {
    Accept: "application/json",
    ...sessionHeaders(options.anonymous ? null : currentSession, path.startsWith("/admin/")),
    ...options.headers,
  };
  const multipart = typeof FormData !== "undefined" && options.body instanceof FormData;
  const body = options.body === undefined ? undefined : multipart || typeof options.body === "string"
    ? options.body : JSON.stringify(options.body);
  if (body && !multipart && !headers["Content-Type"]) headers["Content-Type"] = "application/json";
  // The Android app talks directly to the existing Worker. Only Expo Web Preview needs a CORS bridge.
  let url = WORKER_URL + path;
  let init: RequestInit = { method: options.method || "GET", headers, body };
  if (Platform.OS === "web") {
    const api = process.env.EXPO_PUBLIC_API_BASE_URL || Constants.expoConfig?.extra?.apiBaseUrl;
    if (!api) throw new Error("Prévia Web sem endereço da ponte de API. O aplicativo Android usa o Worker diretamente.");
    url = `${String(api).replace(/\/$/, "")}/api/sedx${path}`;
  } else {
    headers["User-Agent"] = "SEDXNative/1.0 (Android; Expo ReactNative)";
  }
  const abort = new AbortController();
  const cancel = () => abort.abort();
  if (options.signal?.aborted) abort.abort();
  else options.signal?.addEventListener("abort", cancel, { once: true });
  const timer = setTimeout(cancel, options.timeout || 120_000);
  init.signal = abort.signal;
  try {
    const response = await fetch(url, init);
    const text = await response.text();
    let data: any;
    try { data = text ? JSON.parse(text) : null; }
    catch { throw new WorkerError("O serviço retornou uma resposta inválida. Verifique sua conexão e tente novamente.", response.status, null); }
    if (!response.ok || data?.ok === false || data?.sessaoExpirada) {
      throw new WorkerError(messageFrom(data, response.status), response.status, data);
    }
    return data as T;
  } catch (error) {
    if (abort.signal.aborted) throw new Error(options.signal?.aborted ? "Consulta cancelada." : "A consulta demorou mais que o esperado. Tente novamente.");
    if (error instanceof WorkerError) throw error;
    if (error instanceof TypeError) throw new Error("Sem conexão com o SEDX. Verifique a internet e tente novamente.");
    throw error;
  } finally {
    clearTimeout(timer);
    options.signal?.removeEventListener("abort", cancel);
  }
}
export function useWorker<T = any>(path: string | null) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(Boolean(path));
  const request = useRef<AbortController | null>(null);
  const mounted = useRef(true);
  const refresh = useCallback(async () => {
    if (!path) { setLoading(false); return; }
    request.current?.abort();
    const controller = new AbortController(); request.current = controller;
    setLoading(true); setError(null);
    try {
      const result = await worker<T>(path, { signal: controller.signal });
      if (mounted.current && !controller.signal.aborted) setData(result);
    } catch (e) {
      if (mounted.current && !controller.signal.aborted) setError(errorMessage(e));
    } finally { if (mounted.current && !controller.signal.aborted) setLoading(false); }
  }, [path]);
  useEffect(() => {
    mounted.current = true; setData(null); void refresh();
    const sub = AppState.addEventListener("change", (state) => { if (state === "active") void refresh(); });
    return () => { mounted.current = false; request.current?.abort(); sub.remove(); };
  }, [refresh]);
  return { data, error, loading, refresh };
}
