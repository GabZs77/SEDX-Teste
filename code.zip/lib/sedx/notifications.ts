import { Platform } from "react-native";
import Constants from "expo-constants";
import * as Notifications from "expo-notifications";
import * as SecureStore from "expo-secure-store";
import { worker } from "./api";
const PUSH_KEY = "sedx_native_expo_push_token";
export function nativeNotificationsAvailable() {
  return Platform.OS !== "web" && Constants.executionEnvironment !== "storeClient";
}
export async function requestNativePermission() {
  if (!nativeNotificationsAvailable()) throw new Error("Notificações nativas precisam do APK ou de um build de desenvolvimento; não estão disponíveis nesta prévia Expo Go/Web.");
  if (Platform.OS === "android") await Notifications.setNotificationChannelAsync("sedx", { name: "SEDX — avisos e atividades", importance: Notifications.AndroidImportance.HIGH, sound: "default" });
  const current = await Notifications.getPermissionsAsync();
  const result = current.granted ? current : await Notifications.requestPermissionsAsync();
  if (!result.granted) throw new Error("As notificações não foram autorizadas. Você pode ativá-las nas configurações do aparelho.");
}
export async function scheduleTimerNotification(when: Date, title: string): Promise<string | null> {
  await requestNativePermission();
  if (!Number.isFinite(when.getTime()) || when.getTime() <= Date.now()) return null;
  return Notifications.scheduleNotificationAsync({
    content: { title: "Tempo de atividade concluído", body: `${title.slice(0, 180)}: você já pode conferir e enviar suas respostas.`, sound: "default", data: { route: "/tarefas", kind: "task-timer" } },
    trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: when, channelId: "sedx" },
  });
}
export async function cancelTimerNotification(id: string) { if (nativeNotificationsAvailable()) await Notifications.cancelScheduledNotificationAsync(id); }
export async function registerNativePush() {
  await requestNativePermission();
  const projectId = Constants.expoConfig?.extra?.eas?.projectId ?? Constants.easConfig?.projectId;
  if (!projectId) throw new Error("O build ainda não está vinculado a um projeto Expo/EAS. Conecte Expo e configure FCM antes de ativar o push Android.");
  const token = (await Notifications.getExpoPushTokenAsync({ projectId })).data;
  await worker("/push/native/register", { method: "POST", body: { expoPushToken: token, projectId } });
  await SecureStore.setItemAsync(PUSH_KEY, token);
}
export async function unregisterNativePush() {
  if (!nativeNotificationsAvailable()) return;
  const token = await SecureStore.getItemAsync(PUSH_KEY);
  if (!token) return;
  await worker("/push/native/unregister", { method: "POST", body: { expoPushToken: token } });
  await SecureStore.deleteItemAsync(PUSH_KEY);
}
export function configureNotificationPresentation() {
  if (!nativeNotificationsAvailable()) return;
  Notifications.setNotificationHandler({ handleNotification: async () => ({ shouldPlaySound: true, shouldSetBadge: false, shouldShowBanner: true, shouldShowList: true }) });
}
