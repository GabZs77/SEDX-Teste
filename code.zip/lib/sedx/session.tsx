import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from "react";
import { Platform, AppState } from "react-native";
import * as SecureStore from "expo-secure-store";
import { configureWorkerSession, worker, WorkerError } from "./api";
import { SedxSession, normalizeSession, errorMessage, dashboardNeedsSessionRefresh } from "./contracts";

const KEY = "sedx_native_session_v1";
const secureOptions = { keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY };
async function readStored(): Promise<SedxSession | null> {
  try {
    if (Platform.OS === "web") return null; // No tokens in localStorage; Web Preview is deliberately session-only.
    const index = await SecureStore.getItemAsync(KEY, secureOptions);
    if (!index) return null;
    const count = Number(index);
    if (!Number.isInteger(count) || count < 1 || count > 30) return null;
    let json = "";
    for (let i = 0; i < count; i++) json += (await SecureStore.getItemAsync(`${KEY}_${i}`, secureOptions)) || "";
    const data = JSON.parse(json);
    return normalizeSession(data, data.usuario);
  } catch { return null; }
}
async function clearStored() {
  if (Platform.OS === "web") return;
  const count = Math.min(30, Number(await SecureStore.getItemAsync(KEY, secureOptions)) || 0);
  await SecureStore.deleteItemAsync(KEY, secureOptions);
  await Promise.all(Array.from({ length: count }, (_, i) => SecureStore.deleteItemAsync(`${KEY}_${i}`, secureOptions)));
}
async function persist(session: SedxSession) {
  if (Platform.OS === "web") return;
  await clearStored();
  const json = JSON.stringify(session);
  const chunks = json.match(/.{1,900}/gs) || [];
  for (let i = 0; i < chunks.length; i++) await SecureStore.setItemAsync(`${KEY}_${i}`, chunks[i], secureOptions);
  await SecureStore.setItemAsync(KEY, String(chunks.length), secureOptions);
}
interface SedxContextValue {
  session: SedxSession | null; booting: boolean; authError: string | null;
  dashboard: any; dashboardLoading: boolean; dashboardError: string | null;
  profile: any; siteState: any; isAdmin: boolean;
  signIn: (usuario: string, senha: string, remember: boolean) => Promise<void>;
  signOut: () => Promise<void>;
  refreshDashboard: () => Promise<void>; refreshProfile: () => Promise<void>; refreshSiteState: () => Promise<void>;
}
const Context = createContext<SedxContextValue | null>(null);
export function SedxProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<SedxSession | null>(null);
  const sessionRef = useRef<SedxSession | null>(null);
  const rememberRef = useRef(false);
  const [booting, setBooting] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);
  const [dashboard, setDashboard] = useState<any>(null);
  const [dashboardLoading, setDashboardLoading] = useState(false);
  const [dashboardError, setDashboardError] = useState<string | null>(null);
  const [profile, setProfile] = useState<any>(null);
  const [siteState, setSiteState] = useState<any>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const apply = useCallback((s: SedxSession | null) => {
    sessionRef.current = s; configureWorkerSession(s); setSession(s);
  }, []);
  const signOut = useCallback(async () => {
    apply(null); setDashboard(null); setProfile(null); setIsAdmin(false); setAuthError(null);
    await clearStored();
  }, [apply]);
  const refreshProfile = useCallback(async () => {
    if (!sessionRef.current) return;
    const r = await worker("/profile"); setProfile(r?.profile || null);
  }, []);
  const refreshSiteState = useCallback(async () => {
    const r = await worker("/site-state", { anonymous: true }); setSiteState(r);
  }, []);
  const refreshDashboard = useCallback(async () => {
    const s = sessionRef.current; if (!s) return;
    setDashboardLoading(true); setDashboardError(null);
    try {
      const renew = async () => {
        const renewed = normalizeSession(await worker("/resume", { method: "POST", body: { token: s.token, usuario: s.usuario } }), s.usuario);
        if (sessionRef.current !== s) return false;
        apply(renewed);
        if (rememberRef.current) await persist(renewed);
        return true;
      };
      let r: any;
      let attemptedRenewal = false;
      try { r = await worker("/dashboard"); }
      catch (e) {
        if (!(e instanceof WorkerError) || ![401,403].includes(e.status)) throw e;
        attemptedRenewal = true;
        if (!(await renew())) return;
        r = await worker("/dashboard");
      }
      if (!attemptedRenewal && dashboardNeedsSessionRefresh(r)) {
        attemptedRenewal = true;
        try { if (await renew()) r = await worker("/dashboard"); }
        catch { /* Mantém a resposta inicial, como no fluxo web. */ }
      }
      if (r?.meta?.sessaoSedExpirada) throw new Error("Sua sessão da Secretaria expirou. Saia e entre novamente para atualizar os dados.");
      if (sessionRef.current?.usuario === s.usuario) setDashboard(r);
    } catch (e) { setDashboardError(errorMessage(e)); }
    finally { setDashboardLoading(false); }
  }, [apply]);
  useEffect(() => {
    let active = true;
    void (async () => {
      try {
        const saved = await readStored();
        if (saved) {
          const renewed = normalizeSession(await worker("/resume", { method: "POST", anonymous: true, body: { token: saved.token, usuario: saved.usuario } }), saved.usuario);
          if (active) { rememberRef.current = true; await persist(renewed); apply(renewed); }
        }
      } catch (e) { await clearStored(); if (active) setAuthError(errorMessage(e)); }
      finally { if (active) setBooting(false); }
    })();
    return () => { active = false; };
  }, [apply]);
  const signIn = useCallback(async (usuario: string, senha: string, remember: boolean) => {
    setAuthError(null);
    const result = await worker("/login", { method: "POST", anonymous: true, body: { usuario, senha } });
    const s = normalizeSession(result, usuario);
    rememberRef.current = remember;
    if (remember) await persist(s); else await clearStored();
    apply(s); setDashboard(null); setProfile(null);
  }, [apply]);
  useEffect(() => {
    if (!session) return;
    void refreshDashboard(); void refreshProfile().catch(() => {});
    // Server response, not the claimed RA, determines whether the administrative UI is available.
    let alive = true;
    void worker("/admin/data").then(() => { if (alive) setIsAdmin(true); }).catch(() => { if (alive) setIsAdmin(false); });
    return () => { alive = false; };
  }, [session?.usuario, refreshDashboard, refreshProfile]);
  useEffect(() => {
    void refreshSiteState().catch(() => {});
    const id = setInterval(() => { if (AppState.currentState === "active") void refreshSiteState().catch(() => {}); }, 60_000);
    return () => clearInterval(id);
  }, [refreshSiteState]);
  return <Context.Provider value={{ session, booting, authError, dashboard, dashboardLoading, dashboardError, profile, siteState, isAdmin, signIn, signOut, refreshDashboard, refreshProfile, refreshSiteState }}>{children}</Context.Provider>;
}
export function useSedx() {
  const context = useContext(Context);
  if (!context) throw new Error("Contexto SEDX indisponível.");
  return context;
}
