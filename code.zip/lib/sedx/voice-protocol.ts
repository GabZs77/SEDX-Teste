/** Wire format from reference/Sed/voice-room.js. This Worker is signaling only. */
export const VOICE_SOCKET_URL =
  "wss://sedx-voice.gabrielreplit56.workers.dev/room/sala-de-voz/ws";
export const VOICE_MAX_MEMBERS = 20;
export const VOICE_PING_INTERVAL_MS = 25_000;
export const VOICE_DISCLOSURE =
  "O Worker só faz sinalização: não transporta o áudio nem valida a identidade no servidor. Nome e avatar são informações declaradas pelo cliente, não autenticação por RA. O áudio e as telas usam P2P, sem TURN; a conexão pode falhar em redes restritas. Compartilhe a tela apenas com pessoas em quem confia.";

// Return fresh objects: react-native-webrtc mutates its RTCConfiguration.
export function voiceIceServers() {
  return [{ urls: ["stun:stun.l.google.com:19302", "stun:stun1.l.google.com:19302"] }];
}

export interface VoicePeerInfo {
  id: string;
  name?: string;
  avatar?: string;
  muted?: boolean;
  deaf?: boolean;
  sharing?: boolean;
  speaking?: boolean;
}
export type VoiceState = Partial<Pick<VoicePeerInfo, "muted" | "deaf" | "sharing" | "speaking">>;
export interface VoiceDescription { type: "offer" | "answer"; sdp: string }
export interface VoiceCandidate {
  candidate: string;
  sdpMid?: string | null;
  sdpMLineIndex?: number | null;
  usernameFragment?: string | null;
}
export type VoiceSignal = { description: VoiceDescription; candidate?: never }
  | { candidate: VoiceCandidate; description?: never };
export type VoiceClientMessage =
  | { type: "join"; name: string; avatar: string; muted: boolean }
  | ({ type: "state" } & VoiceState)
  | { type: "ping" }
  | { type: "signal"; to: string; data: VoiceSignal };
export type VoiceServerMessage =
  | { type: "welcome"; id: string; max: number; peers: VoicePeerInfo[] }
  | { type: "full"; max: number }
  | { type: "peer-joined" | "peer-state"; peer: VoicePeerInfo }
  | { type: "peer-left"; id: string }
  | { type: "signal"; from: string; data: VoiceSignal };

const stateKeys = ["muted", "deaf", "sharing", "speaking"] as const;
const isRecord = (v: unknown): v is Record<string, unknown> =>
  !!v && typeof v === "object" && !Array.isArray(v);
const validId = (v: unknown): v is string =>
  typeof v === "string" && v.length > 0 && v.length <= 200 && v.trim() === v;

export function cleanVoiceName(value: unknown): string {
  return (typeof value === "string" ? value : "Aluno")
    .trim().replace(/\s+/g, " ").slice(0, 40) || "Aluno";
}
export function safeVoiceAvatar(value: unknown): string {
  if (typeof value !== "string" || value.length > 2048) return "";
  try {
    const url = new URL(value);
    return ["https:", "http:"].includes(url.protocol) && !url.username && !url.password
      ? url.href : "";
  } catch { return ""; }
}
/** Only public display fields; never send session tokens, usuario/RA or admin claims. */
export function voiceIdentity(profile: any, session: any): { name: string; avatar: string } {
  return {
    name: cleanVoiceName(profile?.name || profile?.nome || profile?.apelido || session?.nome || session?.apelido),
    avatar: safeVoiceAvatar(profile?.avatar || profile?.avatarUrl || profile?.photoURL || profile?.foto),
  };
}
export function voiceMemberLimit(value: unknown): number {
  const number = typeof value === "number" || typeof value === "string" ? Number(value) : NaN;
  return Number.isFinite(number) && number > 0
    ? Math.max(1, Math.min(VOICE_MAX_MEMBERS, Math.floor(number))) : VOICE_MAX_MEMBERS;
}
function readState(value: Record<string, unknown>): VoiceState {
  const result: VoiceState = {};
  for (const key of stateKeys) if (typeof value[key] === "boolean") result[key] = value[key];
  return result;
}
function readPeer(value: unknown): VoicePeerInfo | null {
  if (!isRecord(value) || !validId(value.id)) return null;
  return {
    id: value.id,
    ...(typeof value.name === "string" ? { name: cleanVoiceName(value.name) } : {}),
    ...(typeof value.avatar === "string" ? { avatar: safeVoiceAvatar(value.avatar) } : {}),
    ...readState(value),
  };
}
function readSignal(value: unknown): VoiceSignal | null {
  if (!isRecord(value)) return null;
  if (isRecord(value.description)) {
    const description = value.description;
    if ((description.type !== "offer" && description.type !== "answer") ||
        typeof description.sdp !== "string" || !description.sdp || description.sdp.length > 256_000) return null;
    return { description: { type: description.type, sdp: description.sdp } };
  }
  if (!isRecord(value.candidate)) return null;
  const c = value.candidate;
  if (typeof c.candidate !== "string" || c.candidate.length > 8192) return null;
  if (c.sdpMid !== undefined && c.sdpMid !== null &&
      (typeof c.sdpMid !== "string" || c.sdpMid.length > 256)) return null;
  if (c.sdpMLineIndex !== undefined && c.sdpMLineIndex !== null &&
      (typeof c.sdpMLineIndex !== "number" || !Number.isInteger(c.sdpMLineIndex) ||
        c.sdpMLineIndex < 0 || c.sdpMLineIndex > 65535)) return null;
  if (c.usernameFragment !== undefined && c.usernameFragment !== null &&
      (typeof c.usernameFragment !== "string" || c.usernameFragment.length > 256)) return null;
  // Native RTCIceCandidate requires a media section, even for end-of-candidates.
  if (c.sdpMid == null && c.sdpMLineIndex == null) return null;
  return { candidate: {
    candidate: c.candidate,
    ...(c.sdpMid !== undefined ? { sdpMid: c.sdpMid as string | null } : {}),
    ...(c.sdpMLineIndex !== undefined ? { sdpMLineIndex: c.sdpMLineIndex as number | null } : {}),
    ...(c.usernameFragment !== undefined ? { usernameFragment: c.usernameFragment as string | null } : {}),
  } };
}

/** Ignore malformed/unknown frames (including pong); the reference has no pong handler. */
export function parseVoiceMessage(raw: unknown): VoiceServerMessage | null {
  if (typeof raw !== "string" || raw.length > 512_000) return null;
  let value: unknown;
  try { value = JSON.parse(raw); } catch { return null; }
  if (!isRecord(value)) return null;
  switch (value.type) {
    case "welcome": {
      if (!validId(value.id)) return null;
      const max = voiceMemberLimit(value.max);
      const peers: VoicePeerInfo[] = [];
      const seen = new Set([value.id]);
      if (Array.isArray(value.peers)) {
        for (const entry of value.peers) {
          if (peers.length >= max - 1) break;
          const peer = readPeer(entry);
          if (!peer || seen.has(peer.id)) continue;
          seen.add(peer.id); peers.push(peer);
        }
      }
      return { type: "welcome", id: value.id, max, peers };
    }
    case "full": return { type: "full", max: voiceMemberLimit(value.max) };
    case "peer-joined":
    case "peer-state": {
      const peer = readPeer(value.peer);
      return peer ? { type: value.type, peer } : null;
    }
    case "peer-left": return validId(value.id) ? { type: "peer-left", id: value.id } : null;
    case "signal": {
      const data = readSignal(value.data);
      return validId(value.from) && data ? { type: "signal", from: value.from, data } : null;
    }
    default: return null;
  }
}

export function voiceJoin(name: unknown, avatar: unknown, muted: boolean): VoiceClientMessage {
  return { type: "join", name: cleanVoiceName(name), avatar: safeVoiceAvatar(avatar), muted: !!muted };
}
export function voiceState(state: VoiceState): VoiceClientMessage {
  return { type: "state", ...readState(state as Record<string, unknown>) };
}
export function voicePing(): VoiceClientMessage { return { type: "ping" }; }
export function voiceSignal(to: string, data: unknown): VoiceClientMessage {
  const signal = readSignal(data);
  if (!validId(to) || !signal) throw new Error("Sinal WebRTC inválido.");
  return { type: "signal", to, data: signal };
}
export function serializeVoiceMessage(message: VoiceClientMessage): string {
  // Rebuild the envelope so runtime extras cannot leak session credentials.
  switch (message.type) {
    case "join": return JSON.stringify(voiceJoin(message.name, message.avatar, message.muted));
    case "state": return JSON.stringify(voiceState(message));
    case "ping": return JSON.stringify(voicePing());
    case "signal": return JSON.stringify(voiceSignal(message.to, message.data));
    default: throw new Error("Mensagem não suportada pelo protocolo de voz.");
  }
}
