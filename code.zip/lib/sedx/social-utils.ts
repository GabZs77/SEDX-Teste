/** Contratos do SEDX: utilitários sem I/O, DOM ou dependências nativas. */
export const CHAT_MAX_BYTES = 3 * 1024 * 1024;
export const IMAGE_MAX_BYTES = 250 * 1024;
// O cliente de referência limita foto/banner a 300.000 caracteres de data URI.
export const PROFILE_IMAGE_MAX_CHARS = 300_000;
export const PROFILE_IMAGE_MAX_BYTES = 210 * 1024;
export const CHAT_MAX_CHARS = 4000;
export const FEEDBACK_MAX_CHARS = 2000;

export type CommunityChannel =
  | "channels"
  | "general"
  | "announcements"
  | "drops"
  | "voice";
export type Attachment = {
  url: string;
  name: string;
  type: string;
  duration?: number;
};
export type ChatMessage = {
  id: string;
  authorRa: string;
  author: { name: string; avatarUrl: string };
  content: string;
  attachmentUrl: string;
  attachmentName: string;
  attachmentType: string;
  audioUrl: string;
  deleted: boolean;
  editedAt: string;
  createdAt: string;
  replyTo?: { id: string; name: string; content: string } | null;
};
export type ReplyTarget = { id?: string; name: string; excerpt: string };
export type FeedbackTicket = {
  id: string;
  userRa: string;
  userName: string;
  type: string;
  content: string;
  image: string;
  status: string;
  adminReply: string;
  createdAt: string;
};
export type FeedbackMessage = {
  id: string;
  authorRa: string;
  authorName: string;
  authorRole: string;
  content: string;
  deleted: boolean;
  mine: boolean;
  createdAt: string;
  editedAt: string;
};
export type ProfileFields = {
  photo: string;
  banner: string;
  description: string;
  theme: string;
  accent: string;
  secondary: string;
  bg: string;
  foreground: string;
};
export const PROFILE_PRESETS = [
  {
    id: "sedx",
    name: "SEDX",
    accent: "#ff9f3f",
    secondary: "#d44b2a",
    bg: "#120b08",
    foreground: "#f7f7f7",
  },
  {
    id: "ocean",
    name: "Oceano",
    accent: "#45b9ff",
    secondary: "#5d6bff",
    bg: "#07111c",
    foreground: "#f7f7f7",
  },
  {
    id: "violet",
    name: "Violeta",
    accent: "#c58cff",
    secondary: "#745cff",
    bg: "#10091c",
    foreground: "#f7f7f7",
  },
  {
    id: "forest",
    name: "Floresta",
    accent: "#64d39b",
    secondary: "#1e9c76",
    bg: "#07150f",
    foreground: "#f7f7f7",
  },
] as const;
export const text = (value: unknown): string =>
  typeof value === "string" || typeof value === "number" ? String(value) : "";
export const raDigits = (value: unknown): string =>
  text(value).replace(/\D/g, "");
export const sameRa = (left: unknown, right: unknown): boolean =>
  Boolean(raDigits(left)) && raDigits(left) === raDigits(right);
export const asList = <T = any>(value: unknown): T[] =>
  Array.isArray(value)
    ? value.filter((item) => item && typeof item === "object")
    : [];
export function accountName(session: any): string {
  return (
    [session?.nome, session?.nomeCompleto, session?.name, session?.apelido]
      .map(text)
      .map((value) => value.trim())
      .find((value) => value && !/^\d+\s*[a-z]{0,2}$/i.test(value)) || "Aluno"
  );
}
export function initials(value: unknown): string {
  return (
    text(value)
      .trim()
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .map((word) => word.charAt(0))
      .join("")
      .toUpperCase() || "AL"
  );
}
export function shortName(value: unknown): string {
  const parts = text(value).trim().split(/\s+/).filter(Boolean);
  if (!parts.length || /^\d+\s*[a-z]{0,2}$/i.test(parts.join(" ")))
    return "Aluno";
  return parts.length > 1 ? `${parts[0]} ${parts[1].charAt(0)}.` : parts[0];
}
export function safeHttpUrl(value: unknown): string {
  const source = text(value).trim();
  if (
    !source ||
    source.length > 2048 ||
    /[\s\\\u0000-\u001f\u007f<>"']/u.test(source) ||
    !/^https?:\/\//i.test(source)
  )
    return "";
  try {
    const url = new URL(source);
    return ["https:", "http:"].includes(url.protocol) &&
      !url.username &&
      !url.password &&
      Boolean(url.hostname)
      ? url.href
      : "";
  } catch {
    return "";
  }
}
export function base64Bytes(value: string): number {
  if (!value || value.length % 4 !== 0 || !/^[A-Za-z0-9+/]+={0,2}$/.test(value))
    return 0;
  return (
    (value.length * 3) / 4 -
    (value.endsWith("==") ? 2 : value.endsWith("=") ? 1 : 0)
  );
}
export function dataUriParts(
  value: unknown,
): { type: string; base64: string; bytes: number } | null {
  const source = text(value);
  if (source.length > 5_000_000) return null;
  const match = source.match(
    /^data:([a-z0-9.+-]+\/[a-z0-9.+-]+);base64,([A-Za-z0-9+/]*={0,2})$/i,
  );
  if (!match) return null;
  const bytes = base64Bytes(match[2]);
  return bytes > 0
    ? { type: match[1].toLowerCase(), base64: match[2], bytes }
    : null;
}
export function safeImageUri(value: unknown): string {
  const data = dataUriParts(value);
  if (data)
    return /^image\/(?:png|jpeg|jpg|webp|gif)$/i.test(data.type) &&
      data.bytes <= CHAT_MAX_BYTES
      ? text(value)
      : "";
  const url = safeHttpUrl(value);
  return url.startsWith("https://") ? url : "";
}
export function safeMediaUri(value: unknown, kind?: "audio" | "video"): string {
  const data = dataUriParts(value);
  if (data)
    return data.bytes <= CHAT_MAX_BYTES &&
      (kind
        ? data.type.startsWith(`${kind}/`)
        : allowedAttachmentType(data.type))
      ? text(value)
      : "";
  const url = safeHttpUrl(value);
  return url.startsWith("https://") ? url : "";
}
export const colorValid = (value: unknown): boolean =>
  /^#[0-9a-f]{6}$/i.test(text(value));
export function normalizeProfile(value: any): ProfileFields {
  const source = value?.profile || value || {};
  const preset =
    PROFILE_PRESETS.find((item) => item.id === source.theme) ||
    PROFILE_PRESETS[0];
  return {
    photo: safeImageUri(source.photo),
    banner: safeImageUri(source.banner),
    description: text(source.description).slice(0, 180),
    theme: text(source.theme) || preset.id,
    accent: colorValid(source.accent) ? source.accent : preset.accent,
    secondary: colorValid(source.secondary)
      ? source.secondary
      : preset.secondary,
    bg: colorValid(source.bg) ? source.bg : preset.bg,
    foreground: colorValid(source.foreground)
      ? source.foreground
      : preset.foreground,
  };
}
/** PUT /profile substitui os campos: nunca enviar apenas o campo editado. */
export function profilePayload(
  current: any,
  patch: Partial<ProfileFields> = {},
): ProfileFields {
  const merged = { ...normalizeProfile(current), ...patch };
  if (text(merged.description).trim().length > 180)
    throw new Error("A descrição deve ter até 180 caracteres.");
  for (const key of ["accent", "secondary", "bg", "foreground"] as const) {
    if (!colorValid(merged[key]))
      throw new Error("Use cores no formato #RRGGBB.");
  }
  for (const key of ["photo", "banner"] as const) {
    if (!merged[key]) continue;
    const data = dataUriParts(merged[key]);
    const unchanged = merged[key] === normalizeProfile(current)[key];
    if (
      (!data || !/^image\/(?:png|jpeg|webp|gif)$/.test(data.type)) &&
      !unchanged
    )
      throw new Error("Escolha uma imagem válida.");
    if (
      data &&
      (data.bytes > IMAGE_MAX_BYTES ||
        merged[key].length > PROFILE_IMAGE_MAX_CHARS)
    )
      throw new Error("A imagem de perfil excede o limite permitido.");
  }
  return {
    photo: merged.photo,
    banner: merged.banner,
    description: merged.description.trim(),
    theme: merged.theme,
    accent: merged.accent,
    secondary: merged.secondary,
    bg: merged.bg,
    foreground: merged.foreground,
  };
}
export function fitImage(
  width: number,
  height: number,
  maxSide: number,
): { width: number; height: number } {
  if (
    ![width, height, maxSide].every(
      (number) => Number.isFinite(number) && number > 0,
    )
  )
    throw new Error("Dimensões de imagem inválidas.");
  const scale = Math.min(1, maxSide / Math.max(width, height));
  return {
    width: Math.max(1, Math.round(width * scale)),
    height: Math.max(1, Math.round(height * scale)),
  };
}
export function allowedAttachmentType(value: unknown): boolean {
  const type = text(value).toLowerCase();
  return (
    /^(?:image|video|audio)\/[a-z0-9.+-]+$/.test(type) ||
    [
      "application/pdf",
      "text/plain",
      "application/zip",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ].includes(type)
  );
}
export function inferMime(name: string, declared?: string | null): string {
  if (declared && declared !== "application/octet-stream")
    return declared.toLowerCase();
  const extension = name.split(".").pop()?.toLowerCase() || "";
  const types: Record<string, string> = {
    jpg: "image/jpeg",
    jpeg: "image/jpeg",
    png: "image/png",
    webp: "image/webp",
    gif: "image/gif",
    mp4: "video/mp4",
    mov: "video/quicktime",
    webm: "video/webm",
    mp3: "audio/mpeg",
    m4a: "audio/mp4",
    aac: "audio/aac",
    wav: "audio/wav",
    ogg: "audio/ogg",
    pdf: "application/pdf",
    txt: "text/plain",
    zip: "application/zip",
    docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  };
  return types[extension] || "application/octet-stream";
}
export function validateUpload(size: number | undefined, type: string): void {
  if (!Number.isFinite(size) || Number(size) <= 0)
    throw new Error("Não foi possível verificar o tamanho do arquivo.");
  if (Number(size) > CHAT_MAX_BYTES)
    throw new Error("O arquivo deve ter no máximo 3 MB.");
  if (!allowedAttachmentType(type))
    throw new Error(
      "Tipo de arquivo não permitido. Use imagem, vídeo, áudio, PDF, TXT, ZIP, DOCX ou XLSX.",
    );
}
export function safeFilename(value: unknown, fallback = "anexo"): string {
  return (
    text(value)
      .replace(/[\\/\u0000-\u001f<>:"|?*]/g, "_")
      .replace(/^\.+/, "")
      .trim()
      .slice(0, 120) || fallback
  );
}
export function normalizeChatMessage(value: any): ChatMessage {
  return {
    id: text(value?.id),
    authorRa: text(value?.authorRa ?? value?.userRa ?? value?.ra),
    author: {
      name:
        text(value?.author?.name || value?.authorName || value?.user?.name) ||
        "Aluno",
      avatarUrl: safeImageUri(value?.author?.avatarUrl || value?.avatarUrl),
    },
    content: text(value?.content),
    attachmentUrl: safeMediaUri(value?.attachmentUrl),
    attachmentName: text(value?.attachmentName),
    attachmentType: text(value?.attachmentType),
    audioUrl: safeMediaUri(value?.audioUrl, "audio"),
    deleted: value?.deleted === true || value?.deleted === 1,
    editedAt: text(value?.editedAt),
    createdAt: text(value?.createdAt),
    replyTo: value?.replyTo?.id
      ? {
          id: text(value.replyTo.id),
          name: text(value.replyTo.name),
          content: text(value.replyTo.content),
        }
      : null,
  };
}
/** Formato persistido de resposta do frontend; sem HTML nem metadados proprietários. */
export function splitReply(value: unknown): {
  name: string;
  excerpt: string;
  content: string;
} {
  const source = text(value).replace(/\r\n?/g, "\n");
  const match = source.match(/^> ([^\n]+)\n> ([^\n]+)\n\n([\s\S]*)$/);
  return match
    ? { name: match[1], excerpt: match[2], content: match[3] }
    : { name: "", excerpt: "", content: source };
}
export function replyExcerpt(message: Partial<ChatMessage>): string {
  const content = splitReply(message.content)
    .content.replace(/\s+/g, " ")
    .trim();
  return (
    content ||
    (message.audioUrl
      ? "Áudio"
      : message.attachmentName ||
        (message.attachmentUrl ? "Mensagem com anexo" : "Mensagem"))
  ).slice(0, 220);
}
export function canReply(
  message: Partial<ChatMessage> | null,
  accountRa: unknown,
): boolean {
  return Boolean(
    message && !message.deleted && !sameRa(message.authorRa, accountRa),
  );
}
export function replyContent(
  content: string,
  target?: ReplyTarget | null,
): string {
  const body = content.trim();
  if (!target) return body;
  const name = target.name.replace(/\s+/g, " ").trim().slice(0, 120) || "Aluno";
  const excerpt =
    target.excerpt.replace(/\s+/g, " ").trim().slice(0, 220) || "Mensagem";
  return `> ${name}\n> ${excerpt}\n\n${body}`;
}
export function chatPayload(
  content: string,
  attachment?: Attachment | null,
  audio?: Attachment | null,
  target?: ReplyTarget | null,
) {
  if (!content.trim() && !attachment && !audio)
    throw new Error("Escreva uma mensagem ou anexe um arquivo.");
  const encoded = replyContent(content, target);
  if (encoded.length > CHAT_MAX_CHARS)
    throw new Error(
      "A mensagem, incluindo a citação, deve ter até 4.000 caracteres.",
    );
  for (const item of [attachment, audio]) {
    if (item && (!safeMediaUri(item.url) || !allowedAttachmentType(item.type)))
      throw new Error("Anexo inválido. Escolha o arquivo novamente.");
  }
  return {
    content: encoded,
    attachment: attachment || null,
    audio: audio || null,
  };
}
export function validateFeedbackContent(
  value: unknown,
  create = false,
): string {
  const content = text(value).trim();
  if (content.length < (create ? 10 : 1))
    throw new Error(
      create
        ? "Descreva o atendimento com pelo menos 10 caracteres."
        : "A mensagem não pode ficar vazia.",
    );
  if (content.length > FEEDBACK_MAX_CHARS)
    throw new Error("A mensagem deve ter até 2.000 caracteres.");
  return content;
}
export function feedbackCreatePayload(
  kind: "bug" | "suggestion",
  content: string,
  image = "",
) {
  if (!["bug", "suggestion"].includes(kind))
    throw new Error("Selecione o tipo de atendimento.");
  if (image) {
    const data = dataUriParts(image);
    if (
      !data ||
      !/^image\/(?:png|jpeg|webp|gif)$/.test(data.type) ||
      data.bytes > IMAGE_MAX_BYTES ||
      image.length > 350000
    )
      throw new Error("A imagem deve ter até 250 KB.");
  }
  return { type: kind, content: validateFeedbackContent(content, true), image };
}
export const feedbackTicketPath = (id: string) =>
  `/feedback/ticket?id=${encodeURIComponent(id)}`;
export const feedbackDeleteMessagePath = (id: string) =>
  `/feedback/message?id=${encodeURIComponent(id)}`;
export const feedbackDeleteTicketPath = (id: string) =>
  `/admin/feedback?id=${encodeURIComponent(id)}`;
export function normalizeTicket(value: any): FeedbackTicket {
  return {
    id: text(value?.id),
    userRa: text(value?.userRa ?? value?.userRA ?? value?.ra ?? value?.RA),
    userName: text(value?.userName || value?.nome || value?.name) || "Aluno",
    type: text(value?.type),
    content: text(value?.content),
    image: safeImageUri(value?.image),
    status: text(value?.status),
    adminReply: text(value?.adminReply),
    createdAt: text(value?.createdAt),
  };
}
export function normalizeFeedbackMessage(value: any): FeedbackMessage {
  return {
    id: text(value?.id),
    authorRa: text(value?.authorRa ?? value?.userRa ?? value?.ra),
    authorName:
      text(
        value?.authorName || value?.userName || value?.nome || value?.name,
      ) || "Aluno",
    authorRole: text(value?.authorRole),
    content: text(value?.content),
    deleted: value?.deleted === true || value?.deleted === 1,
    mine: value?.mine === true,
    createdAt: text(value?.createdAt),
    editedAt: text(value?.editedAt),
  };
}
export function feedbackStatus(value: unknown): string {
  const labels: Record<string, string> = {
    aberto: "Recebido",
    em_analise: "Em análise",
    resolvido: "Resolvido",
    arquivado: "Arquivado",
  };
  return labels[text(value)] || "Recebido";
}
export function formatDateTime(value: unknown): string {
  const source = text(value);
  if (!source) return "";
  const date = new Date(source);
  return Number.isNaN(date.getTime())
    ? ""
    : date.toLocaleString("pt-BR", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      });
}
export function formatDuration(seconds: number): string {
  const total = Number.isFinite(seconds) ? Math.max(0, Math.round(seconds)) : 0;
  return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, "0")}`;
}
export function noticeMarker(notice: any): string {
  return `${text(notice?.id)}:${text(notice?.updatedAt || notice?.publishedAt)}`;
}
export function readMarkerKey(account: unknown): string {
  return `sedx:announcements-read:v1:${raDigits(account) || "visitor"}`;
}
export function parseReadMarkers(value: string | null): string[] {
  try {
    const parsed = JSON.parse(value || "[]");
    return Array.isArray(parsed)
      ? [
          ...new Set(
            parsed.filter(
              (item) => typeof item === "string" && item.length <= 250,
            ),
          ),
        ].slice(-200)
      : [];
  } catch {
    return [];
  }
}
export function addReadMarkers(markers: string[], notices: any[]): string[] {
  return [
    ...new Set([
      ...markers,
      ...notices.filter((item) => text(item?.id)).map(noticeMarker),
    ]),
  ].slice(-200);
}
export function normalizePartnership(value: any) {
  return {
    id: text(value?.id),
    title: text(value?.title),
    description: text(value?.description),
    logo: safeImageUri(value?.logo),
    banner: safeImageUri(value?.banner),
    destinationUrl: safeHttpUrl(value?.destinationUrl),
    type: ["Discord", "WhatsApp"].includes(value?.type)
      ? (value.type as string)
      : "Outro",
    isPublished:
      value?.isPublished === true ||
      value?.isPublished === 1 ||
      value?.isPublished === "1",
  };
}
export function publishedAbout(
  value: any,
): { title: string; intro: string; sections: any[] } | null {
  if (
    value?.published !== true ||
    !value?.content ||
    typeof value.content !== "object"
  )
    return null;
  return {
    title: text(value.content.title) || "Sobre o SEDX",
    intro: text(value.content.intro),
    sections: asList(value.content.sections).slice(0, 30),
  };
}
