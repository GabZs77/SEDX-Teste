export const WORKER_URL = "https://sdf.gabrielreplit56.workers.dev";
export const SITE_URL = "https://sed-gg.vercel.app";

export interface SedxSession {
  token: string;
  token2: string;
  usuario: string;
  nome: string;
  apelido: string;
  escola?: string;
  cdUsuarioCurto: string;
  codigoAluno?: string;
  profileKey?: string;
  localAdmin?: boolean;
}

export function makeUsuario(ra: string, digit: string, uf: string): string {
  const clean = ra.replace(/\D/g, "");
  const dv = digit.trim().toUpperCase();
  const state = uf.trim().toUpperCase();
  if (!clean || clean.length > 20) throw new Error("Informe um RA válido.");
  if (!/^[0-9X]$/.test(dv)) throw new Error("Informe o dígito do RA (0–9 ou X).");
  if (!/^[A-Z]{2}$/.test(state)) throw new Error("Informe a UF com duas letras.");
  return `${clean}${dv}${state}`;
}

export function normalizeSession(value: any, usuario: string): SedxSession {
  if (!value || typeof value !== "object" || !value.token || !value.token2) {
    throw new Error("A autenticação não retornou uma sessão completa. Tente entrar novamente.");
  }
  const cd = String(value.cdUsuarioCurto || value.codigoAluno || "");
  if (!cd) throw new Error("A sessão não informou o código do aluno.");
  return {
    token: String(value.token), token2: String(value.token2),
    usuario: String(value.usuario || usuario),
    nome: String(value.nome || "Aluno"), apelido: String(value.apelido || value.nome || usuario),
    escola: String(value.escola || ""), cdUsuarioCurto: cd, codigoAluno: cd,
    profileKey: String(value.profileKey || ""), localAdmin: value.localAdmin === true,
  };
}

export function dashboardNeedsSessionRefresh(value: any): boolean {
  const meta = value?.meta;
  return Boolean(meta && (
    meta.sessaoSedExpirada === true ||
    [meta.alunoApiOk, meta.faltasApiOk, meta.agendaApiOk].some((ok) => ok === false)
  ));
}

export function safeUrl(value: unknown): string | null {
  try {
    const u = new URL(String(value || ""));
    return ["https:", "http:"].includes(u.protocol) && !u.username && !u.password ? u.toString() : null;
  } catch { return null; }
}
export function errorMessage(value: unknown): string {
  return value instanceof Error ? value.message : "Não foi possível concluir. Tente novamente.";
}
export function raIdentity(value: string): string { return value.replace(/\D/g, "").replace(/^0+/, ""); }
export function firstName(value: string): string { return value.trim().split(/\s+/)[0] || "Aluno"; }
