# SEDX — aplicativo Android nativo com Expo

## Objetivo e referência
Recriar o site do repositório privado `GabZs77/Sed` (referência inicial: `bab3925`) usando Expo Router, React Native e TypeScript. Não utilizar WebView, Capacitor, iframe ou HTML como interface do aplicativo. Preservar a identidade visual, os recursos e os contratos dos Cloudflare Workers já empregados pelo site, com layout adaptado a telefones e tablets.

## Implementação
A interface será construída com componentes nativos, navegação e formulários acessíveis. Login oficial SED por RA, dígito, UF e senha através do Worker `sdf.gabrielreplit56.workers.dev`; sessão no SecureStore nativo, sem persistência de senha. Informações acadêmicas, comunidade, suporte, perfil, IA, estado global, ferramentas, parcerias e administração serão conectadas aos endpoints reais identificados no código. Não haverá usuário fictício ou dados simulados substituindo o backend.

Migrar os recursos observados no site: início, agenda, presença, boletim, tarefas e respostas com CAPTCHA, apostilas, assistente de IA, comunidade e anúncios, central de ajuda, perfil, ferramentas, parcerias, sobre e painel administrativo com autorização aplicada pelo Worker. Recursos que usam APIs exclusivas de navegador (sala WebRTC, captura de tela, Web Push e PDFs) terão equivalentes nativos compatíveis com Expo. Por autorização expressa, o Worker `sdf` recebeu as rotas para Expo Push nativo e exclusão própria de mensagens; o Web Push do site e os bindings existentes foram preservados. Não trocar o backend do site nem expor secrets Cloudflare ou de upstream no APK. Não realizar submissões acadêmicas ou alterações administrativas em produção durante a verificação.

## Estrutura
- `app/`: rotas Expo, login e áreas do aluno.
- `components/sedx/`: componentes nativos, shell, formulários, cartões e renderização de conteúdo.
- `lib/sedx/`: contratos tipados, cliente HTTP dos Workers, sessão, normalização e utilitários.
- `hooks/`: estado e consultas reativas.
- `assets/images/`: logo e ícones SEDX já existentes no repositório, adaptados sem mudar a marca.
- `server/` e `drizzle/`: infraestrutura preservada do starter; dados do aluno permanecem nos Workers existentes, não numa base nova.
- `tests/`: verificações determinísticas com respostas artificiais apenas nos testes, nunca na interface de produção.
- `docs/`: matriz de recursos e instruções de instalação/compilação.

## Design
Reutilizar a marca SEDX do site: logo branco/cinza sobre preto, fundo `#161616`, superfícies escuras, contornos discretos `#404040` e destaque cinza-claro `#dadada`, conforme o CSS atual. Hierarquia tipográfica forte, informações agrupadas em cartões e menu adaptado para uso com uma mão. Respeitar áreas seguras e teclado. Temas sazonais devem seguir o estado publicado pelo Worker, não uma configuração independente.

## APK e entrega
Salvar uma versão aceita do projeto Expo no ambiente gerenciado. O APK Android de instalação deve ser compilado pelo painel de build do projeto, após conexão da conta Expo pelo usuário no painel; não solicitar token Expo ou senha em chat. Entregar o APK somente após resultado efetivo da compilação. Prévia Web e Expo Go não equivalem a um APK nem comprovam funcionamento em aparelho. Se a compilação depender de ação do usuário ou existir incompatibilidade de API nativa, informar claramente e manter a pendência explícita, sem declarar o aplicativo finalizado.
