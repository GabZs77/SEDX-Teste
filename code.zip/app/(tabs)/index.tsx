export { HomeScreen as default } from "@/components/sedx/home";
