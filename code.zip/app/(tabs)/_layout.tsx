import React, { useEffect } from "react";
import { Stack, useRouter, type Href } from "expo-router";
import * as Notifications from "expo-notifications";
import { useSedx } from "@/lib/sedx/session";
import { configureNotificationPresentation, nativeNotificationsAvailable } from "@/lib/sedx/notifications";
import { LoginScreen } from "@/components/sedx/login";
import { Body, Button, Card, C, Page, Notice } from "@/components/sedx/ui";
export default function AppLayout() {
  const { session, booting, siteState, isAdmin, signOut, refreshSiteState } = useSedx();
  const router = useRouter();
  useEffect(() => {
    configureNotificationPresentation();
    if (!session || !nativeNotificationsAvailable()) return;
    const subscription = Notifications.addNotificationResponseReceivedListener((response) => {
      const route = response.notification.request.content.data?.route;
      const allowed = ["/", "/tarefas", "/agenda", "/boletim", "/presenca", "/avisos"];
      if (typeof route === "string" && allowed.includes(route)) router.push(route as Href);
    });
    return () => subscription.remove();
  }, [session, router]);
  if (booting || !session) return <LoginScreen />;
  if (siteState?.maintenance && !isAdmin) return <Page title="O SedX está em manutenção" eyebrow="VOLTAMOS EM BREVE"><Card><Notice message={siteState.maintenanceMessage || "Estamos melhorando o SEDX. Tente novamente em instantes."} /><Body>Seu acesso será restabelecido assim que a manutenção terminar.</Body><Button label="Verificar novamente" onPress={refreshSiteState} /><Button label="Sair da conta" onPress={signOut} variant="secondary" /></Card></Page>;
  return <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: C.bg }, animation: "fade" }}><Stack.Screen name="index" /><Stack.Screen name="[screen]" /></Stack>;
}
