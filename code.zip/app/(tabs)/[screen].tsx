import React from "react";
import { useLocalSearchParams } from "expo-router";
import { AgendaScreen, AttendanceScreen, GradesScreen, TasksScreen, TaskDetailScreen, BooksScreen, AIScreen } from "@/components/sedx/academic";
import { CommunityScreen, HelpScreen, ProfileScreen, ToolsScreen, PartnershipsScreen, AboutScreen, NotificationsScreen } from "@/components/sedx/social";
import { AdminScreen } from "@/components/sedx/admin";
import { VoiceScreen } from "@/components/sedx/voice";
import { Page, Empty, Button, go } from "@/components/sedx/ui";
const screens: Record<string, React.ComponentType> = {
  agenda: AgendaScreen, presenca: AttendanceScreen, boletim: GradesScreen,
  tarefas: TasksScreen, atividade: TaskDetailScreen, apostilas: BooksScreen, ia: AIScreen,
  comunidade: CommunityScreen, ajuda: HelpScreen, perfil: ProfileScreen,
  ferramentas: ToolsScreen, parcerias: PartnershipsScreen, sobre: AboutScreen,
  avisos: NotificationsScreen, admin: AdminScreen, voz: VoiceScreen,
};
export default function FeatureRoute() {
  const { screen } = useLocalSearchParams<{ screen: string }>();
  const name = Array.isArray(screen) ? screen[0] : screen;
  const Screen = screens[name];
  if (!Screen) return <Page title="Página não encontrada"><Empty title="Este caminho não existe no SEDX." /><Button label="Voltar ao início" onPress={() => go("/")} /></Page>;
  return <Screen />;
}
