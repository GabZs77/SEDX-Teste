import express, { type Express } from "express";
const ORIGIN = "https://sdf.gabrielreplit56.workers.dev";
const prefix = /^\/(login|resume|dashboard|agenda|boletim|presenca|frequencia|tarefas|student-rooms|captcha|task-details|answer-task|profile|feedback|admin|chat|groq-chat|groq-help|groq-research|site-state|partnerships|about|notifications|health|pdf-proxy)(\/|\?|$)/;
const forwarded = ["accept", "content-type", "x-token", "x-token2", "x-cd-usuario", "x-task-user", "x-usuario", "x-profile-key", "x-admin-user", "x-captcha-token", "x-captcha-session", "x-captcha-cookie"];
export function registerSedxPreview(app: Express) {
  // This stateless bridge exists only for Expo Web Preview's browser CORS restrictions.
  // Native Android does not use this service; credentials are never persisted or logged here.
  app.use("/api/sedx", express.raw({ type: () => true, limit: "25mb" }), async (req, res) => {
    if (!prefix.test(req.url) || /\\|\.{2}|%2f|%5c/i.test(req.path)) { res.status(400).json({ erro: "Rota inválida." }); return; }
    if (!["GET", "POST", "PUT", "PATCH", "DELETE"].includes(req.method)) { res.sendStatus(405); return; }
    const headers: Record<string, string> = { Origin: "https://sed-gg.vercel.app", "User-Agent": "Mozilla/5.0 SEDXNativePreview/1.0" };
    for (const name of forwarded) { const value = req.get(name); if (value) headers[name] = value; }
    try {
      const response = await fetch(ORIGIN + req.url, { method: req.method, headers,
        body: ["GET", "HEAD"].includes(req.method) || !req.body?.length ? undefined : req.body,
        signal: AbortSignal.timeout(120_000), redirect: "error" });
      res.status(response.status); res.setHeader("Cache-Control", "no-store");
      res.setHeader("Content-Type", response.headers.get("content-type") || "application/json");
      res.send(Buffer.from(await response.arrayBuffer()));
    } catch { res.status(502).json({ erro: "Não foi possível conectar ao Worker SEDX. Tente novamente." }); }
  });
}
