import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { readFileSync } from "node:fs";
import * as ts from "typescript";
import * as protocol from "../lib/sedx/voice-protocol";

const frame = (value: unknown) => JSON.stringify(value);
const description = { type: "offer", sdp: "v=0\r\nm=audio 9 UDP/TLS/RTP/SAVPF 111\r\n" };
const candidate = { candidate: "candidate:1 1 udp 2122260223 192.0.2.1 5000 typ host", sdpMid: "0", sdpMLineIndex: 0 };

describe("voice wire protocol (reference/Sed/voice-room.js)", () => {
  it("uses only the existing Worker, fixed room, STUN and 25s ping", () => {
    expect(protocol.VOICE_SOCKET_URL).toBe("wss://sedx-voice.gabrielreplit56.workers.dev/room/sala-de-voz/ws");
    expect(protocol.VOICE_MAX_MEMBERS).toBe(20);
    expect(protocol.VOICE_PING_INTERVAL_MS).toBe(25_000);
    expect(protocol.voiceIceServers()).toEqual([{ urls: ["stun:stun.l.google.com:19302", "stun:stun1.l.google.com:19302"] }]);
    const ice = protocol.voiceIceServers(); ice[0].urls.pop();
    expect(protocol.voiceIceServers()[0].urls).toHaveLength(2);
  });
  it("serializes exactly join, state, ping, description and candidate envelopes", () => {
    expect(JSON.parse(protocol.serializeVoiceMessage(protocol.voiceJoin(" Ana  Silva ", "", false))))
      .toEqual({ type: "join", name: "Ana Silva", avatar: "", muted: false });
    expect(JSON.parse(protocol.serializeVoiceMessage(protocol.voiceState({ muted: true, deaf: false, sharing: true, speaking: false }))))
      .toEqual({ type: "state", muted: true, deaf: false, sharing: true, speaking: false });
    expect(protocol.serializeVoiceMessage(protocol.voicePing())).toBe('{"type":"ping"}');
    expect(JSON.parse(protocol.serializeVoiceMessage(protocol.voiceSignal("peer", { description }))))
      .toEqual({ type: "signal", to: "peer", data: { description } });
    expect(JSON.parse(protocol.serializeVoiceMessage(protocol.voiceSignal("peer", { candidate }))))
      .toEqual({ type: "signal", to: "peer", data: { candidate } });
  });
  it("rejects invented message types and strips runtime credentials/admin fields", () => {
    expect(() => protocol.serializeVoiceMessage({ type: "leave" } as any)).toThrow();
    const join = protocol.voiceJoin("Aluno", "", true);
    expect(JSON.parse(protocol.serializeVoiceMessage({ ...join, token: "secret", ra: "123", admin: true } as any)))
      .toEqual({ type: "join", name: "Aluno", avatar: "", muted: true });
    expect(JSON.parse(protocol.serializeVoiceMessage({ type: "state", muted: true, token: "secret", id: "fake" } as any)))
      .toEqual({ type: "state", muted: true });
  });
  it("accepts all six server messages handled by the reference", () => {
    expect(protocol.parseVoiceMessage(frame({ type: "welcome", id: "self", max: 20, peers: [{ id: "p", name: "Pedro", muted: false }] })))
      .toEqual({ type: "welcome", id: "self", max: 20, peers: [{ id: "p", name: "Pedro", muted: false }] });
    expect(protocol.parseVoiceMessage(frame({ type: "full", max: 20 }))).toEqual({ type: "full", max: 20 });
    for (const type of ["peer-joined", "peer-state"]) {
      expect(protocol.parseVoiceMessage(frame({ type, peer: { id: "p", name: "Pedro", sharing: true } })))
        .toEqual({ type, peer: { id: "p", name: "Pedro", sharing: true } });
    }
    expect(protocol.parseVoiceMessage(frame({ type: "peer-left", id: "p" }))).toEqual({ type: "peer-left", id: "p" });
    expect(protocol.parseVoiceMessage(frame({ type: "signal", from: "p", data: { description } })))
      .toEqual({ type: "signal", from: "p", data: { description } });
  });
  it("keeps peer-state partial rather than inventing/resetting display fields", () => {
    expect(protocol.parseVoiceMessage(frame({ type: "peer-state", peer: { id: "p", muted: true } })))
      .toEqual({ type: "peer-state", peer: { id: "p", muted: true } });
    expect(protocol.parseVoiceMessage(frame({ type: "peer-state", peer: { id: "p", muted: "false", admin: true } })))
      .toEqual({ type: "peer-state", peer: { id: "p" } });
  });
  it("counts self within the 20 member limit and deduplicates peers", () => {
    const message = protocol.parseVoiceMessage(frame({ type: "welcome", id: "self", max: 999,
      peers: [{ id: "self" }, { id: "p0" }, { id: "p0" }, ...Array.from({ length: 40 }, (_, i) => ({ id: `p${i}` }))],
    }));
    expect(message?.type).toBe("welcome");
    if (message?.type !== "welcome") throw new Error("missing welcome");
    expect(message.max).toBe(20); expect(message.peers).toHaveLength(19);
    expect(new Set(message.peers.map(p => p.id)).size).toBe(19);
    expect(message.peers.some(p => p.id === "self")).toBe(false);
  });
  it.each([["8", 8], [3.9, 3], [0, 20], [-1, 20], [Infinity, 20], ["n/a", 20], [null, 20], [0.1, 1]])
    ("normalizes limit %s -> %s", (input, expected) => expect(protocol.voiceMemberLimit(input)).toBe(expected));
  it("sanitizes identity fields but never derives identity from RA", () => {
    expect(protocol.voiceIdentity({ nome: "  Ana   Souza ", avatar: "javascript:alert(1)" }, { usuario: "123SP", token: "secret" }))
      .toEqual({ name: "Ana Souza", avatar: "" });
    expect(protocol.voiceIdentity({}, { usuario: "123SP", token: "secret", localAdmin: true }))
      .toEqual({ name: "Aluno", avatar: "" });
    expect(protocol.cleanVoiceName("a".repeat(80))).toHaveLength(40);
    expect(protocol.safeVoiceAvatar("https://user:pass@example.com/a.png")).toBe("");
    expect(protocol.safeVoiceAvatar("https://example.com/a.png")).toBe("https://example.com/a.png");
  });
  it.each([null, {}, "{", "null", "[]", '{"type":"pong"}', '{"type":"welcome"}',
    '{"type":"peer-left","id":3}', '{"type":"peer-state","peer":[]}', "x".repeat(512_001)])
    ("ignores malformed/unknown frame %#", raw => expect(protocol.parseVoiceMessage(raw)).toBeNull());
  it("rejects oversized/invalid SDP and ICE while accepting empty ICE with a media section", () => {
    expect(protocol.parseVoiceMessage(frame({ type: "signal", from: "p", data: { description: { type: "rollback", sdp: "v=0" } } }))).toBeNull();
    expect(protocol.parseVoiceMessage(frame({ type: "signal", from: "p", data: { description: { type: "offer", sdp: "x".repeat(256_001) } } }))).toBeNull();
    expect(() => protocol.voiceSignal("p", { candidate: { candidate: "x" } })).toThrow();
    expect(() => protocol.voiceSignal("p", { candidate: { ...candidate, sdpMLineIndex: -1 } })).toThrow();
    expect(() => protocol.voiceSignal("", { candidate })).toThrow();
    expect(protocol.voiceSignal("p", { candidate: { candidate: "", sdpMid: "0", sdpMLineIndex: null } }))
      .toEqual({ type: "signal", to: "p", data: { candidate: { candidate: "", sdpMid: "0", sdpMLineIndex: null } } });
  });
  it("states signaling, unvalidated identity, P2P and lack of TURN honestly", () => {
    expect(protocol.VOICE_DISCLOSURE).toContain("nem valida a identidade");
    expect(protocol.VOICE_DISCLOSURE).toContain("sem TURN");
    expect(protocol.VOICE_DISCLOSURE).toContain("não autenticação por RA");
  });
});

// Source-only harness. Transpile the native file in memory and provide fake modules:
// no RN runtime, native bridge, real WebSocket, mic, camera or voice activity is used.
const nativeSource = readFileSync(new URL("../components/sedx/voice.native.tsx", import.meta.url), "utf8");
const nativeCode = ts.transpileModule(`${nativeSource}\nexports.TestVoiceRoom = NativeVoiceRoom;`, {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, jsx: ts.JsxEmit.React, esModuleInterop: true },
}).outputText;
const ticks = async () => { for (let i = 0; i < 100; i++) await Promise.resolve(); };
function deferred<T>() {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>(done => { resolve = done; });
  return { promise, resolve };
}
class FakeTrack {
  enabled = true; muted = false; readyState = "live";
  listeners = new Map<string, Set<() => void>>();
  stop = vi.fn(() => { this.enabled = false; this.readyState = "ended"; });
  release = vi.fn();
  constructor(public kind: string) {}
  addEventListener(type: string, listener: () => void) {
    if (!this.listeners.has(type)) this.listeners.set(type, new Set());
    this.listeners.get(type)!.add(listener);
  }
  removeEventListener(type: string, listener: () => void) { this.listeners.get(type)?.delete(listener); }
  emit(type: string) { for (const listener of this.listeners.get(type) || []) listener(); }
}
class FakeStream {
  release = vi.fn();
  constructor(public tracks = [new FakeTrack("audio")]) {}
  getTracks() { return this.tracks; }
  getAudioTracks() { return this.tracks.filter(t => t.kind === "audio"); }
  getVideoTracks() { return this.tracks.filter(t => t.kind === "video"); }
  toURL() { return "mock-stream-url"; }
}
class FakeSocket {
  static OPEN = 1;
  static instances: FakeSocket[] = [];
  readyState = 0;
  onopen: null | (() => void) = null;
  onmessage: null | ((event: { data: string }) => void) = null;
  onerror: null | (() => void) = null;
  onclose: null | ((event: { code: number; reason: string }) => void) = null;
  sent: any[] = [];
  close = vi.fn(() => { this.readyState = 3; });
  constructor(public url: string) { FakeSocket.instances.push(this); }
  send(raw: string) { this.sent.push(JSON.parse(raw)); }
  open() { this.readyState = 1; this.onopen?.(); }
  async receive(value: unknown) { this.onmessage?.({ data: frame(value) }); await ticks(); }
}
class FakeDescription {
  constructor(public value: any) {}
  toJSON() { return this.value; }
}
class FakePC {
  static instances: FakePC[] = [];
  connectionState = "new"; signalingState = "stable";
  remoteDescription: any = null; localDescription: any = null;
  listeners = new Map<string, (event: any) => void>();
  senders: { sender: { replaceTrack: ReturnType<typeof vi.fn> } }[] = [];
  addIceCandidate = vi.fn(async (_value: unknown) => {});
  createOffer = vi.fn(async () => description);
  createAnswer = vi.fn(async () => ({ ...description, type: "answer" }));
  close = vi.fn(() => { this.connectionState = "closed"; this.signalingState = "closed"; });
  constructor(public config: any) { FakePC.instances.push(this); }
  addTransceiver(_kind: string, _options: unknown) {
    const tx = { sender: { replaceTrack: vi.fn(async (_track: unknown) => {}) } }; this.senders.push(tx); return tx;
  }
  addEventListener(type: string, listener: (event: any) => void) { this.listeners.set(type, listener); }
  emit(type: string, value: unknown) { this.listeners.get(type)?.(value); }
  async setLocalDescription(value: any) { this.localDescription = new FakeDescription(value); }
  async setRemoteDescription(value: any) { this.remoteDescription = value; }
}
function harness(expoGo = false) {
  const mic = new FakeStream();
  const gum = vi.fn(async () => mic);
  const screen = new FakeStream([new FakeTrack("video")]);
  const gdm = vi.fn(async (_constraints: unknown) => screen);
  const check = vi.fn(async (_permission: string) => true);
  const appState = { currentState: "active" };
  const audio = vi.fn(async (_mode: unknown) => {});
  const nativeRequires = vi.fn();
  const modules: Record<string, any> = {
    react: {},
    "react-native": { AppState: appState, NativeModules: { WebRTCModule: {} },
      Platform: { OS: "android", Version: 34 }, PermissionsAndroid: { check }, StyleSheet: { create: (v: unknown) => v } },
    "expo-constants": { __esModule: true, default: { executionEnvironment: expoGo ? "storeClient" : "standalone" },
      ExecutionEnvironment: { StoreClient: "storeClient" } },
    "expo-router": {}, "expo-audio": { setAudioModeAsync: audio },
    "@/components/sedx/ui": { C: { bg: "black", border: "gray" } },
    "@/lib/sedx/session": {}, "@/lib/sedx/voice-protocol": protocol,
    "react-native-webrtc": { RTCPeerConnection: FakePC, RTCSessionDescription: FakeDescription,
      RTCIceCandidate: class { constructor(public value: any) {} }, MediaStream: FakeStream,
      mediaDevices: { getUserMedia: gum, getDisplayMedia: gdm }, RTCView: () => null },
  };
  const exports: any = {};
  new Function("require", "exports", nativeCode)((id: string) => {
    if (id === "react-native-webrtc") nativeRequires();
    if (!(id in modules)) throw new Error(`Unexpected runtime module ${id}`);
    return modules[id];
  }, exports);
  const updates = vi.fn();
  const room = new exports.TestVoiceRoom(updates);
  return { room, mic, gum, screen, gdm, check, appState, audio, nativeRequires, updates, modules };
}
const identity = { name: "Ana Silva", avatar: "" };
async function joined(h: ReturnType<typeof harness>, peers: any[] = [], max = 20) {
  await h.room.join(identity);
  const ws = FakeSocket.instances.at(-1)!; ws.open();
  await ws.receive({ type: "welcome", id: "self", peers, max });
  return ws;
}

describe("native lifecycle, entirely simulated/offline", () => {
  beforeEach(() => {
    vi.useFakeTimers(); FakeSocket.instances = []; FakePC.instances = [];
    vi.stubGlobal("WebSocket", FakeSocket);
  });
  afterEach(() => { vi.clearAllTimers(); vi.useRealTimers(); vi.unstubAllGlobals(); });
  it("does not load WebRTC, connect or request microphone on mount/construction", () => {
    const h = harness(); expect(h.nativeRequires).not.toHaveBeenCalled();
    expect(h.gum).not.toHaveBeenCalled(); expect(FakeSocket.instances).toHaveLength(0);
  });
  it("blocks Expo Go before any native require or mic permission", async () => {
    const h = harness(true); await h.room.join(identity);
    expect(h.nativeRequires).not.toHaveBeenCalled(); expect(h.gum).not.toHaveBeenCalled();
    expect(FakeSocket.instances).toHaveLength(0); expect(h.room.view.message).toContain("Expo Go");
  });
  it("joins voluntarily with native constraints and source-compatible frames", async () => {
    const h = harness(); const ws = await joined(h);
    expect(h.nativeRequires).toHaveBeenCalledTimes(1);
    expect(h.gum).toHaveBeenCalledWith({ audio: true, video: false });
    expect(ws.url).toBe(protocol.VOICE_SOCKET_URL);
    expect(ws.sent).toEqual([{ type: "join", ...identity, muted: false },
      { type: "state", deaf: false, sharing: false, speaking: false }]);
    vi.advanceTimersByTime(25_000);
    expect(ws.sent.at(-1)).toEqual({ type: "ping" }); h.room.disconnect();
  });
  it("releases a microphone permission result that arrives after cancellation", async () => {
    const h = harness(); const pending = deferred<FakeStream>(); h.gum.mockReturnValueOnce(pending.promise);
    const joining = h.room.join(identity); h.room.disconnect(); pending.resolve(h.mic); await joining;
    expect(h.mic.getTracks()[0].stop).toHaveBeenCalled(); expect(h.mic.release).toHaveBeenCalled();
    expect(FakeSocket.instances).toHaveLength(0); expect(h.room.view.phase).toBe("idle");
  });
  it("permits listen-only join after mic denial and reacquires only on a button action", async () => {
    const h = harness(); h.gum.mockRejectedValueOnce(new Error("denied"));
    const ws = await joined(h); expect(ws.sent[0].muted).toBe(true);
    expect(h.room.view.muted).toBe(true); expect(h.gum).toHaveBeenCalledTimes(1);
    await h.room.toggleMute(); expect(h.gum).toHaveBeenCalledTimes(2);
    expect(h.room.view.muted).toBe(false); expect(ws.sent.at(-1)).toEqual({ type: "state", muted: false });
    h.room.disconnect();
  });
  it("offers to existing peers and never resets their names on signal/state", async () => {
    const h = harness(); const ws = await joined(h, [{ id: "p", name: "Pedro", muted: false }]);
    expect(ws.sent.some(m => m.type === "signal" && m.to === "p" && m.data.description.type === "offer")).toBe(true);
    await ws.receive({ type: "peer-state", peer: { id: "p", muted: true } });
    await ws.receive({ type: "signal", from: "p", data: { description: { ...description, type: "answer" } } });
    expect(h.room.view.members[0].name).toBe("Pedro"); h.room.disconnect();
  });
  it("queues ICE until remote description, then answers newcomers using the original envelope", async () => {
    const h = harness(); const ws = await joined(h);
    await ws.receive({ type: "peer-joined", peer: { id: "p", name: "Pedro" } });
    expect(ws.sent.some(m => m.type === "signal")).toBe(false);
    await ws.receive({ type: "signal", from: "p", data: { candidate } });
    expect(FakePC.instances[0].addIceCandidate).not.toHaveBeenCalled();
    await ws.receive({ type: "signal", from: "p", data: { description } });
    expect(FakePC.instances[0].addIceCandidate).toHaveBeenCalledTimes(1);
    expect(ws.sent.at(-1)).toEqual({ type: "signal", to: "p", data: { description: { ...description, type: "answer" } } });
    h.room.disconnect();
  });
  it("caps the mesh at 19 remotes even after excess peer-joined events", async () => {
    const h = harness(); const ws = await joined(h, Array.from({ length: 30 }, (_, i) => ({ id: `p${i}` })), 999);
    expect(h.room.view.members).toHaveLength(19); expect(FakePC.instances).toHaveLength(19);
    await ws.receive({ type: "peer-joined", peer: { id: "extra" } });
    expect(FakePC.instances).toHaveLength(19); h.room.disconnect();
  });
  it("mutes mic, silences native remote audio and announces only supported states", async () => {
    const h = harness(); const ws = await joined(h, [{ id: "p" }]);
    await h.room.toggleMute(); expect(h.mic.getAudioTracks()[0].enabled).toBe(false);
    expect(ws.sent.at(-1)).toEqual({ type: "state", muted: true, speaking: false });
    const remote = new FakeTrack("audio"); FakePC.instances[0].emit("track", { track: remote });
    h.room.toggleDeaf(); expect(remote.enabled).toBe(false);
    expect(ws.sent.at(-1)).toEqual({ type: "state", deaf: true });
    h.room.toggleDeaf(); expect(remote.enabled).toBe(true); h.room.disconnect();
  });
  it("releases peers, captures, WS handlers and ping on leave, without an invented leave frame", async () => {
    const h = harness(); const ws = await joined(h, [{ id: "p" }]);
    h.room.disconnect(); await ticks();
    expect(h.mic.release).toHaveBeenCalled(); expect(FakePC.instances[0].close).toHaveBeenCalled();
    expect(ws.close).toHaveBeenCalledWith(1000, "left");
    expect(ws.onopen).toBeNull(); expect(ws.onmessage).toBeNull(); expect(ws.onclose).toBeNull();
    expect(ws.sent.some(m => m.type === "leave")).toBe(false);
    expect(vi.getTimerCount()).toBe(0);
    expect(h.audio).toHaveBeenLastCalledWith(expect.objectContaining({ allowsRecording: false, shouldPlayInBackground: false }));
  });
  it.each(["background", "inactive"])("ends the call on %s and never auto-reconnects", async state => {
    const h = harness(); const ws = await joined(h); h.appState.currentState = state; h.room.onAppState(state);
    expect(h.room.view.phase).toBe("idle"); expect(h.mic.release).toHaveBeenCalled(); expect(ws.close).toHaveBeenCalled();
    h.appState.currentState = "active"; h.room.onAppState("active");
    vi.advanceTimersByTime(90_000); expect(FakeSocket.instances).toHaveLength(1);
  });
  it("releases local capture on full and on signaling close", async () => {
    const h = harness(); await h.room.join(identity); const ws = FakeSocket.instances[0]; ws.open();
    await ws.receive({ type: "full", max: 20 });
    expect(h.room.view.message).toContain("Sala cheia"); expect(h.mic.release).toHaveBeenCalled();
    expect(vi.getTimerCount()).toBe(0);
    const h2 = harness(); const ws2 = await joined(h2);
    ws2.onclose?.({ code: 1006, reason: "" }); expect(h2.mic.release).toHaveBeenCalled();
    expect(h2.room.view.phase).toBe("idle");
  });
  it("checks manifest foreground permissions before asking the system for screen capture", async () => {
    const h = harness(); await joined(h); h.check.mockResolvedValue(false); await h.room.toggleScreen();
    expect(h.gdm).not.toHaveBeenCalled(); expect(h.room.view.message).toContain("FOREGROUND_SERVICE"); h.room.disconnect();
  });
  it("uses v155 display constraints, replaces fixed video senders, and renders remote stream URLs", async () => {
    const h = harness(); const ws = await joined(h, [{ id: "p" }]); await h.room.toggleScreen();
    expect(h.gdm).toHaveBeenCalledWith({ android: { resolutionScale: 0.6 } });
    expect(h.check).toHaveBeenCalledWith("android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION");
    expect(h.room.view.sharing).toBe(true); expect(ws.sent.at(-1)).toEqual({ type: "state", sharing: true });
    expect(FakePC.instances[0].senders[1].sender.replaceTrack).toHaveBeenCalledWith(h.screen.getVideoTracks()[0]);
    const track = new FakeTrack("video"); FakePC.instances[0].emit("track", { track });
    await ws.receive({ type: "peer-state", peer: { id: "p", sharing: true } });
    expect(h.room.view.members[0].videoURL).toBe("mock-stream-url");
    await h.room.toggleScreen(); expect(h.screen.release).toHaveBeenCalled();
    expect(ws.sent.at(-1)).toEqual({ type: "state", sharing: false }); h.room.disconnect();
  });
  it("releases a late screen stream after background/dispose and never announces sharing", async () => {
    const h = harness(); const ws = await joined(h); const pending = deferred<FakeStream>(); h.gdm.mockReturnValueOnce(pending.promise);
    const sharing = h.room.toggleScreen(); await ticks();
    h.appState.currentState = "background"; h.room.onAppState("background"); h.room.dispose();
    pending.resolve(h.screen); await sharing;
    expect(h.screen.getVideoTracks()[0].stop).toHaveBeenCalled(); expect(h.screen.release).toHaveBeenCalled();
    expect(ws.sent.some(m => m.type === "state" && m.sharing === true)).toBe(false);
  });
  it("cancels when the handshake times out and remains reusable after Strict Mode cleanup", async () => {
    const h = harness(); await h.room.join(identity); vi.advanceTimersByTime(20_000);
    expect(h.room.view.phase).toBe("idle"); expect(h.mic.release).toHaveBeenCalled();
    h.room.dispose(); h.room.activate(); await h.room.join(identity);
    expect(FakeSocket.instances).toHaveLength(2); h.room.disconnect();
  });
});

describe("platform resolution isolation", () => {
  it("web and fallback contain neither native modules nor DOM/WebView embeddings", () => {
    for (const file of ["voice.web.tsx", "voice.tsx"]) {
      const source = readFileSync(new URL(`../components/sedx/${file}`, import.meta.url), "utf8");
      expect(source).not.toMatch(/react-native-webrtc|voice\.native|WebView|iframe|document\.|window\.|navigator\./);
      expect(source).toContain("VoiceScreen");
    }
    expect(nativeSource).not.toMatch(/WebView|iframe|document\.|window\.|registerGlobals\(/);
  });
});
