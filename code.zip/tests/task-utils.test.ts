import { describe, expect, it } from 'vitest';
import { apiFailure, buildSubmission, captchaHeaders, captchaImageSource, chatPayload, deadlineExpired, durationSeconds, elapsedSeconds, extractQuestions, formatDeadline, htmlMedia, normalizeTasks, number, parseChallenge, parseVerified, plainText, questionComplete, safeHttps, serializeAnswers, studyAttachment, submissionProblems, taskListState, validNumericId, validTarget, verifyBody, type Answers, type Question } from '../lib/sedx/task-utils';

const questions = (row: Record<string, any>): Question[] => extractQuestions({ questions: [row] });
const single = () => questions({ id: 21, type: 'single', statement: 'Escolha uma opção.', options: [{ id: 'a', statement: 'Primeira' }, { id: 'b', statement: 'Segunda' }] });
const fill = () => questions({ id: 22, type: 'fill-words', statement: 'Complete:', options: { phrase: [{ fixed: true, value: 'A' }, { fixed: false, value: '' }, { fixed: true, value: 'e' }, { fixed: false, value: '' }], choices: ['água', 'vida'] } });
const captcha = { token: 'test-only-token', sessionKey: 'test-session', captchaCookie: 'test-cookie=1; auxiliary=2' };
const challenge = { challengeId: 'test-challenge', image: 'data:image/png;base64,iVBORw0KGgo=', sessionKey: 'test-session', captchaCookie: 'test-cookie=1; auxiliary=2' };

describe('contratos acadêmicos e lista de tarefas', () => {
  it('mantém dados desconhecidos diferentes de zero', () => {
    expect(number(null)).toBeNull(); expect(number('')).toBeNull(); expect(number(false)).toBeNull(); expect(number('8,5')).toBe(8.5); expect(number(0)).toBe(0);
  });
  it('não converte falha de tarefas em sucesso vazio', () => {
    const state = taskListState({ tarefas: [], tarefasApiOk: false, tarefasApiStatus: 401 });
    expect(state.confirmed).toBe(false); expect(state.error).toContain('401'); expect(state.tasks).toEqual([]);
  });
  it('lista vazia só é confirmada com indicador de sucesso e array', () => {
    expect(taskListState({ tarefas: [], tarefasApiOk: true }).confirmed).toBe(true);
    expect(taskListState({ tarefas: [] }).confirmed).toBe(false);
    expect(taskListState({ tarefasApiOk: true }).confirmed).toBe(false);
  });
  it('preserva a sala oficial que o Worker normalizou, sem fallback à primeira turma', () => {
    const task = normalizeTasks([{ id: 10, title: 'Atividade real', room: 'r123-l:class', raw: { id: 10, room: 'internal-id', title: 'Atividade real' } }])[0];
    expect(task.id).toBe('10'); expect(task.room).toBe('r123-l:class');
    expect(normalizeTasks([{ title: 'Sem identificador' }])[0].id).toBe('');
    expect(normalizeTasks([{ id: 11, title: 'Sem sala' }])[0].room).toBe('');
  });
  it('respeita o último instante do prazo em São Paulo', () => {
    expect(deadlineExpired('2099-05-06', Date.parse('2099-05-07T02:59:58Z'))).toBe(false);
    expect(deadlineExpired('2099-05-06', Date.parse('2099-05-07T03:00:00Z'))).toBe(true);
    expect(formatDeadline('2099-05-06')).toBe('06/05/2099'); expect(deadlineExpired('inválido')).toBe(false);
  });
  it('reconhece envio e mantém rascunho em aberto', () => {
    expect(normalizeTasks([{ id: 1, status: 'submitted' }])[0].status).toBe('completed');
    expect(normalizeTasks([{ id: 2, status: 'draft' }])[0].isDraft).toBe(true);
  });
  it('expõe falhas sem requerer exceção HTTP', () => { expect(apiFailure({ ok: false, error: 'Consulta falhou' })).toBe('Consulta falhou'); expect(apiFailure({ ok: true })).toBeNull(); });
});

describe('CAPTCHA visual exclusivamente manual', () => {
  it('aceita imagem PNG e bytes sem OCR ou inferência', () => {
    expect(captchaImageSource('iVBORw0KGgo=')).toBe('data:image/png;base64,iVBORw0KGgo=');
    expect(captchaImageSource([137, 80, 78, 71, 13, 10, 26, 10])).toBe('data:image/png;base64,iVBORw0KGgo=');
    expect(captchaImageSource({ type: 'Buffer', data: [137, 80, 78, 71, 13, 10, 26, 10] })).toBe('data:image/png;base64,iVBORw0KGgo=');
  });
  it('bloqueia payloads executáveis, imagens relativas e bytes inválidos', () => {
    expect(captchaImageSource('data:text/html;base64,PHNjcmlwdD4=')).toBeNull();
    expect(captchaImageSource('<svg onload="alert(1)"></svg>')).toBeNull();
    expect(captchaImageSource('http://example.org/code.png')).toBeNull();
    expect(captchaImageSource('/captcha/image.png')).toBeNull(); expect(captchaImageSource([256, -1])).toBeNull();
  });
  it('mantém sessão e todos os cookies no corpo de verificação', () => {
    expect(verifyBody(challenge, ' AbC ')).toEqual({ type: 'image', realm: 'edusp', sessionKey: 'test-session', captchaCookie: challenge.captchaCookie, payload: { challengeId: 'test-challenge', answer: 'AbC' } });
    expect(() => verifyBody(challenge, '  ')).toThrow(/manualmente/);
  });
  it('exige imagem, identificador e sessão devolvidos pelo serviço', () => {
    expect(parseChallenge(challenge)).toEqual(challenge);
    expect(() => parseChallenge({ ...challenge, sessionKey: '' })).toThrow(/sessão/);
    expect(() => parseChallenge({ ...challenge, image: 'não é imagem' })).toThrow();
  });
  it('não valida resposta sem token ou na sessão errada', () => {
    expect(() => parseVerified({ valid: true }, challenge)).toThrow();
    expect(() => parseVerified({ token: 'token', sessionKey: 'other' }, challenge)).toThrow(/mesma sessão/);
    expect(() => parseVerified({ token: 'token', valid: false }, challenge)).toThrow();
  });
  it('preserva cookies atualizados entre verify e apply/answer', () => {
    const verified = parseVerified({ valid: true, token: 'new-token', sessionKey: challenge.sessionKey, captchaCookie: 'test-cookie=2; auxiliary=3' }, challenge);
    expect(captchaHeaders(verified)).toEqual({ 'X-Captcha-Token': 'new-token', 'X-Captcha-Session': 'test-session', 'X-Captcha-Cookie': 'test-cookie=2; auxiliary=3' });
  });
});

describe('respostas explícitas e serialização do Worker ativo', () => {
  it('serializa alternativas por chave de envio original, não por texto ou id inventado', () => {
    expect(questionComplete(single()[0], 'b')).toBe(true);
    expect(serializeAnswers(single(), { '21': 'b' })['21']).toEqual({ question_id: 21, question_type: 'single', answer: { '0': false, '1': true } });
    expect(() => serializeAnswers(single(), { '21': 'x' })).toThrow(/Preencha/);
  });
  it('preserva chaves de opções recebidas como objeto', () => {
    const q = questions({ id: 1, type: 'single', options: { A: 'Texto A', B: 'Texto B' } });
    expect(serializeAnswers(q, { '1': 'B' })['1'].answer).toEqual({ A: false, B: true });
  });
  it('não aceita opções múltiplas fora do banco nem duplicadas', () => {
    const q = questions({ ...single()[0].raw, type: 'multi' });
    expect(questionComplete(q[0], ['a', 'b'])).toBe(true);
    expect(questionComplete(q[0], ['a', 'a'])).toBe(false);
    expect(questionComplete(q[0], ['unknown'])).toBe(false);
  });
  it('exige resposta para todos os itens certo/errado e preserva false', () => {
    const q = questions({ id: 1, type: 'true-false', options: [{ id: 'a', text: 'Item 1' }, { id: 'b', text: 'Item 2' }] });
    expect(questionComplete(q[0], { a: false })).toBe(false);
    expect(serializeAnswers(q, { '1': { a: false, b: true } })['1'].answer).toEqual({ '0': false, '1': true });
  });
  it('respeita limite textual e não preenche automaticamente', () => {
    const q = questions({ id: 1, type: 'text_ai', statement: 'Escreva', options: { max_text_count: 5 } });
    expect(q[0].type).toBe('text'); expect(questionComplete(q[0], '')).toBe(false); expect(questionComplete(q[0], '123456')).toBe(false);
    expect(serializeAnswers(q, { '1': 'Minha' })['1'].answer).toBe('Minha');
  });
  it('envia todas as lacunas na ordem original do enunciado', () => {
    const q = fill(); expect(q[0].bank).toEqual(['água', 'vida']);
    expect(serializeAnswers(q, { '22': { '3': 'vida', '1': 'água' } })['22'].answer).toEqual(['água', 'vida']);
    expect(questionComplete(q[0], { '1': 'água' })).toBe(false); expect(questionComplete(q[0], { '1': 'inventado', '3': 'vida' })).toBe(false);
  });
  it('bloqueia fill-words sem escolhas e não extrai gabarito oculto', () => {
    const q = questions({ id: 1, type: 'fill-words', options: { phrase: [{ fixed: false, value: '', answer: 'oculta', correct: 'oculta' }] } });
    expect(q[0].bank).toEqual([]); expect(q[0].problem).toContain('banco'); expect(() => serializeAnswers(q, { '1': { '0': 'oculta' } })).toThrow();
  });
  it('bloqueia lacunas genéricas sem fingir um contrato de envio fill-words', () => {
    const q = questions({ id: 1, type: 'fill', statement: 'O nome é __ e o ano é __.' });
    expect(q[0].problem).toContain('Worker ativo');
    expect(() => serializeAnswers(q, { '1': { '0': 'nome', '1': 'ano' } })).toThrow();
  });
  it('trata tokens duplicados de ordenação como itens distintos', () => {
    const q = questions({ id: 1, type: 'word-order', options: { word_bank: ['a', 'vida', 'a'] } });
    expect(questionComplete(q[0], [0, 1, 2])).toBe(true); expect(questionComplete(q[0], [0, 1, 0])).toBe(false);
    expect(serializeAnswers(q, { '1': [2, 1, 0] })['1'].answer).toEqual(['a', 'vida', 'a']);
  });
  it('preserva o tipo original de texto com comando de ordenar', () => {
    const q = questions({ id: 1, type: 'text', statement: 'Ordene as palavras para formar a frase.', options: { word_bank: ['uma', 'frase'] } });
    expect(q[0].type).toBe('ordering'); expect(serializeAnswers(q, { '1': [0, 1] })['1'].question_type).toBe('text');
  });
  it('bloqueia tipos desconhecidos e atividades sem questões respondíveis', () => {
    const q = questions({ id: 1, type: 'drag-graph', statement: 'Movimente o gráfico' });
    expect(q[0].type).toBe('unknown'); expect(submissionProblems(q, { '1': 'texto' })[0]).toContain('não suportado');
    expect(() => serializeAnswers(questions({ id: 1, type: 'info', statement: 'Leia' }), {})).toThrow(/respondíveis/);
  });
  it('bloqueia identificadores ausentes/duplicados e alternativas duplicadas', () => {
    expect(questions({ type: 'text' })[0].problem).toContain('identificador');
    expect(extractQuestions({ questions: [{ id: 1, type: 'text' }, { id: 1, type: 'text' }] }).every(q => q.problem)).toBe(true);
    expect(questions({ id: 1, type: 'single', options: [{ id: 'a', text: 'A' }, { id: 'a', text: 'B' }] })[0].problem).toContain('duplicados');
  });
  it('bloqueia notação ou conteúdo que não pode apresentar integralmente', () => {
    expect(questions({ id: 1, type: 'text', statement: '<math><mi>x</mi></math>' })[0].problem).toContain('notação');
    expect(questions({ id: 1, type: 'text', statement: '<iframe src="https://example.org"></iframe>' })[0].problem).toContain('mídia');
  });
});

describe('tempo real e envio sem forjar duração ou sala', () => {
  const args = () => ({ taskId: '10', room: 'r123-l:class', questions: single(), answers: { '21': 'a' } as Answers, session: { cdUsuarioCurto: '456', apelido: 'Estudante de teste' }, captcha, startedAt: 1_000, minimumSeconds: 60, now: 62_000 });
  it('impõe pelo menos 60 segundos e respeita mínimo recebido', () => {
    expect(durationSeconds(0)).toBe(60); expect(durationSeconds(13)).toBe(60); expect(durationSeconds(12)).toBe(720); expect(durationSeconds(1, { task: { min_duration: 95 } })).toBe(95);
    expect(elapsedSeconds(0, 1000)).toBe(0); expect(elapsedSeconds(5000, 4000)).toBe(0);
  });
  it('não envia antes do mínimo ou com início falsamente ausente', () => {
    expect(() => buildSubmission({ ...args(), now: 59_000 })).toThrow(/tempo mínimo/);
    expect(() => buildSubmission({ ...args(), startedAt: 0 })).toThrow(/tempo mínimo/);
  });
  it('envia elapsed real, mesma sessão e target correto, sem status draft ou score artificial', () => {
    const body = buildSubmission(args());
    expect(body.duration).toBe(61); expect(body.executed_on).toBe('r123-l:class'); expect(body.captcha_cookie).toBe(captcha.captchaCookie);
    expect(body.draft).toBeUndefined(); expect(body.result_score).toBeUndefined(); expect(body.status).toBeUndefined();
  });
  it('não permite credenciais incompletas, datetime como target, ou id não numérico', () => {
    expect(() => buildSubmission({ ...args(), session: { apelido: 'teste' } })).toThrow(/Identificação/);
    expect(() => buildSubmission({ ...args(), room: '2026-11-04T12:00:00Z' })).toThrow(/Sala/);
    expect(() => buildSubmission({ ...args(), taskId: 'task-test' })).toThrow(/Identificação/);
    expect(validTarget('r123-l:class')).toBe(true); expect(validNumericId('9007199254740993')).toBe(false);
  });
});

describe('texto nativo e tutor sem auto-answer', () => {
  it('não executa HTML, scripts ou links javascript', () => {
    expect(plainText('<p>Água &amp; vida</p><script>roubar()</script><p>&#231; &aacute;</p>')).toBe('Água & vida\nç á');
    const media = htmlMedia('<a href="javascript:alert(1)">Não</a><img src="https://example.org/image.png">');
    expect(media.links).toEqual([]); expect(media.images).toEqual(['https://example.org/image.png']); expect(safeHttps('https://user:password@example.org')).toBeNull();
  });
  it('limita histórico ao contrato existente sem modelo novo', () => {
    const payload = chatPayload(Array.from({ length: 100 }, (_, i) => ({ role: i % 2 ? 'assistant' as const : 'user' as const, content: 'Histórico' })), 'Explique o conceito');
    expect(payload.messages.length).toBeLessThanOrEqual(20); expect(payload.messages[0].content).toContain('Não selecione');
    expect((payload as any).model).toBeUndefined(); expect(() => chatPayload([], 'x'.repeat(18001))).toThrow(/excede/);
  });
  it('anexa texto de estudo sem incluir gabarito ou respostas locais', () => {
    const attachment = studyAttachment({ questions: [{ ...single()[0].raw, correct: 'b', answer: 'b' }] }, 'Atividade');
    expect(attachment).toContain('Primeira'); expect(attachment).not.toContain('correct'); expect(attachment).not.toContain('answer');
    expect(chatPayload([], 'Como estudar?', attachment).messages.at(-1)?.content).toContain('Material de estudo anexado');
  });
  it('não corta silenciosamente um anexo acima do limite', () => { expect(() => studyAttachment({ statement: 'a'.repeat(12001) }, 'Título')).toThrow(/extensa/); });
});
