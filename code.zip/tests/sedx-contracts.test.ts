import { describe, it, expect } from "vitest";
import { makeUsuario, normalizeSession, safeUrl, raIdentity, dashboardNeedsSessionRefresh } from "../lib/sedx/contracts";
describe("contratos SEDX nativos", () => {
  it("compõe o login no mesmo formato RA + dígito + UF", () => {
    expect(makeUsuario("123456789", "0", "sp")).toBe("1234567890SP");
    expect(makeUsuario("12.345", "x", "SP")).toBe("12345XSP");
  });
  it("rejeita campos de login inválidos", () => {
    expect(() => makeUsuario("", "0", "SP")).toThrow();
    expect(() => makeUsuario("123", "11", "SP")).toThrow();
    expect(() => makeUsuario("123", "0", "S")).toThrow();
  });
  it("não aceita sessão falsa ou incompleta", () => {
    expect(() => normalizeSession({ token: "test-only" }, "1230SP")).toThrow();
    expect(() => normalizeSession({ token: "test-only", token2: "test-only" }, "1230SP")).toThrow();
  });
  it("mantém os nomes oficiais e a prova do perfil sem senha", () => {
    const s = normalizeSession({ token: "fixture-token", token2: "fixture-edu-token", codigoAluno: "123", profileKey: "fixture-key", nome: "Aluno de teste" }, "1230SP");
    expect(s.cdUsuarioCurto).toBe("123"); expect(s.profileKey).toBe("fixture-key");
    expect(s.usuario).toBe("1230SP"); expect(s).not.toHaveProperty("senha");
  });
  it("bloqueia esquemas executáveis e credenciais em links", () => {
    expect(safeUrl("javascript:alert(1)")).toBeNull();
    expect(safeUrl("file:///etc/passwd")).toBeNull();
    expect(safeUrl("https://usuario:senha@example.org")).toBeNull();
    expect(safeUrl("https://example.org/material")).toBe("https://example.org/material");
  });
  it("normaliza a identidade da conta como no Worker", () => expect(raIdentity("001234XSP")).toBe("1234"));
  it("solicita retomada quando o painel informa token expirado ou recusado", () => {
    expect(dashboardNeedsSessionRefresh({ meta: { sessaoSedExpirada: true } })).toBe(true);
    expect(dashboardNeedsSessionRefresh({ meta: { agendaApiOk: false } })).toBe(true);
    expect(dashboardNeedsSessionRefresh({ meta: { alunoApiOk: true, faltasApiOk: true, agendaApiOk: true } })).toBe(false);
    expect(dashboardNeedsSessionRefresh({ meta: null })).toBe(false);
  });
});
