import { describe, expect, it } from "vitest";
import {
  CHAT_MAX_BYTES,
  IMAGE_MAX_BYTES,
  PROFILE_IMAGE_MAX_CHARS,
  PROFILE_PRESETS,
  accountName,
  addReadMarkers,
  allowedAttachmentType,
  asList,
  base64Bytes,
  canReply,
  chatPayload,
  dataUriParts,
  feedbackCreatePayload,
  feedbackDeleteMessagePath,
  feedbackDeleteTicketPath,
  feedbackStatus,
  feedbackTicketPath,
  fitImage,
  formatDateTime,
  formatDuration,
  inferMime,
  initials,
  normalizeChatMessage,
  normalizeFeedbackMessage,
  normalizePartnership,
  normalizeProfile,
  normalizeTicket,
  noticeMarker,
  parseReadMarkers,
  profilePayload,
  publishedAbout,
  raDigits,
  readMarkerKey,
  replyContent,
  replyExcerpt,
  safeFilename,
  safeHttpUrl,
  safeImageUri,
  safeMediaUri,
  sameRa,
  shortName,
  splitReply,
  validateFeedbackContent,
  validateUpload,
} from "../lib/sedx/social-utils";

const image = "data:image/jpeg;base64,YQ==";
const audio = "data:audio/mp4;base64,YQ==";
// Apenas fixtures locais; este arquivo não importa worker e não realiza rede.
describe("identidade e conteúdo sem HTML", () => {
  it("usa o nome oficial legível e não confunde RA com nome", () => {
    expect(accountName({ nome: "12345SP", nomeCompleto: "Ana Maria" })).toBe(
      "Ana Maria",
    );
    expect(accountName(null)).toBe("Aluno");
    expect(shortName("Ana Maria Souza")).toBe("Ana M.");
    expect(shortName("12345SP")).toBe("Aluno");
    expect(initials("Ana Maria")).toBe("AM");
    expect(initials("")).toBe("AL");
    expect(raDigits("012345-6SP")).toBe("0123456");
    expect(sameRa("0123456SP", "0123456")).toBe(true);
    expect(sameRa("", "")).toBe(false);
  });
  it("tolera envelopes ausentes e campos malformados", () => {
    expect(asList(null)).toEqual([]);
    expect(asList([null, false, "texto", { id: "x" }])).toEqual([{ id: "x" }]);
    expect(normalizeTicket(undefined).id).toBe("");
    expect(normalizeFeedbackMessage(undefined).authorName).toBe("Aluno");
  });
  it("não remove HTML de mensagens nem o executa como markup", () => {
    const content = "<script>alert(1)</script>";
    expect(normalizeChatMessage({ content }).content).toBe(content);
  });
});

describe("URLs seguras e dados base64", () => {
  it("aceita somente HTTP/HTTPS sem credenciais como destino externo", () => {
    expect(safeHttpUrl("https://exemplo.test/caminho?x=1")).toBe(
      "https://exemplo.test/caminho?x=1",
    );
    expect(safeHttpUrl("http://exemplo.test")).toBe("http://exemplo.test/");
    for (const url of [
      "javascript:alert(1)",
      "file:///etc/passwd",
      "intent://abc",
      "//exemplo.test",
      "https://user:pass@exemplo.test",
      "https://exemplo.test/a\nb",
      "https:\\exemplo.test",
      "https://exemplo.test/<script>",
      "data:text/html;base64,YQ==",
    ]) {
      expect(safeHttpUrl(url), url).toBe("");
    }
  });
  it("conta bytes decodificados com padding e rejeita base64 inválido", () => {
    expect(base64Bytes("YQ==")).toBe(1);
    expect(base64Bytes("YWI=")).toBe(2);
    expect(base64Bytes("YWJj")).toBe(3);
    expect(base64Bytes("AA===")).toBe(0);
    expect(base64Bytes("not base64")).toBe(0);
    expect(base64Bytes("YQ=")).toBe(0);
    expect(dataUriParts(image)).toEqual({
      type: "image/jpeg",
      base64: "YQ==",
      bytes: 1,
    });
  });
  it("imagens não aceitam HTTP inseguro, SVG, HTML ou URI local externa", () => {
    expect(safeImageUri(image)).toBe(image);
    expect(safeImageUri("https://exemplo.test/imagem.jpg")).toBe(
      "https://exemplo.test/imagem.jpg",
    );
    for (const uri of [
      "data:image/svg+xml;base64,YQ==",
      "data:text/html;base64,YQ==",
      "file:///foto.jpg",
      "http://exemplo.test/foto.jpg",
      "data:image/jpeg;base64,<script>",
    ])
      expect(safeImageUri(uri)).toBe("");
  });
  it("restringe MIME de mídia ao tipo esperado", () => {
    expect(safeMediaUri(audio, "audio")).toBe(audio);
    expect(safeMediaUri(image, "audio")).toBe("");
    expect(safeMediaUri("data:application/pdf;base64,YQ==")).toBe(
      "data:application/pdf;base64,YQ==",
    );
    expect(safeMediaUri("data:application/x-executable;base64,YQ==")).toBe("");
  });
  it("processa base64 no limite de 3 MB sem recursão de regexp", () => {
    const base64 = Buffer.alloc(CHAT_MAX_BYTES).toString("base64");
    expect(base64Bytes(base64)).toBe(CHAT_MAX_BYTES);
    expect(safeMediaUri(`data:audio/mp4;base64,${base64}`, "audio")).not.toBe(
      "",
    );
    const excess = Buffer.alloc(CHAT_MAX_BYTES + 1).toString("base64");
    expect(safeMediaUri(`data:audio/mp4;base64,${excess}`, "audio")).toBe("");
  });
});

describe("respostas da comunidade preservam contrato blockquote", () => {
  it("codifica e decodifica uma citação persistida sem store de replies", () => {
    const encoded = replyContent("Minha resposta", {
      name: "Aluno A.",
      excerpt: "Pergunta original",
    });
    expect(encoded).toBe("> Aluno A.\n> Pergunta original\n\nMinha resposta");
    expect(splitReply(encoded)).toEqual({
      name: "Aluno A.",
      excerpt: "Pergunta original",
      content: "Minha resposta",
    });
    expect(replyExcerpt({ content: encoded })).toBe("Minha resposta");
  });
  it("permite resposta apenas a mensagens de outra pessoa e não deletadas", () => {
    expect(canReply({ authorRa: "456", content: "Olá" }, "123SP")).toBe(true);
    expect(canReply({ authorRa: "123", content: "Minha" }, "123SP")).toBe(
      false,
    );
    expect(canReply({ authorRa: "456", deleted: true }, "123")).toBe(false);
    expect(canReply(null, "123")).toBe(false);
  });
  it("normaliza CRLF, controla comprimento e não injeta novas linhas na citação", () => {
    const encoded = replyContent("Resposta", {
      name: "Ana\n> invasão",
      excerpt: "Dúvida\nsegunda linha",
    });
    expect(encoded).toBe("> Ana > invasão\n> Dúvida segunda linha\n\nResposta");
    expect(splitReply("> Ana\r\n> Dúvida\r\n\r\nResposta").content).toBe(
      "Resposta",
    );
    expect(replyExcerpt({ content: "x".repeat(500) })).toHaveLength(220);
  });
  it("mantém mensagens legadas como texto e mostra rótulos reais de mídia", () => {
    const legacy = '↪ Ana: "Olá"\n\nResposta';
    expect(splitReply(legacy).content).toBe(legacy);
    expect(splitReply("> Apenas uma linha").name).toBe("");
    expect(replyExcerpt({ audioUrl: audio })).toBe("Áudio");
    expect(
      replyExcerpt({ attachmentUrl: image, attachmentName: "Material.pdf" }),
    ).toBe("Material.pdf");
  });
  it("envia payload compatível e conta citação no limite de texto", () => {
    expect(chatPayload(" Olá ")).toEqual({
      content: "Olá",
      attachment: null,
      audio: null,
    });
    expect(
      chatPayload("", null, {
        url: audio,
        name: "audio.m4a",
        type: "audio/mp4",
      }).audio?.type,
    ).toBe("audio/mp4");
    expect(() => chatPayload("")).toThrow();
    expect(() =>
      chatPayload("x".repeat(4000), null, null, {
        name: "Ana",
        excerpt: "Dúvida",
      }),
    ).toThrow(/4.000/);
    expect(() =>
      chatPayload("Olá", {
        url: "javascript:alert(1)",
        name: "x",
        type: "image/jpeg",
      }),
    ).toThrow(/Anexo inválido/);
  });
  it("normaliza envelope estruturado e preserva tombstone para ocultar mídia na UI", () => {
    const message = normalizeChatMessage({
      id: "m1",
      authorRa: "123",
      author: { name: "Ana", avatarUrl: image },
      content: "Resposta",
      attachmentUrl: image,
      attachmentType: "image/jpeg",
      deleted: 1,
      replyTo: { id: "m0", name: "Bia", content: "Pergunta" },
    });
    expect(message.deleted).toBe(true);
    expect(message.replyTo?.id).toBe("m0");
    expect(message.author.avatarUrl).toBe(image);
  });
});

describe("anexos e otimização nativa", () => {
  it("mantém proporção e nunca amplia imagens pequenas", () => {
    expect(fitImage(2400, 1200, 900)).toEqual({ width: 900, height: 450 });
    expect(fitImage(400, 200, 900)).toEqual({ width: 400, height: 200 });
    expect(fitImage(100, 1000, 800)).toEqual({ width: 80, height: 800 });
    expect(() => fitImage(0, 100, 900)).toThrow();
  });
  it("aceita somente os tipos e bytes autorizados pelo upload ativo", () => {
    expect(() => validateUpload(CHAT_MAX_BYTES, "audio/mp4")).not.toThrow();
    expect(() => validateUpload(CHAT_MAX_BYTES + 1, "audio/mp4")).toThrow(
      /3 MB/,
    );
    expect(() => validateUpload(undefined, "image/jpeg")).toThrow(/tamanho/);
    expect(() => validateUpload(0, "image/jpeg")).toThrow();
    expect(() => validateUpload(100, "application/x-msdownload")).toThrow(
      /Tipo de arquivo/,
    );
    expect(
      allowedAttachmentType(
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      ),
    ).toBe(true);
    expect(
      allowedAttachmentType(
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      ),
    ).toBe(true);
  });
  it("infere MIME de arquivos do seletor e saneia nomes para cache", () => {
    expect(inferMime("Gravacao.M4A", null)).toBe("audio/mp4");
    expect(inferMime("material.pdf", "application/octet-stream")).toBe(
      "application/pdf",
    );
    expect(inferMime("material.xlsm", null)).toBe("application/octet-stream");
    expect(inferMime("video.bin", "video/mp4")).toBe("video/mp4");
    expect(safeFilename("../../meu/arquivo.pdf")).not.toMatch(/[\\/]/);
    expect(safeFilename("")).toBe("anexo");
  });
});

describe("suporte com contratos reais", () => {
  it("cria atendimento com tipos e limites exatos do Worker", () => {
    expect(
      feedbackCreatePayload("bug", "  Mensagem com problema  ", image),
    ).toEqual({ type: "bug", content: "Mensagem com problema", image });
    expect(() => feedbackCreatePayload("suggestion", "curta")).toThrow(
      /10 caracteres/,
    );
    expect(() => feedbackCreatePayload("bug", "x".repeat(2001))).toThrow(
      /2.000/,
    );
    expect(() =>
      feedbackCreatePayload(
        "bug",
        "x".repeat(10),
        "https://exemplo.test/foto.jpg",
      ),
    ).toThrow(/250 KB/);
    const large = `data:image/jpeg;base64,${Buffer.alloc(IMAGE_MAX_BYTES + 1).toString("base64")}`;
    expect(() => feedbackCreatePayload("bug", "x".repeat(10), large)).toThrow(
      /250 KB/,
    );
  });
  it("respostas e edição aceitam 1..2000 caracteres, nunca texto vazio", () => {
    expect(validateFeedbackContent(" A ")).toBe("A");
    expect(validateFeedbackContent("x".repeat(2000))).toHaveLength(2000);
    expect(() => validateFeedbackContent(" \n ")).toThrow(/vazia/);
    expect(() => validateFeedbackContent("x".repeat(2001))).toThrow();
  });
  it("escapa IDs em query string para abrir/excluir mensagens e ticket admin", () => {
    const id = "ticket/1?x&ação";
    expect(feedbackTicketPath(id)).toBe(
      `/feedback/ticket?id=${encodeURIComponent(id)}`,
    );
    expect(feedbackDeleteMessagePath(id)).toBe(
      `/feedback/message?id=${encodeURIComponent(id)}`,
    );
    expect(feedbackDeleteTicketPath(id)).toBe(
      `/admin/feedback?id=${encodeURIComponent(id)}`,
    );
  });
  it("mantém status e autoria dos retornos de suporte", () => {
    expect(
      ["aberto", "em_analise", "resolvido", "arquivado"].map(feedbackStatus),
    ).toEqual(["Recebido", "Em análise", "Resolvido", "Arquivado"]);
    expect(
      normalizeTicket({
        userRA: "123SP",
        image: "javascript:bad",
        adminReply: "Retorno",
      }),
    ).toMatchObject({ userRa: "123SP", image: "", adminReply: "Retorno" });
    expect(
      normalizeFeedbackMessage({ id: "m1", mine: true, authorRa: "123" }).mine,
    ).toBe(true);
  });
});

describe("perfil completo sem outra store de temas", () => {
  const current = {
    photo: image,
    banner: image,
    description: "Descrição antiga",
    theme: "ocean",
    accent: "#45b9ff",
    secondary: "#5d6bff",
    bg: "#07111c",
    foreground: "#f7f7f7",
  };
  it("PUT de uma descrição mantém todos os campos do perfil", () => {
    const payload = profilePayload(current, {
      description: " Nova descrição ",
    });
    expect(payload).toEqual({ ...current, description: "Nova descrição" });
    expect(Object.keys(payload).sort()).toEqual([
      "accent",
      "banner",
      "bg",
      "description",
      "foreground",
      "photo",
      "secondary",
      "theme",
    ]);
  });
  it("usa presets apenas como padrão de perfil e aceita cores HEX6", () => {
    expect(normalizeProfile({ theme: "ocean" })).toMatchObject({
      accent: "#45b9ff",
      bg: "#07111c",
    });
    expect(normalizeProfile({ profile: current })).toEqual(current);
    expect(PROFILE_PRESETS).toHaveLength(4);
    expect(() => profilePayload(current, { accent: "red" })).toThrow(/#RRGGBB/);
    expect(() =>
      profilePayload(current, { description: "x".repeat(181) }),
    ).toThrow(/180/);
  });
  it("remove imagem explicitamente e valida limites do data URI", () => {
    expect(profilePayload(current, { photo: "" }).photo).toBe("");
    expect(() =>
      profilePayload(current, { photo: "file:///user/photo.jpg" }),
    ).toThrow(/imagem válida/);
    const large = `data:image/jpeg;base64,${Buffer.alloc(230000).toString("base64")}`;
    expect(large.length).toBeGreaterThan(PROFILE_IMAGE_MAX_CHARS);
    expect(() => profilePayload(current, { banner: large })).toThrow(/limite/);
  });
});

describe("anúncios: uma fonte e marcadores locais por conta", () => {
  const first = {
    id: "n1",
    publishedAt: "2026-11-01",
    updatedAt: "2026-11-02",
  };
  const revised = { ...first, updatedAt: "2026-11-03" };
  it("isola conta e marca versões revistas como novas", () => {
    expect(readMarkerKey("123SP")).not.toBe(readMarkerKey("456SP"));
    expect(readMarkerKey("123SP")).toBe(readMarkerKey("123"));
    expect(noticeMarker(first)).not.toBe(noticeMarker(revised));
    expect(addReadMarkers([], [first, first])).toEqual(["n1:2026-11-02"]);
  });
  it("tolera armazenamento corrompido sem inventar dados", () => {
    expect(parseReadMarkers("bad JSON")).toEqual([]);
    expect(parseReadMarkers("{}")).toEqual([]);
    expect(parseReadMarkers('["x", "x", 3, null]')).toEqual(["x"]);
    expect(
      addReadMarkers(
        [],
        Array.from({ length: 250 }, (_, index) => ({ id: `n${index}` })),
      ),
    ).toHaveLength(200);
  });
});

describe("conteúdo publicado, datas e estados vazios", () => {
  it("somente renderiza a versão publicada de Sobre", () => {
    expect(
      publishedAbout({ published: false, content: { title: "Rascunho" } }),
    ).toBeNull();
    expect(publishedAbout(null)).toBeNull();
    expect(
      publishedAbout({
        published: true,
        content: { title: "Sobre", intro: "Texto", sections: [{ id: "s1" }] },
      }),
    ).toEqual({ title: "Sobre", intro: "Texto", sections: [{ id: "s1" }] });
  });
  it("normaliza publicação de parcerias e bloqueia destinos perigosos", () => {
    expect(
      normalizePartnership({
        isPublished: "1",
        destinationUrl: "https://discord.gg/exemplo",
        type: "Discord",
      }),
    ).toMatchObject({
      isPublished: true,
      destinationUrl: "https://discord.gg/exemplo",
      type: "Discord",
    });
    expect(
      normalizePartnership({
        isPublished: false,
        destinationUrl: "javascript:bad",
        type: "desconhecido",
      }),
    ).toMatchObject({ isPublished: false, destinationUrl: "", type: "Outro" });
  });
  it("datas e duração inválidas não geram NaN nem conteúdo falso", () => {
    expect(formatDateTime("invalid")).toBe("");
    expect(formatDateTime(null)).toBe("");
    expect(formatDateTime("2026-11-04T15:00:00Z")).toContain("2026");
    expect(formatDuration(125)).toBe("2:05");
    expect(formatDuration(-5)).toBe("0:00");
    expect(formatDuration(Number.NaN)).toBe("0:00");
  });
});
